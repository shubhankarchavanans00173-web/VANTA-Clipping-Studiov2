"""Real caption self-check: render a 5 second vertical sample through the SAME code path VANTA uses for exports,
then report PASS/FAIL from the pixel comparison at several moments of the clip.

    python check_captions.py                # PASS/FAIL, files kept in ../check_captions_output
    python check_captions.py --out D:\\x     # choose where the sample, frames and report are written
    python check_captions.py --font "Segoe UI"

Exit codes: 0 = PASS, 1 = FAIL (captions not provably visible), 2 = cannot run (FFmpeg/libass/fonts missing).

What PASS means: at EVERY sampled moment the captions that libass draws on a neutral canvas are present, pixel for pixel
(allowing H.264 drift), in the frame read back from the finished MP4. What it does NOT prove: that the text is spelled
correctly, nor that Devanagari letters are shaped correctly (a missing-glyph "box" is still pixels, so a separate shape check runs). For that, the script
adds a Hindi line and compares it with a row of missing-glyph boxes (FAIL when it is the same); it still tells you which PNG to open.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from PIL import Image  # noqa: E402

from app.clipstudio import capfx  # noqa: E402
from app.clipstudio.errors import CaptionError, RenderError  # noqa: E402
from app.clipstudio.render import ASPECTS, RenderSettings, render_clip  # noqa: E402
from app.clipstudio.transcript import Transcript, parse_subtitles  # noqa: E402

DURATION = 5
HINDI = "\u0928\u092e\u0938\u094d\u0924\u0947 \u0926\u0941\u0928\u093f\u092f\u093e \u092f\u0939 \u0915\u0948\u092a\u094d\u0936\u0928 \u091c\u093e\u0901\u091a \u0939\u0948"   # "namaste duniya yah caption jaanch hai"
SRT = f"""1
00:00:00,200 --> 00:00:01,700
This is a caption check for VANTA.

2
00:00:01,900 --> 00:00:03,300
{HINDI}

3
00:00:03,500 --> 00:00:04,800
Captions must be visible at every moment.
"""
HINDI_WINDOW = (1.9, 3.3)


def tool_version(name: str) -> str | None:
    exe = shutil.which(name)
    if not exe:
        return None
    try:
        out = subprocess.run([exe, "-version"], capture_output=True, text=True, timeout=20).stdout.splitlines()
    except (OSError, subprocess.SubprocessError):
        return None
    return out[0] if out else "unknown version"


def has_ass_filter() -> bool:
    exe = shutil.which("ffmpeg")
    if not exe:
        return False
    out = subprocess.run([exe, "-hide_banner", "-filters"], capture_output=True, text=True, timeout=30).stdout
    return any(line.split()[1:2] == ["ass"] for line in out.splitlines() if line.strip())


def make_sample(path: Path) -> None:
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-f", "lavfi", "-i", f"testsrc2=size=1280x720:rate=30:duration={DURATION}",
           "-f", "lavfi", "-i", f"sine=f=440:duration={DURATION}:sample_rate=48000", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-shortest", str(path)]
    subprocess.run(cmd, check=True, timeout=120, capture_output=True)


TOFU = "\u0378"                 # an unassigned code point: every font draws it as its missing-glyph box
TOFU_SIMILARITY = 0.80          # real shaped Devanagari vs the all-boxes reference scores ~0.1-0.4; boxes score ~1.0


def mask_similarity(a_png: Path, b_png: Path) -> float:
    """Intersection-over-union of the two caption glyph masks."""
    from PIL import ImageChops
    a, b = capfx.glyph_mask(a_png).convert("1"), capfx.glyph_mask(b_png).convert("1")
    inter = ImageChops.logical_and(a, b).convert("L").histogram()[255]
    union = ImageChops.logical_or(a, b).convert("L").histogram()[255]
    return inter / union if union else 0.0


def hindi_boxes_check(work: Path, t: float, W: int, H: int, probe_png: Path, plan: "capfx.FontPlan") -> tuple[str, str, float]:
    """Render the SAME caption with every Devanagari character replaced by a missing-glyph code point and compare.

    Pixel presence cannot tell shaped Devanagari from a row of boxes (both are pixels), so this compares shapes instead.
    Returns (level, message, similarity) with level OK or FAIL.
    """
    ass = (work / "captions.ass").read_text(encoding="utf-8")
    boxed = "".join(TOFU if "\u0900" <= ch <= "\u097f" else ch for ch in ass)
    (work / "captions_boxes_reference.ass").write_text(boxed, encoding="utf-8")
    ref = capfx.probe_glyphs(shutil.which("ffmpeg") or "ffmpeg", work, "captions_boxes_reference.ass", plan, W, H, t, name="boxes_reference")
    sim = mask_similarity(probe_png, ref)
    if sim >= TOFU_SIMILARITY:
        return "FAIL", (f"the Hindi caption is {sim:.0%} identical to a row of missing-glyph boxes: no installed font provides Devanagari to FFmpeg. "
                        "Windows: confirm 'Nirmala UI' exists in C:\\Windows\\Fonts, or set VANTA_FONTS_DIR to a folder holding a Devanagari .ttf, then run this check again."), sim
    return "OK", f"the Hindi caption differs from a row of boxes (similarity {sim:.0%}), so real glyphs are being drawn. Open the PNG to confirm they look right.", sim


def environment_report(font: str) -> tuple[list[str], bool]:
    lines, fatal = [], False
    lines.append(f"OS: {platform.platform()}  |  Python: {sys.version.split()[0]} ({sys.executable})")
    for tool in ("ffmpeg", "ffprobe"):
        v = tool_version(tool)
        lines.append(f"{tool}: {v or 'NOT FOUND on PATH'}")
        fatal |= v is None
    if not fatal:
        ok = has_ass_filter()
        lines.append(f"FFmpeg 'ass' (libass) filter: {'present' if ok else 'MISSING - install a full FFmpeg build (winget install Gyan.FFmpeg)'}")
        fatal |= not ok
    lines.append(f"Bundled fallback font: {', '.join(p.name for p in capfx.BUNDLED_FONTS.glob('*.ttf')) or 'MISSING'}")
    for fam in (font,):
        hits = capfx._find_named(capfx._KNOWN_FILES.get(fam.lower(), []))
        lines.append(f"Requested font '{fam}': {hits[0] if hits else 'not found on this computer (DejaVu Sans will be used)'}")
    deva = capfx._find_named(capfx._SCRIPT_FALLBACKS[0][1]) or ([capfx._fc_match(':lang=hi')] if capfx._fc_match(':lang=hi') else [])
    lines.append(f"Devanagari (Hindi) font: {deva[0] if deva else 'NOT FOUND - Hindi captions may show boxes'}")
    return lines, fatal


def run_check(out_dir: Path, font: str = "Arial", aspect: str = "9:16", with_hindi: bool = True) -> dict:
    """Render the sample and return a report dict. ``result`` is PASS, FAIL or CANNOT_RUN. Never raises for expected failures."""
    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    env_lines, fatal = environment_report(font)
    report: dict = {"environment": env_lines, "result": "CANNOT_RUN", "points": [], "hindi": None, "notes": [], "output_dir": str(out_dir)}
    if fatal:
        report["notes"].append("FFmpeg/ffprobe/libass is missing, so captions cannot be rendered at all.")
        return report
    work = out_dir / "work"
    shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True)
    src, dst, srt_out = out_dir / "sample_source.mp4", out_dir / "sample_captioned.mp4", out_dir / "sample_captions.srt"
    try:
        make_sample(src)
        tr = Transcript(parse_subtitles(SRT if with_hindi else SRT.replace(HINDI, "This line replaces the Hindi one.")), "subtitle-file")
        info = {"has_audio": True, "width": 1280, "height": 720, "duration": DURATION, "fps": 30}
        settings = RenderSettings.from_dict({"aspect": aspect, "captions": True, "caption_style": {"font": font}})
        result = render_clip(src, dst, work, 0.0, float(DURATION), info, settings, tr, None, srt_path=srt_out)
        ver = result["caption_verification"]
    except CaptionError as error:
        report.update(result="FAIL", notes=[f"Caption verification failed [{getattr(error, 'code', '')}]: {error}"])
        _keep_frames(work, out_dir)
        return report
    except (RenderError, subprocess.SubprocessError, OSError) as error:
        report.update(result="CANNOT_RUN", notes=[f"The sample could not be rendered: {error}"])
        _keep_frames(work, out_dir)
        return report
    _keep_frames(work, out_dir)
    report["points"] = ver.get("points", [])
    report["output_file"] = str(dst)
    report["captions_note"] = result.get("captions_note", "")
    report["result"] = "PASS" if ver.get("visible") and len(report["points"]) >= 2 else "FAIL"
    if report["result"] == "FAIL" and ver.get("visible"):
        report["notes"].append(f"Only {len(report['points'])} moment(s) could be checked (need at least 2).")
    if with_hindi:
        for i, p in enumerate(report["points"]):
            if HINDI_WINDOW[0] <= p["at_seconds"] <= HINDI_WINDOW[1]:
                png = work / ("caption_probe.png" if i == 0 else f"caption_probe_{i}.png")
                W, H = ASPECTS[aspect]
                plan = capfx.FontPlan(_style_family(work), "fonts")
                try:
                    level, msg, sim = hindi_boxes_check(work, p["at_seconds"], W, H, png, plan)
                except CaptionError as error:
                    level, msg, sim = "FAIL", f"could not run the Hindi shape check: {error}", 1.0
                report["hindi"] = {"level": level, "message": msg, "similarity_to_boxes": round(sim, 3), "at_seconds": p["at_seconds"],
                                   "frame": str(out_dir / ("frame_0.png" if i == 0 else f"frame_{i}.png"))}
                if level == "FAIL":
                    report["result"] = "FAIL"
    if with_hindi and report["hindi"] is None:
        report["notes"].append("The Hindi moment was not among the checked points.")
    return report


def _style_family(work: Path) -> str:
    """Font family written into the ASS style of the render that was just checked."""
    import re
    m = re.search(r"^Style:\s*[^,]*,([^,]+),", (work / "captions.ass").read_text(encoding="utf-8"), re.M)
    return m.group(1).strip() if m else capfx.FALLBACK_FAMILY


def _keep_frames(work: Path, out_dir: Path) -> None:
    for i in range(8):
        f = work / ("export_frame.png" if i == 0 else f"export_frame_{i}.png")
        if f.is_file():
            shutil.copy2(f, out_dir / f"frame_{i}.png")
    for name in ("ffmpeg_stderr.txt", "ffmpeg_command.txt", "captions.ass"):
        if (work / name).is_file():
            shutil.copy2(work / name, out_dir / name)


def format_report(r: dict) -> str:
    L = ["=" * 64, "VANTA caption check", "=" * 64, *r["environment"], ""]
    if r["points"]:
        L.append(f"Moments checked in the exported 9:16 MP4 (need >= {capfx.MIN_MATCH_RATIO:.0%} of caption pixels present):")
        for p in r["points"]:
            L.append(f"  t={p['at_seconds']:>5.2f}s  caption pixels={p['glyph_pixels']:>6}  found={p['match_ratio']:.1%}  {'ok' if p['visible'] else 'MISSING'}")
    if r.get("hindi"):
        h = r["hindi"]
        L.append(f"Hindi/Devanagari at {h['at_seconds']}s [{h['level']}]: {h['message']}")
        L.append(f"  Look at this frame yourself: {h['frame']}")
    for n in r["notes"]:
        L.append(f"NOTE: {n}")
    L += ["", f"Files: {r['output_dir']}", f"RESULT: {r['result']}"]
    if r["result"] == "PASS":
        L.append("(Pixel check only. Open sample_captioned.mp4 to confirm the wording and that Hindi letters are not boxes.)")
    return "\n".join(L)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "check_captions_output"))
    ap.add_argument("--font", default="Arial")
    ap.add_argument("--aspect", default="9:16", choices=["9:16", "1:1", "16:9"])
    ap.add_argument("--no-hindi", action="store_true", help="skip the Hindi/Devanagari line and its shape check")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    r = run_check(Path(ns.out), ns.font, ns.aspect, not ns.no_hindi)
    (Path(ns.out)).mkdir(parents=True, exist_ok=True)
    (Path(ns.out) / "report.json").write_text(json.dumps(r, indent=1, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(r, indent=1, ensure_ascii=False) if ns.json else format_report(r))
    return {"PASS": 0, "FAIL": 1}.get(r["result"], 2)


if __name__ == "__main__":
    sys.exit(main())

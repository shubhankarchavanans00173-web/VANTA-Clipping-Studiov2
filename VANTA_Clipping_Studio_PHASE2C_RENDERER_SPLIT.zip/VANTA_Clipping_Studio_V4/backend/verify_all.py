"""One-command verification of a VANTA install. Writes a single report you can send back.

    verify_all.bat                                   (Windows; recommended)
    python backend/verify_all.py [options]

Options
    --url URL          public video for the live download check (default: the short sample used in the docs)
    --video FILE       also transcribe the first 60 s of this file with the real Whisper model (needs the model already downloaded)
    --skip-network     do not attempt the live YouTube download
    --skip-tests       do not run the backend unit tests
    --tests A,B        only these test modules (e.g. test_core,test_selection)
    --test-timeout S   seconds allowed per test module (default 1500)
    --report FILE      where to write the report (default: verify_report.txt in the project folder)

Each check ends as PASS, FAIL or SKIPPED (with the reason). SKIPPED means NOT VERIFIED, not "fine".
Exit code: 0 = no check FAILED (skips may exist), 1 = at least one FAIL.

Safety: this never registers the Windows scheduled task, never uploads anything, never downloads a Whisper model, and
never reads your .env into the report. Test processes get a throw-away data folder and blank API keys.
"""
from __future__ import annotations

import argparse
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

PASS, FAIL, SKIPPED = "PASS", "FAIL", "SKIPPED"
DEFAULT_URL = "https://www.youtube.com/watch?v=jNQXAC9IVRw"
TAIL_LINES = 60
SECRET_ENV_HINTS = ("KEY", "TOKEN", "SECRET", "PASSWORD", "CREDENTIAL")
# Variables blanked for the unit-test processes so a real .env can never turn on a paid/online path during tests.
BLANKED_FOR_TESTS = ("ANTHROPIC_API_KEY", "VANTA_CLOUD_AI_ENABLED", "VANTA_CLOUD_AI_MODEL", "PEXELS_API_KEY", "REPLICATE_API_TOKEN",
                     "YOUTUBE_CLIENT_SECRET_FILE", "VANTA_LOCAL_LLM", "VANTA_LOCAL_LLM_MODEL")
# Steps that must never appear in this runner (it must not touch the Windows scheduled task).
FORBIDDEN_TOKENS = ("install_scheduler_task", "schtasks", "uninstall_scheduler_task")

_TOKEN_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
    re.compile(r"ya29\.[0-9A-Za-z_\-]{10,}"),
    re.compile(r"1//[0-9A-Za-z_\-]{20,}"),
    re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{12,}"),
    re.compile(r"(?i)(api[_-]?key|token|secret|password)\s*[=:]\s*\S+"),
]


@dataclass
class Step:
    key: str
    title: str
    cmd: list[str] | str | None = None          # list = argv, str = raw Windows command line
    cwd: Path | None = None
    timeout: int = 600
    env: dict[str, str] = field(default_factory=dict)
    skip_reason: str | None = None              # decided before running
    skip_codes: dict[int, str] = field(default_factory=dict)   # exit code -> reason it counts as SKIPPED (not a failure)
    group: str = "checks"


@dataclass
class Result:
    step: Step
    status: str
    reason: str
    seconds: float = 0.0
    returncode: int | None = None
    output: str = ""
    detail: str = ""


# ----------------------------------------------------------------------------- scrubbing
def redact(text: str, home: str | None = None, extra_secrets: list[str] | None = None) -> str:
    """Remove anything that looks like a credential and shorten the user's home folder. Never raises."""
    if not text:
        return ""
    out = text
    for s in sorted({x for x in (extra_secrets or []) if x and len(x) >= 6}, key=len, reverse=True):
        out = out.replace(s, "[redacted]")
    for p in _TOKEN_PATTERNS:
        out = p.sub(lambda m: (m.group(1) + "=[redacted]") if m.lastindex else "[redacted]", out)
    if home:
        out = re.sub(re.escape(home), "%USERPROFILE%" if os.name == "nt" else "~", out, flags=re.I)
    return out


def secret_values_from_env(environ: dict[str, str] | None = None) -> list[str]:
    environ = environ if environ is not None else os.environ
    return [v for k, v in environ.items() if any(h in k.upper() for h in SECRET_ENV_HINTS) and v and len(v) >= 6]


def tail(text: str, n: int = TAIL_LINES) -> str:
    lines = (text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    lines = [ln.rstrip() for ln in lines]
    while lines and not lines[-1]:
        lines.pop()
    if len(lines) <= n:
        return "\n".join(lines)
    return f"... ({len(lines) - n} earlier lines omitted)\n" + "\n".join(lines[-n:])


# ----------------------------------------------------------------------------- command building
def windows_cmd_line(bat: Path, *args: str) -> str:
    """Raw command line for CreateProcess that survives spaces: cmd /d /s /c ""bat" "arg" ..""  (outer quotes are stripped by /s)."""
    inner = " ".join(['"%s"' % str(bat)] + ['"%s"' % a.replace('"', "") for a in args])
    return f'cmd.exe /d /s /c "{inner}"'


def discover_test_modules(backend: Path) -> list[str]:
    return sorted(p.stem for p in (backend / "tests").glob("test_*.py"))


def build_steps(root: Path, python: str, *, url: str, video: str | None, skip_network: bool, skip_tests: bool,
                only_tests: list[str] | None, test_timeout: int, windows: bool) -> list[Step]:
    backend = root / "backend"
    steps: list[Step] = []
    env_nopause = {"VANTA_NO_PAUSE": "1"}

    def bat_or_py(bat: Path, py_args: list[str], *bat_args: str) -> list[str] | str:
        return windows_cmd_line(bat, *bat_args) if windows else [python, *py_args]

    steps.append(Step("system", "System check (Python, Node, FFmpeg, FFprobe, folders)",
                      bat_or_py(root / "check_system.bat", [str(backend / "diagnose.py")]), cwd=root, timeout=300, env=env_nopause))

    if skip_network:
        steps.append(Step("youtube", "Live YouTube download (public sample)", skip_reason="--skip-network was given; live download NOT verified"))
    else:
        steps.append(Step("youtube", f"Live YouTube download of {url}",
                          bat_or_py(root / "diagnose_youtube.bat", [str(backend / "diagnose.py"), "--test-url", url], url),
                          cwd=root, timeout=1500, env=env_nopause))

    t_args = [str(backend / "check_transcription.py")]
    t_bat = ["--file", video] if video else []
    if video:
        t_args += ["--file", video]
    steps.append(Step("transcription", "Local transcription (faster-whisper status" + (" + real 60 s run)" if video else ", no download)"),
                      bat_or_py(root / "scripts" / "check_transcription.bat", t_args, *t_bat), cwd=root, timeout=1800, env=env_nopause,
                      skip_codes={2: "faster-whisper or the model is not installed/downloaded here (real transcription NOT verified)"}))

    steps.append(Step("captions", "Caption rendering self-check (English + Hindi, real FFmpeg)",
                      bat_or_py(root / "scripts" / "check_captions.bat", [str(backend / "check_captions.py"), "--out", str(root / "check_captions_output")]),
                      cwd=root, timeout=900, env=env_nopause,
                      skip_codes={2: "the check could not run (see output); captions NOT verified"}))

    if skip_tests:
        steps.append(Step("tests", "Backend unit tests", skip_reason="--skip-tests was given; tests NOT run", group="tests"))
    else:
        mods = discover_test_modules(backend)
        if only_tests:
            wanted = [m if m.startswith("test_") else "test_" + m for m in only_tests]
            missing = [m for m in wanted if m not in mods]
            mods = [m for m in wanted if m in mods]
            for m in missing:
                steps.append(Step(f"tests.{m}", f"Unit tests: {m}", skip_reason="no such test module", group="tests"))
        for m in mods:
            steps.append(Step(f"tests.{m}", f"Unit tests: {m}", [python, "-m", "unittest", f"tests.{m}"], cwd=backend, timeout=test_timeout, group="tests"))
    return steps


# ----------------------------------------------------------------------------- running and classifying
_RAN = re.compile(r"Ran (\d+) tests? in ([\d.]+)s")


def parse_unittest(output: str) -> dict:
    ran = _RAN.search(output or "")
    failed = re.search(r"FAILED \(([^)]*)\)", output or "")
    return {"ran": int(ran.group(1)) if ran else None, "ok": bool(re.search(r"^OK\b", output or "", re.M)),
            "failed": failed.group(1) if failed else None, "skipped": re.search(r"skipped=(\d+)", output or "") is not None}


def classify(step: Step, rc: int | None, timed_out: bool, output: str) -> tuple[str, str]:
    if timed_out:
        return FAIL, f"timed out after {step.timeout}s (it may just be slow on this PC: rerun with --test-timeout)"
    if rc is None:
        return FAIL, "could not start the command"
    if step.group == "tests":
        info = parse_unittest(output)
        if rc == 0 and info["ok"] and info["ran"] is not None:
            extra = " (some tests skipped)" if info["skipped"] else ""
            return PASS, f"{info['ran']} tests OK{extra}"
        if rc == 0:
            return FAIL, "exit 0 but no 'OK' summary found: treated as not verified"
        return FAIL, info["failed"] or f"exit code {rc}"
    if rc == 0:
        return PASS, "exit code 0"
    if rc in step.skip_codes:
        return SKIPPED, step.skip_codes[rc]
    return FAIL, f"exit code {rc}"


def run_step(step: Step, base_env: dict[str, str], runner: Callable = subprocess.run) -> Result:
    if step.skip_reason:
        return Result(step, SKIPPED, step.skip_reason)
    env = dict(base_env)
    env.update(step.env)
    t0 = time.monotonic()
    try:
        cp = runner(step.cmd, cwd=str(step.cwd) if step.cwd else None, env=env, capture_output=True, timeout=step.timeout, shell=False)
        out = _decode(cp.stdout) + (("\n" + _decode(cp.stderr)) if cp.stderr else "")
        status, reason = classify(step, cp.returncode, False, out)
        return Result(step, status, reason, time.monotonic() - t0, cp.returncode, out)
    except subprocess.TimeoutExpired as e:
        out = _decode(e.stdout or b"") + _decode(e.stderr or b"")
        status, reason = classify(step, None, True, out)
        return Result(step, status, reason, time.monotonic() - t0, None, out)
    except (OSError, ValueError) as e:
        return Result(step, FAIL, f"could not start: {type(e).__name__}: {e}", time.monotonic() - t0, None, "")


def _decode(b) -> str:
    if b is None:
        return ""
    if isinstance(b, str):
        return b
    if b.startswith((b"\xff\xfe", b"\xfe\xff")):
        return b.decode("utf-16", errors="replace")
    for enc in ("utf-8", "cp1252"):
        try:
            return b.decode(enc)
        except UnicodeDecodeError:
            continue
    return b.decode("utf-8", errors="replace")


def test_env(base: dict[str, str], tmp_data: str) -> dict[str, str]:
    """Environment for unit-test processes: throw-away data folder, secrets/paid paths blanked, no network features switched on."""
    env = dict(base)
    env.update({"VANTA_DATA_DIR": tmp_data, "STUDIO_DATA_DIR": tmp_data, "PYTHONPATH": ".", "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
    for k in BLANKED_FOR_TESTS:
        env[k] = ""
    return env


# ----------------------------------------------------------------------------- report
def tool_version(cmd: list[str]) -> str:
    exe = shutil.which(cmd[0])
    if not exe:
        return "NOT FOUND"
    try:
        cp = subprocess.run([exe, *cmd[1:]], capture_output=True, timeout=20)
        first = _decode(cp.stdout or cp.stderr).strip().splitlines()
        return first[0][:120] if first else "found (no version output)"
    except (OSError, subprocess.SubprocessError):
        return "found (version check failed)"


def render_report(results: list[Result], meta: dict, home: str | None, secrets: list[str]) -> str:
    counts = {PASS: 0, FAIL: 0, SKIPPED: 0}
    for r in results:
        counts[r.status] += 1
    L: list[str] = []
    L.append("VANTA VERIFICATION REPORT")
    L.append("=" * 72)
    for k in ("started", "os", "python", "project", "ffmpeg", "node"):
        L.append(f"{k:<9}: {meta.get(k, '?')}")
    L.append("")
    verdict = "FAIL" if counts[FAIL] else ("PASS WITH SKIPS (skipped = NOT verified)" if counts[SKIPPED] else "PASS")
    L.append(f"OVERALL  : {verdict}   |  PASS {counts[PASS]}   FAIL {counts[FAIL]}   SKIPPED {counts[SKIPPED]}")
    L.append("")
    L.append("SUMMARY")
    L.append("-" * 72)
    for r in results:
        L.append(f"[{r.status:<7}] {r.step.title}  -  {r.reason}" + (f"  ({r.seconds:.0f}s)" if r.seconds >= 1 else ""))
    L.append("")
    L.append("WHAT THIS REPORT DOES NOT PROVE")
    L.append("-" * 72)
    L.append("* No browser/video-playback check, no live YouTube upload/OAuth, no human-rated clip-quality result.")
    L.append("* A SKIPPED line is NOT a pass. Fix the reason and rerun.")
    L.append("")
    L.append("DETAILS (last lines of output, secrets and your user folder removed)")
    L.append("=" * 72)
    for r in results:
        if r.status == PASS and r.step.group == "tests":
            continue   # passing unit-test modules are fully described by the summary
        L.append("")
        L.append(f"### {r.step.title}  [{r.status}]")
        if r.returncode is not None:
            L.append(f"exit code: {r.returncode}")
        L.append(redact(tail(r.output), home, secrets) or "(no output)")
    L.append("")
    L.append("END OF REPORT")
    return "\n".join(L) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default=DEFAULT_URL)
    ap.add_argument("--video")
    ap.add_argument("--skip-network", action="store_true")
    ap.add_argument("--skip-tests", action="store_true")
    ap.add_argument("--tests", help="comma-separated test modules")
    ap.add_argument("--test-timeout", type=int, default=1500)
    ap.add_argument("--report")
    ap.add_argument("--force-python-mode", action="store_true", help="(developers) run the python scripts instead of the .bat files, even on Windows")
    a = ap.parse_args(argv)

    root = Path(__file__).resolve().parents[1]
    report_path = Path(a.report) if a.report else root / "verify_report.txt"
    windows = os.name == "nt" and not a.force_python_mode
    steps = build_steps(root, sys.executable, url=a.url, video=a.video, skip_network=a.skip_network, skip_tests=a.skip_tests,
                        only_tests=[t.strip() for t in a.tests.split(",") if t.strip()] if a.tests else None,
                        test_timeout=a.test_timeout, windows=windows)
    for s in steps:   # defensive: the runner must never touch the scheduled task
        blob = s.cmd if isinstance(s.cmd, str) else " ".join(s.cmd or [])
        assert not any(t in blob.lower() for t in FORBIDDEN_TOKENS), f"forbidden step {s.key}"

    meta = {"started": time.strftime("%Y-%m-%d %H:%M:%S"), "os": f"{platform.system()} {platform.release()} ({platform.machine()})",
            "python": f"{platform.python_version()}  {sys.executable}", "project": str(root),
            "ffmpeg": tool_version(["ffmpeg", "-version"]), "node": tool_version(["node", "--version"])}
    home = str(Path.home())
    secrets = secret_values_from_env()
    base_env = dict(os.environ)
    base_env["PYTHONIOENCODING"] = "utf-8"
    results: list[Result] = []
    with tempfile.TemporaryDirectory(prefix="vanta-verify-") as tmp:
        for i, s in enumerate(steps, 1):
            print(f"[{i}/{len(steps)}] {s.title} ...", flush=True)
            env = test_env(base_env, tmp) if s.group == "tests" else base_env
            r = run_step(s, env)
            results.append(r)
            print(f"      -> {r.status}: {r.reason}", flush=True)
    text = render_report(results, meta, home, secrets)
    try:
        report_path.write_text(text, encoding="utf-8")
    except OSError as e:
        print(f"Could not write {report_path}: {e}\n\n" + text)
        return 1
    print(f"\nReport written to: {report_path}")
    overall = next((ln for ln in text.splitlines() if ln.startswith("OVERALL")), "")
    print(overall)
    return 1 if any(r.status == FAIL for r in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())

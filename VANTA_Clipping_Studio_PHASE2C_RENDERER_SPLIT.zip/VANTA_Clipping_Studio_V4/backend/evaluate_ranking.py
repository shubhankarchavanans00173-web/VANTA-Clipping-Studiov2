"""Compare the baseline heuristic ranker with the multi-signal engine on the controlled fixtures (and optional human labels).

    python evaluate_ranking.py                  # print the comparison
    python evaluate_ranking.py --write          # also write docs/EVALUATION.md
    python evaluate_ranking.py --labels my_labels.json   # add human-rated metrics: {"fixture_name": [{"start":..,"end":..,"label":"good"}, ...]}

The built-in fixtures are SYNTHETIC and developer-authored. They show whether the engine avoids known bad stretches; they do not prove
that it finds clips a human editor would prefer. Human ratings (via the UI or --labels) are what settle that.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.clipstudio import analysis  # noqa: E402
from app.clipstudio.selection import engine, evaluation as E  # noqa: E402
from evaluation.fixtures import all_fixtures  # noqa: E402

TARGET, COUNT = 30, 3
ROWS = [("inside_gold_rate", "Clips inside an annotated good moment", True), ("in_bad_stretch_rate", "Clips inside an annotated bad stretch", False),
        ("gold_moments_found", "Good moments found (of total)", True), ("mid_thought_start_rate", "Clips opening mid-thought", False),
        ("unfinished_end_rate", "Clips ending unfinished", False), ("overlap_rate", "Overlapping clip pairs", False),
        ("invalid_boundary_rate", "Invalid boundaries", False), ("within_duration_rate", "Within requested duration", True),
        ("diversity", "Topical diversity (1 = all different)", True)]


def run(labels: dict | None = None) -> dict:
    agg = {"baseline": {}, "multi-signal": {}}
    per = []
    for fx in all_fixtures():
        tr, dur = fx["transcript"], fx["duration"]
        lo, hi = analysis.length_bounds(TARGET, dur)
        base = [(c.start, c.end) for c in analysis.suggest_clips(dur, tr, [], [], TARGET, COUNT)]
        v2 = [(c.start, c.end) for c in engine.rank(dur, tr, [], [], TARGET, COUNT)[0]]
        entry = {"fixture": fx["name"], "clips": {}}
        for name, clips in (("baseline", base), ("multi-signal", v2)):
            m = {**E.structural_metrics(clips, dur, lo, hi, tr), **E.gold_metrics(clips, [(a, b) for a, b, _ in fx["gold"]], [(a, b) for a, b, _ in fx["bad"]])}
            if labels and fx["name"] in labels:
                m["human"] = E.labeled_metrics(clips, labels[fx["name"]])
            entry["clips"][name] = {"spans": [(round(a, 1), round(b, 1)) for a, b in clips], "metrics": m}
            for k, v in m.items():
                if isinstance(v, (int, float)):
                    agg[name].setdefault(k, []).append(v)
        per.append(entry)
    mean = lambda xs: round(sum(xs) / len(xs), 3)
    return {"per_fixture": per, "aggregate": {n: {k: (sum(v) if k.startswith("gold_moments") or k == "clips" else mean(v)) for k, v in d.items()} for n, d in agg.items()},
            "fixtures": len(per)}


def render(res: dict, labeled: bool) -> str:
    a = res["aggregate"]
    lines = [f"Fixtures: {res['fixtures']} synthetic transcripts, target {TARGET}s, top {COUNT} clips each ({a['baseline']['clips']} clips per ranker).", "",
             "| Metric | Baseline | Multi-signal | Better |", "|---|---|---|---|"]
    for key, label, higher in ROWS:
        b, n = a["baseline"].get(key), a["multi-signal"].get(key)
        if b is None or n is None:
            continue
        better = "tie" if b == n else ("multi-signal" if (n > b) == higher else "baseline")
        lines.append(f"| {label} | {b} | {n} | {better} |")
    lines += ["", "Per fixture clip spans (seconds):", ""]
    for e in res["per_fixture"]:
        lines.append(f"* **{e['fixture']}** baseline {e['clips']['baseline']['spans']} · multi-signal {e['clips']['multi-signal']['spans']}")
    lines += ["", "Sample size: " + ("human labels supplied; see per-fixture 'human' metrics in the JSON output." if labeled else
              "NO human ratings were used. Gold/bad spans were written by the developer together with the fixtures, so a win here shows the engine avoids known-bad "
              "stretches, not that a human editor prefers its clips. With 3 videos × 3 clips this is a smoke test, not statistical evidence.")]
    return "\n".join(lines)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--labels"); ap.add_argument("--write", action="store_true"); ap.add_argument("--json", action="store_true")
    ap.add_argument("--dataset", help="HUMAN-labelled real-video dataset JSON (see docs/CLIP_SELECTION_EVALUATION.md). Reported on its own; never merged with synthetic fixtures.")
    ap.add_argument("--export-pool", metavar="OUT.json", help="with --videos: write a label template containing the union of both rankers' top-K clips")
    ap.add_argument("--videos", help="JSON list of {id,duration,transcript[,split]} used by --export-pool")
    ap.add_argument("--target", type=float, default=30); ap.add_argument("--k", type=int, default=5)
    ns = ap.parse_args()
    from app.clipstudio.selection import dataset_eval as D
    if ns.export_pool:
        vids = json.loads(Path(ns.videos).read_text("utf-8")); D.export_pool(vids, ns.target, ns.k, Path(ns.export_pool)); print("wrote label template", ns.export_pool); sys.exit(0)
    if ns.dataset:
        try:
            res = D.evaluate(Path(ns.dataset))
        except D.DatasetError as error:
            print("ERROR:", error); sys.exit(2)
        print(json.dumps(res, indent=1) if ns.json else D.render(res)); sys.exit(0)
    labels = json.loads(Path(ns.labels).read_text("utf-8")) if ns.labels else None
    res = run(labels)
    print(json.dumps(res, indent=1) if ns.json else render(res, bool(labels)))
    if ns.write:
        out = Path(__file__).resolve().parent.parent / "docs" / "EVALUATION.md"
        out.write_text("# Ranking evaluation: baseline vs multi-signal engine\n\nGenerated by `python backend/evaluate_ranking.py --write`.\n\n" + render(res, bool(labels)) + "\n", "utf-8")
        print("wrote", out)

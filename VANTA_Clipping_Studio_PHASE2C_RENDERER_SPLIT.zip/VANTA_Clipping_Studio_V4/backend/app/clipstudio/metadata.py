"""Thumbnails and publish metadata (title / description / hashtags) for finished exports.

Honesty rules
* A thumbnail is always a REAL frame read back from the exported MP4. The "recommended" one is the sharpest non-dark frame:
  a technical measure, not a prediction of clicks.
* Suggested title / description / hashtags are built ONLY from the real transcript text of the clip. With no transcript nothing is
  invented: the fields stay empty and the user writes them. Every field records where it came from (transcript or user).
* Nothing here publishes anything.
"""
from __future__ import annotations

import re
import shutil
import subprocess
import unicodedata
from collections import Counter
from pathlib import Path

from PIL import Image, ImageFilter, ImageStat

from .transcript import Transcript

TITLE_MAX = 100          # YouTube limit
DESCRIPTION_MAX = 5000   # YouTube limit
HASHTAG_MAX = 15         # YouTube ignores all hashtags of a video that has more than 15
HASHTAG_LEN = 30

_STOP = set("""a about after again all also am an and any are as at be because been before being both but by can could did do does doing down during
each few for from further had has have having he her here hers him his how i if in into is it its just me more most my no nor not now of off on once only
or other our out over own same she should so some such than that the their them then there these they this those through to too under until up very was we
were what when where which while who whom why will with would you your yours yeah okay really actually basically kind sort like thing things stuff going
gonna want know think one two get got let lets say said much many even still""".split())



def _is_wordchar(ch: str) -> bool:
    """Letters AND combining marks: Python's \\w drops Devanagari vowel signs / virama (category M*), which would cut Hindi words apart."""
    return ch.isalpha() or unicodedata.category(ch).startswith("M")


def _words(text: str, min_len: int = 3) -> list[str]:
    out, cur = [], []
    for ch in text:
        if _is_wordchar(ch):
            cur.append(ch)
        else:
            if len(cur) >= min_len:
                out.append("".join(cur))
            cur = []
    if len(cur) >= min_len:
        out.append("".join(cur))
    return out


_SENT = re.compile(r"(?<=[.!?।])\s+")


# --------------------------------------------------------------------------- text suggestions
def clip_text(transcript: Transcript | None, start: float, end: float) -> str:
    if transcript is None or not transcript.available:
        return ""
    parts = [s.text.strip() for s in transcript.segments if s.end > start and s.start < end and s.text.strip()]
    return re.sub(r"\s+", " ", " ".join(parts)).strip()


def _cut(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0].rstrip(",;:-")
    return cut or text[:limit]


def clean_hashtags(tags) -> list[str]:
    """Accepts a list or a string ('#a #b, c'); returns unique '#tag' items without spaces/punctuation, in order."""
    if isinstance(tags, str):
        tags = [tags]
    tags = [p for item in tags or [] for p in re.split(r"[\s,]+", str(item))]   # "a b" in a list is two tags, like the string form
    out: list[str] = []
    for t in tags or []:
        t = "".join(ch for ch in str(t).lstrip("#") if _is_wordchar(ch) or ch.isdigit() or ch == "_")[:HASHTAG_LEN]
        if t and not t.isdigit() and ("#" + t).lower() not in {x.lower() for x in out}:
            out.append("#" + t)
    return out


def suggest(transcript: Transcript | None, start: float, end: float) -> dict:
    """Title/description/hashtags taken from the clip's real transcript text. Empty (with a message) when there is none."""
    text = clip_text(transcript, start, end)
    if not text:
        return {"title": "", "description": "", "hashtags": [], "available": False,
                "message": "This clip has no transcript text, so nothing can be suggested without making it up. Write the details yourself.",
                "provenance": {"source": "none"}}
    sentences = [s.strip() for s in _SENT.split(text) if s.strip()]
    first = next((s for s in sentences if len(s.split()) >= 3), sentences[0] if sentences else text)
    title = _cut(first.rstrip(".,;:!?-"), TITLE_MAX)
    description = _cut(text, 400)
    words = [w.lower() for w in _words(text)]
    freq = Counter(w for w in words if w not in _STOP)
    repeated = [w for w, n in freq.most_common() if n >= 2]
    rest = sorted((w for w in freq if freq[w] == 1 and len(w) >= 6), key=lambda w: (-len(w), w))
    tags = clean_hashtags((repeated + rest)[:5])
    return {"title": title, "description": description, "hashtags": tags, "available": True,
            "message": "Suggested from the transcript text of this clip. Edit anything before using it.",
            "provenance": {"source": "transcript", "clip_start": round(start, 2), "clip_end": round(end, 2),
                           "keywords": "most repeated non-filler words in the clip, then longer distinct words"}}


def validate(title: str, description: str, hashtags) -> dict:
    """Normalise and validate user-edited metadata. Raises ValueError with a message the UI can show."""
    title, description = (title or "").strip(), (description or "").strip()
    if len(title) > TITLE_MAX:
        raise ValueError(f"The title is {len(title)} characters; the limit is {TITLE_MAX}.")
    if len(description) > DESCRIPTION_MAX:
        raise ValueError(f"The description is {len(description)} characters; the limit is {DESCRIPTION_MAX}.")
    for label, value in (("title", title), ("description", description)):
        if "<" in value or ">" in value:
            raise ValueError(f"The {label} cannot contain < or > (YouTube rejects them).")
    tags = clean_hashtags(hashtags)
    if len(tags) > HASHTAG_MAX:
        raise ValueError(f"{len(tags)} hashtags: YouTube ignores all hashtags when there are more than {HASHTAG_MAX}.")
    return {"title": title, "description": description, "hashtags": tags}


# --------------------------------------------------------------------------- thumbnails
def _ffmpeg() -> str:
    exe = shutil.which("ffmpeg")
    if not exe:
        raise RuntimeError("FFmpeg was not found on PATH.")
    return exe


def grab_frame(video: Path, t: float, out: Path) -> Path:
    out.parent.mkdir(parents=True, exist_ok=True)
    out.unlink(missing_ok=True)
    r = subprocess.run([_ffmpeg(), "-y", "-hide_banner", "-nostdin", "-loglevel", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(video),
                        "-frames:v", "1", "-q:v", "2", str(out)], capture_output=True, text=True, timeout=120)
    if r.returncode != 0 or not out.is_file() or out.stat().st_size == 0:
        out.unlink(missing_ok=True)
        raise RuntimeError("Could not read a frame from the video at that time: " + (r.stderr or "")[-160:])
    return out


def frame_stats(path: Path) -> dict:
    """Sharpness = variance of an edge-filtered greyscale thumbnail; brightness = mean luma. Technical measures only."""
    with Image.open(path) as im:
        g = im.convert("L")
        g.thumbnail((320, 320))
        edges = g.filter(ImageFilter.FIND_EDGES)
        return {"sharpness": round(ImageStat.Stat(edges).var[0], 2), "brightness": round(ImageStat.Stat(g).mean[0], 1)}


def make_candidates(video: Path, out_dir: Path, duration: float, count: int = 5) -> list[dict]:
    """``count`` real frames evenly spread over the video (not at the very start/end). Returns metadata, best candidate flagged."""
    count = max(2, min(10, int(count)))
    if duration <= 0:
        raise RuntimeError("The export has no duration.")
    shutil.rmtree(out_dir, ignore_errors=True)
    out_dir.mkdir(parents=True)
    pad = min(0.5, duration / 10)
    span = max(duration - 2 * pad, 0.01)
    items = []
    for i in range(count):
        t = pad + span * (i + 0.5) / count
        name = f"t{i + 1}.jpg"
        grab_frame(video, t, out_dir / name)
        st = frame_stats(out_dir / name)
        items.append({"name": name, "time": round(t, 2), **st, "dark": st["brightness"] < 12})
    usable = [x for x in items if not x["dark"]] or items
    best = max(usable, key=lambda x: x["sharpness"])
    for x in items:
        x["recommended"] = x is best
    return items

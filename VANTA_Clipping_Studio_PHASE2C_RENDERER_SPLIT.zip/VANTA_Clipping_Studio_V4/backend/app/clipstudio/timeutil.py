"""Timestamp parsing/formatting and clip-range validation."""
from __future__ import annotations

import math
import re

MIN_CLIP_SECONDS = 3.0
MAX_CLIP_SECONDS = 180.0
TARGET_DURATIONS = (15, 30, 45, 60)


class TimeError(ValueError):
    """Raised for unparseable timestamps or invalid clip ranges."""


_CLOCK = re.compile(r"^(?:(\d+):)?(\d{1,2}):(\d{1,2})(?:[.,](\d{1,3}))?$")
_UNITS = re.compile(r"^(?:(\d+(?:\.\d+)?)h)?(?:(\d+(?:\.\d+)?)m)?(?:(\d+(?:\.\d+)?)s)?$")


def parse_timestamp(value) -> float:
    """Accept seconds (12, "12.5"), clock ("1:02", "01:02:03.250", "00:00:05,500") or "1m2s"."""
    if isinstance(value, bool):
        raise TimeError("Timestamp must be a number or text, not a boolean.")
    if isinstance(value, (int, float)):
        seconds = float(value)
    else:
        text = str(value or "").strip().lower()
        if not text:
            raise TimeError("Timestamp is empty.")
        if re.fullmatch(r"\d+(?:\.\d+)?", text):
            seconds = float(text)
        else:
            match = _CLOCK.match(text)
            if match:
                hours, minutes, secs, frac = match.groups()
                if int(minutes) > 59 and hours is not None or int(secs) > 59:
                    raise TimeError(f"Invalid clock timestamp: {value!r}.")
                seconds = int(hours or 0) * 3600 + int(minutes) * 60 + int(secs) + (int(frac.ljust(3, "0")) / 1000 if frac else 0)
            else:
                units = _UNITS.match(text)
                if not units or not any(units.groups()):
                    raise TimeError(f"Could not read timestamp {value!r}. Use seconds, mm:ss or hh:mm:ss.")
                h, m, s = (float(g) if g else 0.0 for g in units.groups())
                seconds = h * 3600 + m * 60 + s
    if not math.isfinite(seconds) or seconds < 0:
        raise TimeError("Timestamp must be a finite, non-negative number.")
    return round(float(seconds), 3)


def format_timestamp(seconds: float, millis: bool = True) -> str:
    total = max(0.0, float(seconds))
    ms = round(total * 1000)
    h, ms = divmod(ms, 3_600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    base = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
    return f"{base}.{ms:03d}" if millis else base


def validate_range(start, end, source_duration: float | None = None,
                   min_seconds: float = MIN_CLIP_SECONDS, max_seconds: float = MAX_CLIP_SECONDS) -> tuple[float, float]:
    """Parse and validate a clip range; returns (start, end) in seconds."""
    s, e = parse_timestamp(start), parse_timestamp(end)
    if e <= s:
        raise TimeError("The end time must be after the start time.")
    if source_duration is not None:
        if s >= source_duration:
            raise TimeError(f"Start ({format_timestamp(s)}) is beyond the end of the video ({format_timestamp(source_duration)}).")
        if e > source_duration + 0.05:
            raise TimeError(f"End ({format_timestamp(e)}) is beyond the end of the video ({format_timestamp(source_duration)}).")
        e = min(e, source_duration)
    length = e - s
    if length < min_seconds - 1e-6:
        raise TimeError(f"A clip must be at least {min_seconds:g} seconds long (this one is {length:.1f}s).")
    if length > max_seconds + 1e-6:
        raise TimeError(f"A Short can be at most {max_seconds:g} seconds long (this one is {length:.1f}s).")
    return s, round(e, 3)

"""Caption tracks for a trimmed clip.

Word timings are used ONLY when the transcript really contains them. Otherwise the track is
sentence-level (``granularity == "sentence"``) and no word timing is invented.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path

from ..captions import _ass_time, _bgr, _esc, _srt_time
from .transcript import Transcript

KeepSegments = list[tuple[float, float]]   # clip-relative (start, end) ranges that remain after silence removal


@dataclass
class CaptionStyle:
    mode: str = "word_highlight"        # "word_highlight" | "clean"
    font: str = "Arial"
    font_size_pct: float = 4.4          # % of output height
    position: str = "bottom"            # "bottom" | "middle" | "top"
    margin_pct: float = 14.0            # % of output height from the chosen edge (ignored for middle)
    color: str = "#FFFFFF"
    highlight_color: str = "#FFC83C"
    max_words_per_line: int = 3
    uppercase: bool = False
    background: bool = False
    background_opacity: float = 0.55

    @classmethod
    def from_dict(cls, data: dict | None) -> "CaptionStyle":
        data = data or {}
        s = cls()
        for key, value in data.items():
            if hasattr(s, key) and value is not None:
                setattr(s, key, type(getattr(s, key))(value) if not isinstance(getattr(s, key), bool) else bool(value))
        s.mode = s.mode if s.mode in {"word_highlight", "clean"} else "word_highlight"
        s.position = s.position if s.position in {"bottom", "middle", "top"} else "bottom"
        s.font_size_pct = min(10.0, max(2.0, s.font_size_pct))
        s.margin_pct = min(40.0, max(0.0, s.margin_pct))
        s.max_words_per_line = min(10, max(1, int(s.max_words_per_line)))
        s.background_opacity = min(1.0, max(0.0, s.background_opacity))
        return s

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class CaptionEvent:
    start: float
    end: float
    text: str
    words: list[tuple[str, float, float]] | None = None   # per-word timings (word-level tracks only)


@dataclass
class CaptionTrack:
    events: list[CaptionEvent] = field(default_factory=list)
    granularity: str = "none"        # "word" | "sentence" | "none"
    note: str = ""

    def to_dict(self) -> dict:
        return {"granularity": self.granularity, "note": self.note,
                "events": [{"start": round(e.start, 3), "end": round(e.end, 3), "text": e.text,
                            **({"words": [{"text": w, "start": round(a, 3), "end": round(b, 3)} for w, a, b in e.words]} if e.words else {})}
                           for e in self.events]}


def remap_time(t: float, keep: KeepSegments | None) -> float | None:
    """Map a clip-relative time onto the silence-removed timeline (None when it falls in a removed gap)."""
    if not keep:
        return t
    out = 0.0
    for a, b in keep:
        if a - 1e-9 <= t <= b + 1e-9:
            return out + (t - a)
        out += b - a
    return None


def kept_duration(clip_len: float, keep: KeepSegments | None) -> float:
    return clip_len if not keep else sum(b - a for a, b in keep)


def build_track(transcript: Transcript | None, clip_start: float, clip_end: float, keep: KeepSegments | None = None,
                max_words: int = 3, sentence_wrap: int = 6) -> CaptionTrack:
    """Captions for [clip_start, clip_end] of the source, re-timed to start at 0 (and to the silence-removed timeline)."""
    if transcript is None or not transcript.available:
        return CaptionTrack([], "none", "No transcript, so no captions can be generated.")
    clip_len = clip_end - clip_start
    if transcript.word_level:
        words: list[tuple[str, float, float]] = []
        for seg in transcript.segments:
            if seg.end < clip_start or seg.start > clip_end:
                continue
            for w in seg.words or []:
                mid = (w.start + w.end) / 2
                if not (clip_start <= mid <= clip_end):
                    continue
                a, b = remap_time(max(0.0, w.start - clip_start), keep), remap_time(min(clip_len, w.end - clip_start), keep)
                if a is None:
                    continue
                if b is None or b <= a:
                    b = a + max(0.08, w.end - w.start)
                words.append((w.text, a, b))
        pages = _paginate(words, max_words)
        events = [CaptionEvent(p[0][1], p[-1][2], " ".join(w[0] for w in p), p) for p in pages]
        return CaptionTrack(events, "word", "Word-level timings from the transcript.")
    events: list[CaptionEvent] = []
    estimated = 0
    for seg in transcript.segments:
        dur = max(1e-6, seg.end - seg.start)
        ov = min(seg.end, clip_end) - max(seg.start, clip_start)
        if ov <= 0.25:
            continue
        if ov >= 0.5 * dur:
            pieces = [(max(seg.start, clip_start), min(seg.end, clip_end), seg.text, False)]   # mostly inside: show the line as written
        else:
            # Only a small part of a long line is inside the clip. Word times are NOT known, so the visible slice is an
            # ESTIMATE by character position. It is flagged in the track note and never labelled as measured.
            pieces = [(a, b, t, True) for a, b, t in _slice_sentence(seg, clip_start, clip_end)]
        for a0, b0, text, est in pieces:
            a = remap_time(max(0.0, a0 - clip_start), keep)
            b = remap_time(min(clip_len, b0 - clip_start), keep)
            if a is None:
                continue
            if b is None or b <= a:
                b = a + 0.5
            events.append(CaptionEvent(a, b, text))
            estimated += 1 if est else 0
    events = _chunk_long_events(events, sentence_wrap)
    note = "Sentence-level fallback: this transcript has no word timings, so words are not highlighted individually."
    if estimated:
        note += f" {estimated} long line(s) only partly inside the clip were split proportionally by character position (estimated, not measured)."
    return CaptionTrack(events, "sentence", note)


def _slice_sentence(seg, clip_start: float, clip_end: float):
    """Words of a sentence-level segment whose *estimated* time (linear by characters) falls inside the clip."""
    words = seg.text.split()
    if not words:
        return []
    total = sum(len(w) + 1 for w in words)
    dur, cursor, spans = seg.end - seg.start, 0, []
    for w in words:
        a = seg.start + dur * cursor / total
        cursor += len(w) + 1
        spans.append((w, a, seg.start + dur * cursor / total))
    inside = [x for x in spans if clip_start <= (x[1] + x[2]) / 2 <= clip_end]
    return [(inside[0][1], inside[-1][2], " ".join(x[0] for x in inside))] if inside else []


def _chunk_long_events(events: list[CaptionEvent], max_chunk_words: int = 6) -> list[CaptionEvent]:
    """Split very long sentence events into readable chunks (<= ~2 lines). Timing is proportional to character count."""
    cap = max(20, max_chunk_words * 3)
    out: list[CaptionEvent] = []
    for ev in events:
        words = ev.text.split()
        if len(words) <= cap:
            out.append(ev)
            continue
        n_chunks = math.ceil(len(words) / cap)
        size = math.ceil(len(words) / n_chunks)
        chunks = [words[i:i + size] for i in range(0, len(words), size)]
        total = sum(len(w) + 1 for w in words)
        dur, cursor = ev.end - ev.start, 0
        for ch in chunks:
            n = sum(len(w) + 1 for w in ch)
            out.append(CaptionEvent(ev.start + dur * cursor / total, ev.start + dur * (cursor + n) / total, " ".join(ch)))
            cursor += n
    return out


def _paginate(words, max_words: int):
    pages, cur = [], []
    for w in words:
        if cur and w[1] - cur[-1][2] > 1.0:
            pages.append(cur); cur = []
        cur.append(w)
        if len(cur) >= max_words or re.search(r"[.!?;:]$", w[0]):
            pages.append(cur); cur = []
    if cur:
        pages.append(cur)
    return pages


def _wrap(text: str, per_line: int) -> str:
    ws = text.split()
    return "\\N".join(" ".join(ws[i:i + per_line]) for i in range(0, len(ws), per_line))


def write_ass(track: CaptionTrack, path: Path, width: int, height: int, style: CaptionStyle, font_family: str | None = None) -> None:
    size = round(height * style.font_size_pct / 100)
    outline = max(2, round(size * 0.09))
    align = {"bottom": 2, "middle": 5, "top": 8}[style.position]
    margin_v = 0 if style.position == "middle" else round(height * style.margin_pct / 100)
    margin_x = round(width * 0.06)
    primary, hi = _bgr(style.color, "FFFFFF"), _bgr(style.highlight_color, "FFC83C")
    alpha = f"{round((1 - style.background_opacity) * 255):02X}"
    back = f"&H{alpha}000000&"
    border_style, outline_col = (3, back) if style.background else (1, "&H00000000&")
    lines = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "WrapStyle: 0", "ScaledBorderAndShadow: yes", "",
             "[V4+ Styles]",
             "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
             f"Style: Main,{_esc(font_family or style.font) or 'Arial'},{size},{primary},{primary},{outline_col},{back},-1,0,0,0,100,100,0,0,{border_style},{outline if not style.background else max(6, outline * 2)},0,{align},{margin_x},{margin_x},{margin_v},1",
             "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    fix = (lambda s: _esc(s).upper()) if style.uppercase else _esc
    for ev in track.events:
        if track.granularity == "word" and style.mode == "word_highlight" and ev.words:
            for i, (word, start, end) in enumerate(ev.words):
                nxt = ev.words[i + 1][1] if i + 1 < len(ev.words) else end
                nxt = max(nxt, start + 0.08)
                parts = [f"{{\\c{hi}\\fscx108\\fscy108}}{fix(w[0])}{{\\r}}" if j == i else fix(w[0]) for j, w in enumerate(ev.words)]
                lines.append(f"Dialogue: 0,{_ass_time(start)},{_ass_time(nxt)},Main,,0,0,0,,{' '.join(parts)}")
        else:
            text = fix(ev.text)
            per_line = style.max_words_per_line if track.granularity == "word" else max(style.max_words_per_line, 5)
            lines.append(f"Dialogue: 0,{_ass_time(ev.start)},{_ass_time(max(ev.end, ev.start + 0.3))},Main,,0,0,0,,{{\\fad(60,60)}}{_wrap(text, per_line)}")
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_srt(track: CaptionTrack, path: Path) -> None:
    blocks = []
    for n, ev in enumerate(track.events, 1):
        blocks.append(f"{n}\n{_srt_time(ev.start)} --> {_srt_time(max(ev.end, ev.start + 0.3))}\n{ev.text}\n")
    Path(path).write_text("\n".join(blocks), encoding="utf-8")

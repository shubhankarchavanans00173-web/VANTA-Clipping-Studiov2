"""Clip suggestions: feedback, evaluation, edit, caption preview and clip SRT routes."""
from __future__ import annotations


from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .. import db, pipeline, settings
from ..selection import evaluation as sel_eval
from ..selection import llm_eval
from ..captions import build_track
from ..timeutil import TimeError, validate_range
from .common import _candidate, _project, _safe_name

router = APIRouter()


# ----------------------------------------------------------------------------- feedback / evaluation
class FeedbackRequest(BaseModel):
    label: str
    note: str | None = Field(None, max_length=300)


@router.put("/candidates/{cid}/feedback")
def put_feedback(cid: str, req: FeedbackRequest):
    _candidate(cid)
    try:
        return db.set_feedback(cid, req.label, req.note)
    except ValueError as error:
        raise HTTPException(400, str(error))


@router.delete("/candidates/{cid}/feedback")
def delete_feedback(cid: str):
    _candidate(cid)
    db.clear_feedback(cid)
    return {"ok": True}


@router.get("/evaluation/summary")
def evaluation_summary(project_id: str | None = None):
    """Counts of human ratings and whether there are enough of them to conclude anything. No model is trained from them."""
    rows = db.list_feedback(project_id)
    return {**sel_eval.summarize_feedback(rows), "labels": list(db.FEEDBACK_LABELS),
            "weight_sets": sel_eval.compare_weight_sets(rows, {"default": None})}


@router.get("/llm-status")
def llm_status():
    return llm_eval.status()


# ----------------------------------------------------------------------------- candidates
class CandidatePatch(BaseModel):
    start: str | float | None = None
    end: str | float | None = None
    status: str | None = None
    title: str | None = None


class CandidateCreate(BaseModel):
    start: str | float
    end: str | float
    title: str | None = None


def _duration_of(project: dict) -> float:
    return float((project.get("probe") or {}).get("duration") or 0) or 1e9


@router.post("/projects/{pid}/candidates")
def create_candidate(pid: str, req: CandidateCreate):
    p = _project(pid)
    try:
        s, e = validate_range(req.start, req.end, _duration_of(p))
    except TimeError as error:
        raise HTTPException(400, str(error))
    tr = pipeline.load_project_transcript(p)
    excerpt = ""
    if tr:
        excerpt = " ".join(seg.text for seg in tr.segments if seg.end > s and seg.start < e)
    return db.add_candidate(pid, s, e, None, "manual", ["Custom range chosen by you."], excerpt, rank=None, origin="custom", status="approved", title=req.title)


@router.patch("/candidates/{cid}")
def patch_candidate(cid: str, req: CandidatePatch):
    c = _candidate(cid)
    p = _project(c["project_id"])
    if c["status"] in {"queued", "rendering"}:
        raise HTTPException(409, "This clip is being rendered right now.")
    fields: dict = {}
    if req.start is not None or req.end is not None:
        try:
            s, e = validate_range(req.start if req.start is not None else c["start"], req.end if req.end is not None else c["end"], _duration_of(p))
        except TimeError as error:
            raise HTTPException(400, str(error))
        fields.update(start=s, end=e, edited=1)
        if c["status"] in {"rendered", "failed"}:
            fields["status"] = "approved"
        tr = pipeline.load_project_transcript(p)
        if tr:
            fields["excerpt"] = " ".join(seg.text for seg in tr.segments if seg.end > s and seg.start < e)
    if req.status is not None:
        if req.status not in {"suggested", "approved", "rejected"}:
            raise HTTPException(400, "Status must be suggested, approved or rejected.")
        fields["status"] = req.status
    if req.title is not None:
        fields["title"] = req.title[:120]
    db.update_candidate(cid, **fields)
    return db.get_candidate(cid)


@router.delete("/candidates/{cid}")
def remove_candidate(cid: str):
    c = _candidate(cid)
    if c["status"] in {"queued", "rendering"}:
        raise HTTPException(409, "This clip is being rendered right now.")
    db.delete_candidate(cid)
    return {"deleted": True}


@router.get("/candidates/{cid}/captions-preview")
def captions_preview(cid: str, max_words: int = 3):
    c = _candidate(cid)
    p = _project(c["project_id"])
    tr = pipeline.load_project_transcript(p)
    track = build_track(tr, c["start"], c["end"], None, max(1, min(10, max_words)))
    return {"start": c["start"], "end": c["end"], **track.to_dict()}


@router.get("/candidates/{cid}/srt")
def candidate_srt(cid: str):
    """Clip-relative .srt of the real transcript for a suggestion (usable before rendering). Sentence/word timings are exactly the transcript's."""
    c = _candidate(cid)
    p = _project(c["project_id"])
    tr = pipeline.load_project_transcript(p)
    if tr is None:
        raise HTTPException(409, "This project has no transcript, so there is nothing to export.")
    track = build_track(tr, c["start"], c["end"], None, 6)
    if not track.events:
        raise HTTPException(409, "The transcript has no text inside this clip.")
    tmp = settings.TMP_DIR / f"srt-{cid}.srt"
    try:
        from ..captions import write_srt
        write_srt(track, tmp)
        text = tmp.read_text(encoding="utf-8")
    finally:
        tmp.unlink(missing_ok=True)
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(text, headers={"Content-Disposition": f'attachment; filename="{_safe_name(p["name"])}_clip_{cid}.srt"'})

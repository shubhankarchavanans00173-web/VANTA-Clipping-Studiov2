"""Render, music upload and job routes."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from .. import db, media, pipeline, settings
from ..render import RenderError, RenderSettings
from .common import _project, _safe_name, _save_upload

router = APIRouter()


# ----------------------------------------------------------------------------- render
class RenderRequest(BaseModel):
    candidate_ids: list[str] | None = None
    settings: dict = Field(default_factory=dict)
    template_id: str | None = None


@router.post("/projects/{pid}/render")
def render(pid: str, req: RenderRequest):
    p = _project(pid)
    cands = db.list_candidates(pid)
    by_id = {c["id"]: c for c in cands}
    # "failed" = approved, then the render errored: a plain retry must include it
    ids = req.candidate_ids if req.candidate_ids is not None else [c["id"] for c in cands if c["status"] in {"approved", "failed"}]
    if not ids:
        raise HTTPException(409, "Nothing is approved yet. Approve at least one suggestion (approval is required before export).")
    for cid in ids:
        c = by_id.get(cid)
        if not c:
            raise HTTPException(404, f"Clip {cid} does not belong to this project.")
        if c["status"] not in {"approved", "failed"}:   # 'failed' = was approved, render errored; retry allowed
            raise HTTPException(409, f"Clip {cid} is '{c['status']}'. Only approved clips are exported.")
    merged = dict(req.settings)
    if req.template_id:
        tpl = next((t for t in db.list_templates() if t["id"] == req.template_id), None)
        if not tpl:
            raise HTTPException(404, "Template not found.")
        merged["caption_style"] = {**tpl["style"], **(merged.get("caption_style") or {})}
    try:
        RenderSettings.from_dict(merged)
        pipeline.resolve_music(merged.get("music_id"))
    except RenderError as error:
        raise HTTPException(400, str(error))
    if not p["source_path"]:
        raise HTTPException(409, "The source video has not been downloaded yet. Use Retry download (or Analyze) first.")
    try:
        return pipeline.submit_render(pid, ids, merged)
    except pipeline.Busy as error:
        raise HTTPException(409, str(error))


@router.post("/music")
async def upload_music(file: UploadFile = File(...)):
    mid = db.new_id()
    dest = settings.MUSIC_DIR / f"{mid}_{_safe_name(file.filename or 'music')}"
    size = await _save_upload(file, dest, settings.MUSIC_EXTENSIONS, 200 * 1024 ** 2, "music file")
    try:
        info = await run_in_threadpool(_probe_audio, dest)
    except media.MediaError as error:
        dest.unlink(missing_ok=True)
        raise HTTPException(400, str(error))
    return {"music_id": mid, "name": file.filename, "bytes": size, "duration": info}


def _probe_audio(path: Path) -> float:
    import json
    r = subprocess.run([shutil.which("ffprobe") or "ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
                       capture_output=True, text=True, timeout=60)
    try:
        data = json.loads(r.stdout or "{}")
    except ValueError:
        data = {}
    if r.returncode != 0 or not any(s.get("codec_type") == "audio" for s in data.get("streams", [])):
        raise media.MediaError("That file is not readable audio.")
    return float((data.get("format") or {}).get("duration") or 0)


# ----------------------------------------------------------------------------- jobs
@router.get("/jobs")
def jobs(limit: int = 100):
    out = []
    names = {p["id"]: p["name"] for p in db.list_projects()}
    for j in db.list_jobs(max(1, min(limit, 300))):
        j["project_name"] = names.get(j["project_id"])
        out.append(j)
    return out


@router.get("/jobs/{jid}")
def job(jid: str):
    j = db.get_job(jid)
    if not j:
        raise HTTPException(404, "Job not found.")
    return j


@router.post("/jobs/{jid}/cancel")
def cancel(jid: str):
    try:
        return pipeline.cancel_job(jid)
    except db.StateError as error:
        raise HTTPException(409, str(error))

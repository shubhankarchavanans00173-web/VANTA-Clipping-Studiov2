"""Route modules of the VANTA API; clipstudio/router.py assembles them under /api/vanta."""

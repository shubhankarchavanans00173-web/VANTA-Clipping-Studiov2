"""yt-dlp adapter for VANTA: URL normalisation, environment diagnostics, error classification, download runner and updater.

Design rules (see docs/YOUTUBE_SETUP.md):
  * yt-dlp is always run as ``<backend python> -m yt_dlp`` so the downloader, the updater and the diagnostics all talk about the
    *same* interpreter. A random ``yt-dlp.exe`` found on PATH is never used.
  * Errors are classified from yt-dlp's ``ERROR:`` lines only. ``WARNING:`` / ``Deprecated Feature:`` lines (for example the
    Python 3.10 deprecation notice that says "Please update to Python 3.11") are context, never a cause.
  * Nothing here bypasses private/login/age/DRM/geo restrictions, and no cookies are read or passed.
  * Downloads go to a staging directory, are validated by the caller, and only then become a source. Failed/cancelled downloads
    remove their staging directory.

Module layout (split from one 670-line file, behaviour unchanged): ytdlp_const, ytdlp_urls, ytdlp_errors, ytdlp_probe, ytdlp_proc hold
the pure/leaf pieces. This module keeps everything the tests patch (installed, version, base_command, diagnostics, download, update,
``subprocess``, ``shutil``, ``time``) so those patches still reach the code that calls them, and re-exports every old name.
"""
from __future__ import annotations

import errno  # noqa: F401  (kept: part of the old module namespace)
import importlib  # noqa: F401
import importlib.metadata
import importlib.util
import os
import platform
import re  # noqa: F401
import shutil
import signal  # noqa: F401
import subprocess
import sys
import threading
import time
from collections import deque  # noqa: F401
from dataclasses import dataclass  # noqa: F401
from datetime import date  # noqa: F401
from pathlib import Path
from typing import Callable
from urllib.parse import parse_qs, urlparse  # noqa: F401

from . import settings
from .linkerrors import LinkError
from .ytdlp_const import (ALLOWED_REMOTE_COMPONENTS, AUTO_RETRY_CODES, DEFAULT_FORMAT, JS_RUNTIMES, MEDIA_SUFFIXES, PIP_SPEC,  # noqa: F401
                          _JS_MIN_MAJOR)
from .ytdlp_urls import YOUTUBE_HOSTS, YouTubeRef, _VIDEO_ID, is_youtube_host, parse_youtube_url  # noqa: F401
from .ytdlp_errors import _ANSI, _JS_CONTEXT, _RULES, _SECRET_QS, classify_error, scrub, split_output  # noqa: F401
from .ytdlp_probe import (_CACHE, _CACHE_TTL, _cached, _major, _tool_version, _writable, ejs_version, ffmpeg_info,  # noqa: F401
                          js_runtime_info, reset_caches, version_age_days)
from .ytdlp_proc import (DownloadResult, RunOutput, _FORMATS, _INTERMEDIATE, _PCT, _child_env, _collect, _kill_tree,  # noqa: F401
                         _popen_kwargs, build_command, run_process)


def enabled() -> bool:
    return os.getenv("VANTA_ENABLE_YTDLP", "").strip().lower() in {"1", "true", "yes", "on"}


def installed() -> bool:
    return importlib.util.find_spec("yt_dlp") is not None


def version() -> str | None:
    """Installed yt-dlp version in *this* interpreter (metadata read, no subprocess)."""
    try:
        return importlib.metadata.version("yt-dlp")
    except importlib.metadata.PackageNotFoundError:
        return None



def base_command() -> list[str] | None:
    return [sys.executable, "-m", "yt_dlp"] if installed() else None


def install_command() -> str:
    return f'"{sys.executable}" -m pip install --upgrade "{PIP_SPEC}"'



def diagnostics() -> dict:
    """Everything needed to tell *why* a platform download can or cannot work. Contains no environment variables or secrets."""
    from ..config import ROOT
    ver = version()
    age = version_age_days(ver)
    js, ff = js_runtime_info(), ffmpeg_info()
    free = None
    try:
        free = shutil.disk_usage(settings.SOURCE_DIR).free
    except OSError:
        pass
    problems: list[str] = []
    warnings: list[str] = []
    if not installed():
        problems.append(f"yt-dlp is not installed in the backend Python environment. Run: {install_command()}")
    if not enabled():
        problems.append("Platform links are switched off. Set VANTA_ENABLE_YTDLP=1 in .env (or run enable_youtube_links.bat) and restart the backend.")
    if not ff["available"]:
        problems.append("FFmpeg/ffprobe not found on PATH. It is needed to merge video+audio and to validate downloads (winget install Gyan.FFmpeg).")
    if not _writable(settings.SOURCE_DIR):
        problems.append(f"Cannot write to the download folder {settings.SOURCE_DIR}.")
    if free is not None and free < settings.MAX_REMOTE_BYTES * 2:
        problems.append(f"Low disk space: {free / 1024 ** 3:.1f} GiB free; downloads need about {settings.MAX_REMOTE_BYTES * 2 / 1024 ** 3:.1f} GiB of headroom.")
    if installed() and not js["available"]:
        warnings.append(js["note"])
    if sys.version_info < (3, 11):
        warnings.append(f"Python {platform.python_version()} is older than yt-dlp's recommended 3.11+. yt-dlp prints a deprecation warning, which is harmless "
                        "for downloads and is NOT the cause of a failed video. See docs/YOUTUBE_SETUP.md for the optional migration.")
    if age is not None and age > 60:
        warnings.append(f"yt-dlp {ver} is {age} days old. YouTube changes often; use Update yt-dlp if downloads start failing with extraction errors.")
    if installed() and js["available"] and not ejs_version():
        warnings.append("yt-dlp-ejs (YouTube challenge solver scripts) is not installed. Use Update yt-dlp, which installs yt-dlp[default].")
    env_path = ROOT / ".env"
    return {
        "python": {"executable": sys.executable, "version": platform.python_version(), "in_virtualenv": sys.prefix != getattr(sys, "base_prefix", sys.prefix),
                   "platform": platform.platform()},
        "yt_dlp": {"installed": installed(), "version": ver, "age_days": age, "ejs_version": ejs_version(), "runs_as": base_command(),
                   "enabled": enabled(), "install_command": install_command()},
        "ffmpeg": ff, "js_runtime": js,
        "env_file": {"path": str(env_path), "exists": env_path.is_file()},
        "folders": {"sources": str(settings.SOURCE_DIR), "writable": _writable(settings.SOURCE_DIR), "free_bytes": free},
        "ready": installed() and enabled() and ff["available"] and not any(p.startswith("Cannot write") for p in problems),
        "problems": problems, "warnings": warnings,
    }



def check_disk(dest: Path) -> None:
    need = settings.MAX_REMOTE_BYTES * 2
    try:
        free = shutil.disk_usage(dest).free
    except OSError:
        return
    if free < need:
        raise LinkError("disk_full", f"Only {free / 1024 ** 3:.1f} GiB free; VANTA wants about {need / 1024 ** 3:.1f} GiB of headroom to download a video.",
                        hint="Free some disk space or lower VANTA_MAX_REMOTE_BYTES in .env, then Retry.")


def _int_env(name: str, default: int, lo: int, hi: int) -> int:
    try:
        return max(lo, min(hi, int(os.getenv(name, default))))
    except ValueError:
        return default


def download(url: str, staging: Path, *, progress: Callable[[float | None, str], None] = lambda p, m: None, cancelled: Callable[[], bool] = lambda: False,
             timeout: float | None = None, max_attempts: int | None = None, sleep: Callable[[float], None] = time.sleep,
             base: list[str] | None = None) -> DownloadResult:
    """Download one validated URL into ``staging``. Raises LinkError with a precise code; never returns a path that does not exist."""
    base = base or base_command()
    if not base:
        raise LinkError("adapter_missing", "yt-dlp is not installed in VANTA's Python environment.", hint=f"Run: {install_command()}  (or use Update yt-dlp in Video Links).")
    ff = ffmpeg_info()
    if not ff["available"]:
        raise LinkError("ffmpeg_missing", "FFmpeg/ffprobe were not found on PATH. They are required to merge streams and validate the download.",
                        hint="Install FFmpeg (winget install Gyan.FFmpeg), reopen the terminal, restart VANTA, then Retry.")
    staging.mkdir(parents=True, exist_ok=True)
    check_disk(staging)
    timeout = float(timeout if timeout is not None else _int_env("VANTA_YTDLP_TIMEOUT", 1800, 60, 24 * 3600))
    attempts = int(max_attempts if max_attempts is not None else _int_env("VANTA_YTDLP_ATTEMPTS", 2, 1, 4))
    js = js_runtime_info()
    rc_env = os.getenv("VANTA_YTDLP_REMOTE_COMPONENTS", "").strip()
    cmd = build_command(base, url, staging, max_filesize=settings.MAX_REMOTE_BYTES, ffmpeg_dir=ff["dir"], js_runtime_arg=js["arg"] if js["available"] else None,
                        remote_components=rc_env if rc_env in ALLOWED_REMOTE_COMPONENTS else None,
                        auto_subs=os.getenv("VANTA_YTDLP_AUTO_SUBS", "") == "1")
    last: LinkError | None = None
    for attempt in range(1, attempts + 1):
        state = {"streams": 1, "index": -1, "last_pct": 101.0}

        def on_line(line: str) -> None:
            m = _FORMATS.search(line)
            if m:
                state["streams"] = max(1, int(m[1]))
            if line.startswith("[download] Destination:"):
                state["index"] += 1
                state["last_pct"] = 0.0
            p = _PCT.search(line)
            if p:
                pct = float(p[1]) / 100.0
                n, i = state["streams"], max(0, state["index"])
                weight = (0.9, 0.1) if n == 2 else tuple([1.0 / n] * n)
                done = sum(weight[:i]) if i < len(weight) else 1.0
                frac = min(1.0, done + pct * (weight[i] if i < len(weight) else 0.0))
                progress(frac, f"Downloading {'video' if i == 0 and n == 2 else 'audio' if i == 1 and n == 2 else 'media'} · {float(p[1]):.0f}%"
                         + (f" (try {attempt}/{attempts})" if attempt > 1 else ""))
        try:
            progress(None, "Contacting the platform" + (f" (try {attempt}/{attempts})" if attempt > 1 else ""))
            res = run_process(cmd, timeout=timeout, cancelled=cancelled, on_stdout_line=on_line)
        except FileNotFoundError as error:
            raise LinkError("adapter_missing", "Could not start Python/yt-dlp.", hint=f"Run: {install_command()}") from error
        except OSError as error:
            if error.errno == errno.ENOSPC:
                raise LinkError("disk_full", "The disk is full, so the video could not be written.", hint="Free some space and Retry.") from error
            if error.errno in (errno.EACCES, errno.EPERM):
                raise LinkError("permission_denied", "VANTA is not allowed to start the downloader or write its folder.") from error
            raise LinkError("download_failed", f"Could not start the downloader: {type(error).__name__}.", retryable=True) from error
        except LinkError as error:
            last = error
            if error.code in AUTO_RETRY_CODES and attempt < attempts:
                sleep_with_cancel(2.0 * attempt, cancelled, sleep)
                continue
            raise
        if res.returncode == 0:
            found = _collect(staging, res.stdout)
            if found:
                found.attempts = attempt
                return found
            err = classify_error("\n".join(res.stderr), "\n".join(res.stdout), 0)
            if err.code == "unknown_error":
                err = LinkError("download_failed", "yt-dlp finished but produced no usable video file.", retryable=True,
                                hint="Retry. If it repeats, run Diagnostics or upload the file.", details=err.details)
            raise err
        err = classify_error("\n".join(res.stderr), "\n".join(res.stdout), res.returncode)
        last = err
        if err.code in AUTO_RETRY_CODES and attempt < attempts:
            sleep_with_cancel(2.0 * attempt, cancelled, sleep)
            continue
        raise err
    raise last or LinkError("download_failed", "The download failed.", retryable=True)


def sleep_with_cancel(seconds: float, cancelled: Callable[[], bool], sleep: Callable[[float], None] = time.sleep) -> None:
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        if cancelled():
            raise LinkError("cancelled", "Download cancelled.")
        sleep(min(0.25, max(0.0, end - time.monotonic())))


# ============================================================================ updater
class UpdateError(RuntimeError):
    def __init__(self, status: int, message: str, code: str = "update_failed"):
        super().__init__(message)
        self.status, self.code = status, code


_UPDATE_LOCK = threading.Lock()


def update(timeout: int = 300) -> dict:
    """Upgrade yt-dlp[default] in the interpreter that runs the backend. Pip's dry run goes first so a resolver conflict changes nothing."""
    if not _UPDATE_LOCK.acquire(blocking=False):
        raise UpdateError(409, "An update is already running.", "update_busy")
    try:
        before = version()
        common = [sys.executable, "-m", "pip", "install", "--upgrade", "--upgrade-strategy", "only-if-needed", "--disable-pip-version-check", "--no-input"]

        def pip(extra: list[str]) -> subprocess.CompletedProcess:
            try:
                return subprocess.run([*common, *extra, PIP_SPEC], capture_output=True, text=True, timeout=timeout, check=False, encoding="utf-8", errors="replace")
            except subprocess.TimeoutExpired as error:
                raise UpdateError(504, f"pip timed out after {timeout}s. Check your network and try again.", "update_timeout") from error
            except OSError as error:
                raise UpdateError(500, f"Could not start pip with {sys.executable}: {error.__class__.__name__}.", "update_failed") from error

        def last_line(r: subprocess.CompletedProcess) -> str:
            lines = [l.strip() for l in ((r.stderr or "") + "\n" + (r.stdout or "")).splitlines() if l.strip()]
            return scrub(lines[-1] if lines else "pip gave no error message", 240)

        dry = pip(["--dry-run"])
        if dry.returncode != 0:
            raise UpdateError(502, f"pip could not resolve {PIP_SPEC} for {sys.executable}; nothing was changed. {last_line(dry)}")
        real = pip([])
        if real.returncode != 0:
            raise UpdateError(502, f"pip failed to install {PIP_SPEC} into {sys.executable}: {last_line(real)}")
        importlib.invalidate_caches()
        reset_caches()
        installed_pkgs: list[str] = []
        for line in (real.stdout or "").splitlines():
            if line.startswith("Successfully installed"):
                installed_pkgs = line[len("Successfully installed"):].split()
        try:
            check = subprocess.run([sys.executable, "-m", "yt_dlp", "--version"], capture_output=True, text=True, timeout=30, check=False, encoding="utf-8", errors="replace")
        except (OSError, subprocess.SubprocessError) as error:
            raise UpdateError(500, "pip reported success, but yt-dlp could not be started afterwards.") from error
        after = (check.stdout or "").strip().splitlines()[0] if check.returncode == 0 and (check.stdout or "").strip() else None
        if not after:
            raise UpdateError(500, "pip reported success, but VANTA could not verify the installed yt-dlp version.")
        changed = bool(before and before != after) or before is None
        others = [p for p in installed_pkgs if not p.lower().startswith(("yt-dlp-", "yt_dlp"))]
        msg = (f"yt-dlp {before or 'not installed'} → {after} in {sys.executable}." if changed else f"yt-dlp {after} is already the newest version for {sys.executable}.")
        return {"ok": True, "executable": sys.executable, "previous_version": before, "version": after, "changed": changed, "installed_packages": installed_pkgs,
                "other_packages_changed": others, "restart_required": False,
                "message": msg + " The new version is used by the next download; no restart is needed."}
    finally:
        _UPDATE_LOCK.release()

"""Editable settings: a whitelist of ``.env`` keys with validation, an atomic write that keeps comments/encoding/line endings,
and secrets that can be written or cleared but are never read back.

Honesty rule: the backend reads these variables once at start-up, so every change is labelled "restart required" and the
UI shows both the saved value and the value the running process is actually using. Nothing here mutates ``os.environ``.
"""
from __future__ import annotations

import os
import re
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..envload import parse_env, read_env_text


class SettingsError(ValueError):
    """Raised with ``errors`` = {KEY: message}. Nothing is written when any field is invalid."""

    def __init__(self, errors: dict[str, str]):
        super().__init__("; ".join(f"{k}: {v}" for k, v in errors.items()))
        self.errors = errors


@dataclass(frozen=True)
class Field_:
    key: str
    label: str
    group: str
    kind: str                       # bool | int | float | choice | text | url
    default: str = ""
    help: str = ""
    minimum: float | None = None
    maximum: float | None = None
    choices: tuple[str, ...] = ()
    secret: bool = False
    allow_empty: bool = True
    apply: str = "restart"          # every variable is read at import time, so "restart" is the honest label


def _whisper_models() -> tuple[str, ...]:
    try:
        from . import whisper_local
        return tuple(whisper_local.MODEL_INFO)
    except Exception:  # pragma: no cover - optional dependency path
        return ("tiny", "base", "small", "medium", "large-v3")


def fields() -> list[Field_]:
    return [
        Field_("VANTA_ENABLE_YTDLP", "Allow downloading from video links", "Links", "bool", "0", "Uses yt-dlp for public videos you may use."),
        Field_("VANTA_YTDLP_TIMEOUT", "Download timeout (seconds)", "Links", "int", "1800", minimum=60, maximum=14400),
        Field_("VANTA_YTDLP_ATTEMPTS", "Download attempts", "Links", "int", "2", "Retries only for transient network errors.", minimum=1, maximum=5),
        Field_("VANTA_YTDLP_AUTO_SUBS", "Fetch platform captions when available", "Links", "bool", "1"),
        Field_("VANTA_WHISPER_MODEL", "Transcription model", "Transcription", "choice", "small", "Models are downloaded only after you approve it in AI Models.", choices=_whisper_models()),
        Field_("VANTA_WHISPER_DEVICE", "Transcription device", "Transcription", "choice", "auto", choices=("auto", "cpu", "cuda")),
        Field_("VANTA_WHISPER_THREADS", "Transcription CPU threads (0 = automatic)", "Transcription", "int", "0", minimum=0, maximum=64),
        Field_("VANTA_MAX_UPLOAD_BYTES", "Largest upload (bytes)", "Limits", "int", str(4 * 1024 ** 3), minimum=1_000_000, maximum=100 * 1024 ** 3),
        Field_("VANTA_MAX_DURATION_SECONDS", "Longest video (seconds)", "Limits", "int", str(4 * 3600), minimum=60, maximum=48 * 3600),
        Field_("VANTA_MAX_REMOTE_BYTES", "Largest linked download (bytes)", "Limits", "int", str(1024 ** 3), minimum=1_000_000, maximum=100 * 1024 ** 3),
        Field_("VANTA_RESUME_JOBS", "Continue interrupted renders/downloads after a restart", "Reliability", "bool", "1"),
        Field_("VANTA_MAX_RESUMES", "Max automatic resumes in a row", "Reliability", "int", "2", minimum=0, maximum=10),
        Field_("VANTA_CLOUD_AI_ENABLED", "Allow optional cloud ranking (paid; always asks first)", "AI", "bool", "0", "Still needs a key and a model name, and each call is confirmed with a cost estimate."),
        Field_("VANTA_LOCAL_LLM", "Local re-ranking engine", "AI", "choice", "", "Empty = off.", choices=("", "ollama")),
        Field_("VANTA_LOCAL_LLM_MODEL", "Local model name", "AI", "text", "", "Example: qwen2.5:3b-instruct"),
        Field_("VANTA_OLLAMA_URL", "Ollama address", "AI", "url", "http://127.0.0.1:11434", "Must be a local address."),
        Field_("VANTA_LLM_TOP_N", "Candidates re-ranked by the local model", "AI", "int", "8", minimum=1, maximum=30),
        Field_("VANTA_LLM_TIMEOUT", "Local model timeout (seconds)", "AI", "int", "120", minimum=5, maximum=1800),
        Field_("ANTHROPIC_API_KEY", "Anthropic API key", "Secrets", "text", secret=True, help="Write-only. Used only by the optional cloud ranking."),
        Field_("PEXELS_API_KEY", "Pexels API key", "Secrets", "text", secret=True, help="Write-only. Used only by the legacy studio."),
        Field_("REPLICATE_API_TOKEN", "Replicate API token", "Secrets", "text", secret=True, help="Write-only. Used only by the legacy studio."),
    ]


def by_key() -> dict[str, Field_]:
    return {f.key: f for f in fields()}


# ----------------------------------------------------------------------------- locating and reading the file
def env_path() -> Path:
    override = os.getenv("VANTA_ENV_FILE")
    if override:
        return Path(override)
    return Path(__file__).resolve().parents[3] / ".env"


def _read(path: Path) -> tuple[str, str, str]:
    """Return (text, encoding to write back, newline)."""
    if not path.is_file():
        return "", "utf-8", "\r\n" if os.name == "nt" else "\n"
    raw = path.read_bytes()
    if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
        enc = "utf-16"
    elif raw.startswith(b"\xef\xbb\xbf"):
        enc = "utf-8-sig"
    else:
        try:
            raw.decode("utf-8")
            enc = "utf-8"
        except UnicodeDecodeError:
            enc = "cp1252"
    text = read_env_text(path)
    nl = "\r\n" if "\r\n" in text else "\n"
    return text, enc, nl


def saved_values(path: Path | None = None) -> dict[str, str]:
    p = path or env_path()
    return parse_env(read_env_text(p)) if p.is_file() else {}


# ----------------------------------------------------------------------------- validation
_TRUE, _FALSE = {"1", "true", "yes", "on"}, {"0", "false", "no", "off"}
_SECRET_RE = re.compile(r"^[A-Za-z0-9._\-:/+=~]{8,500}$")
_LOCAL_HOSTS = {"127.0.0.1", "localhost", "::1", "[::1]"}


def normalise(f: Field_, value: Any) -> str:
    """Return the string to store, or raise ValueError with a human message."""
    if f.secret:
        s = str(value).strip()
        if not _SECRET_RE.match(s):
            raise ValueError("Looks malformed: 8-500 characters, letters/digits and . _ - : / + = ~ only, no spaces or quotes.")
        return s
    s = ("1" if value is True else "0" if value is False else str(value if value is not None else "")).strip()
    if "\n" in s or "\r" in s or "\x00" in s:
        raise ValueError("Must be a single line.")
    if f.kind == "bool":
        low = s.lower()
        if low in _TRUE:
            return "1"
        if low in _FALSE:
            return "0"
        raise ValueError("Choose on or off.")
    if f.kind in {"int", "float"}:
        try:
            n = int(s) if f.kind == "int" else float(s)
        except ValueError:
            raise ValueError("Enter a whole number." if f.kind == "int" else "Enter a number.") from None
        if f.minimum is not None and n < f.minimum or f.maximum is not None and n > f.maximum:
            raise ValueError(f"Must be between {f.minimum:g} and {f.maximum:g}.")
        return str(n)
    if f.kind == "choice":
        if s not in f.choices:
            raise ValueError("Choose one of: " + ", ".join(c or "(off)" for c in f.choices))
        return s
    if f.kind == "url":
        m = re.match(r"^https?://([^/:?#]+|\[[^\]]+\])(:\d{1,5})?(/[^\s]*)?$", s)
        if not m or m.group(1).lower() not in _LOCAL_HOSTS:
            raise ValueError("Must be a local address like http://127.0.0.1:11434.")
        return s
    # text
    if len(s) > 200 or '"' in s or "'" in s or "#" in s:
        raise ValueError("Up to 200 characters; no quotes or # characters.")
    return s


def validate(changes: dict[str, Any], clear: list[str] | None = None) -> tuple[dict[str, str | None], dict[str, str]]:
    """changes: KEY -> new value, or None meaning "remove my override (use the default)". Returns (to_apply, errors)."""
    known = by_key()
    apply: dict[str, str | None] = {}
    errors: dict[str, str] = {}
    for key, value in (changes or {}).items():
        f = known.get(key)
        if f is None:
            errors[key] = "This setting cannot be edited here."
            continue
        if value is None:
            apply[key] = None
            continue
        if f.secret and value == "":
            errors[key] = "Leave it out to keep the current key, or use Clear to remove it."
            continue
        try:
            apply[key] = normalise(f, value)
        except ValueError as e:
            errors[key] = str(e)
    for key in clear or []:
        f = known.get(key)
        if f is None or not f.secret:
            errors[key] = "Only secret settings can be cleared this way."
        else:
            apply[key] = None
    return apply, errors


# ----------------------------------------------------------------------------- writing
def _fmt(value: str) -> str:
    return f'"{value}"' if re.search(r"\s", value) else value


def _key_of(line: str) -> tuple[str, bool] | None:
    """(key, is_commented) for ``KEY=...`` or ``# KEY=...`` lines; None for anything else."""
    m = re.match(r"^\s*(#\s*)?(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=", line)
    return (m.group(2), bool(m.group(1))) if m else None


def apply_to_text(text: str, changes: dict[str, str | None], nl: str = "\n") -> str:
    """Pure function: update/append/remove the given keys, leaving every other line exactly as it was.

    For each key: the first active ``KEY=`` line is rewritten (or removed when the new value is None) and any further active
    duplicates are dropped (the loader lets the LAST duplicate win, so leaving them would silently undo the edit); with no
    active line, the first ``# KEY=`` example line is uncommented in place; otherwise the key is appended at the end."""
    lines = text.splitlines()
    out: list[str] = []
    seen_active: set[str] = set()
    for line in lines:
        k = _key_of(line)
        if k and not k[1] and k[0] in changes:
            key = k[0]
            if key in seen_active:
                continue                          # duplicate active line: drop
            seen_active.add(key)
            if changes[key] is not None:
                out.append(f"{key}={_fmt(changes[key])}")
            continue
        out.append(line)
    pending = {k: v for k, v in changes.items() if k not in seen_active and v is not None}
    for i, line in enumerate(out):
        k = _key_of(line)
        if k and k[1] and k[0] in pending:
            out[i] = f"{k[0]}={_fmt(pending.pop(k[0]))}"
    if pending:
        if out and out[-1].strip():
            out.append("")
        out.append("# --- Added by VANTA Settings ---")
        out.extend(f"{k}={_fmt(v)}" for k, v in pending.items())
    return nl.join(out) + nl


def save(changes: dict[str, str | None], path: Path | None = None) -> dict:
    """Atomically write validated ``changes``. Keeps one backup next to the file. Returns {"path", "backup", "keys"}."""
    p = path or env_path()
    text, enc, nl = _read(p)
    new_text = apply_to_text(text, changes, nl)
    backup = None
    if p.is_file():
        backup = p.with_name(p.name + ".bak")
        backup.write_bytes(p.read_bytes())
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".env-", suffix=".tmp", dir=str(p.parent))
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(new_text.encode(enc))
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, p)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return {"path": str(p), "backup": str(backup) if backup else None, "keys": sorted(changes), "saved_at": time.strftime("%Y-%m-%d %H:%M:%S")}


# ----------------------------------------------------------------------------- what the UI sees
def describe(path: Path | None = None, environ: dict[str, str] | None = None) -> dict:
    """Saved value, running value and metadata for every editable field. Secret values are NEVER included, only whether one is set."""
    p = path or env_path()
    saved = saved_values(p)
    env = os.environ if environ is None else environ
    out = []
    for f in fields():
        item: dict[str, Any] = {"key": f.key, "label": f.label, "group": f.group, "kind": f.kind, "help": f.help, "default": "" if f.secret else f.default,
                                "secret": f.secret, "apply": f.apply, "min": f.minimum, "max": f.maximum, "choices": list(f.choices)}
        if f.secret:
            item["saved_set"] = bool(saved.get(f.key))
            item["running_set"] = bool(env.get(f.key))
            item["pending_restart"] = item["saved_set"] != item["running_set"]
        else:
            item["saved"] = saved.get(f.key)
            item["running"] = env.get(f.key)
            eff_saved = saved.get(f.key, f.default)
            eff_running = env.get(f.key, f.default) if env.get(f.key) is not None else f.default
            item["pending_restart"] = str(eff_saved).strip() != str(eff_running).strip()
        out.append(item)
    return {"env_file": str(p), "exists": p.is_file(), "restart_required": any(i["pending_restart"] for i in out), "fields": out}

"""YouTube URL normalisation (split from ytdlp.py; re-exported there)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import parse_qs, urlparse

from .linkerrors import LinkError

# ============================================================================ YouTube URL handling
YOUTUBE_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be", "www.youtu.be",
                 "youtube-nocookie.com", "www.youtube-nocookie.com"}
_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")


@dataclass(frozen=True)
class YouTubeRef:
    video_id: str
    canonical: str
    kind: str            # watch | short_link | shorts | embed | live


def is_youtube_host(host: str | None) -> bool:
    return (host or "").lower().rstrip(".") in YOUTUBE_HOSTS     # "www.youtube.com." (trailing dot) is the same host


def parse_youtube_url(url: str) -> YouTubeRef:
    """Return the video id and canonical URL for a watch / youtu.be / Shorts / embed / live link, or raise LinkError."""
    p = urlparse(url)
    host = (p.hostname or "").lower().rstrip(".")
    if host not in YOUTUBE_HOSTS:
        raise LinkError("unsupported_platform", "That is not a YouTube link.")
    parts = [x for x in p.path.split("/") if x]
    vid: str | None = None
    kind = "watch"
    if host in {"youtu.be", "www.youtu.be"}:
        kind, vid = "short_link", (parts[0] if parts else None)
    elif not parts:
        raise LinkError("invalid_url", "That YouTube link has no video in it. Paste a link to one video.")
    elif parts[0] == "watch":
        vid = (parse_qs(p.query).get("v") or [None])[0]
    elif parts[0] in {"shorts", "embed", "live", "v"} and len(parts) > 1:
        kind, vid = {"shorts": "shorts", "embed": "embed", "live": "live", "v": "embed"}[parts[0]], parts[1]
        if vid == "videoseries":
            raise LinkError("unsupported_platform", "Embedded playlists are not supported. Paste a link to a single video.")
    elif parts[0] in {"playlist", "channel", "c", "user", "feed", "results", "hashtag"} or parts[0].startswith("@"):
        raise LinkError("unsupported_platform", "Playlists, channels and search pages are not supported. Paste a link to a single video.",
                        hint="Open the video itself and copy its address.")
    if not vid or not _VIDEO_ID.match(vid):
        raise LinkError("invalid_url", "Could not find a valid 11-character YouTube video id in that link.",
                        hint="Use a normal link such as https://www.youtube.com/watch?v=… , https://youtu.be/… or a /shorts/… link.")
    return YouTubeRef(vid, f"https://www.youtube.com/watch?v={vid}", kind)

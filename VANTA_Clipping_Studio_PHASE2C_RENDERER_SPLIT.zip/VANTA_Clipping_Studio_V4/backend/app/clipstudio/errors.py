"""Render-related exceptions (shared by render.py and capfx.py to avoid import cycles)."""
from __future__ import annotations


class RenderError(RuntimeError):
    code = "render_failed"


class RenderCancelled(RenderError):
    code = "cancelled"


class CaptionError(RenderError):
    """Captions were requested but could not be produced or verified. ``code`` is machine readable."""

    def __init__(self, message: str, code: str = "caption_failed"):
        super().__init__(message)
        self.code = code

"""Evaluation metrics for clip rankings: structural (no labels needed), gold-span (fixtures), and human-label (ratings) metrics.

Nothing here trains a model. Human ratings are only used to *measure* and to compare weight sets, and the report states when the
sample is too small to conclude anything.
"""
from __future__ import annotations

from ..analysis import build_units
from ..transcript import Transcript
from . import lexicon as L
from . import scoring

LABELS = ("excellent", "good", "weak", "incomplete", "repetitive", "missing_context")
GRADE = {"excellent": 3, "good": 2, "weak": 0, "incomplete": 0, "repetitive": 0, "missing_context": 0}
COHERENT = {"excellent", "good"}
NOT_SELF_CONTAINED = {"incomplete", "missing_context"}
MIN_RATED_FOR_CONCLUSIONS = 30
SPAN_MATCH_IOU = 0.6


def _iou(a: tuple[float, float], b: tuple[float, float]) -> float:
    inter = max(0.0, min(a[1], b[1]) - max(a[0], b[0]))
    union = (a[1] - a[0]) + (b[1] - b[0]) - inter
    return inter / union if union > 0 else 0.0


def _inside(clip: tuple[float, float], span: tuple[float, float]) -> float:
    inter = max(0.0, min(clip[1], span[1]) - max(clip[0], span[0]))
    return inter / max(1e-6, clip[1] - clip[0])


def structural_metrics(clips: list[tuple[float, float]], duration: float, min_len: float, max_len: float,
                       transcript: Transcript | None = None) -> dict:
    n = len(clips)
    if n == 0:
        return {"clips": 0}
    pairs = [(a, b) for i, a in enumerate(clips) for b in clips[i + 1:]]
    overlapping = sum(1 for a, b in pairs if _inside(a, b) > 0.15 or _inside(b, a) > 0.15)
    invalid = sum(1 for s, e in clips if s < 0 or e <= s or e > duration + 0.01)
    in_range = sum(1 for s, e in clips if min_len - 0.01 <= e - s <= max_len + 0.01)
    out = {"clips": n, "overlap_rate": round(overlapping / len(pairs), 3) if pairs else 0.0,
           "invalid_boundary_rate": round(invalid / n, 3), "within_duration_rate": round(in_range / n, 3)}
    if transcript is not None and transcript.available:
        units = build_units(transcript)
        bad_open = bad_end = 0
        for s, e in clips:
            first = next((u for u in units if u.end > s + 0.3), None)
            last = next((u for u in reversed(units) if u.start < e - 0.3), None)
            if first is None or first.start < s - 0.6 or L.DANGLING.search(first.text) or L.FILLER_START.match(first.text):
                bad_open += 1
            if last is None or last.end > e + 0.6 or not L.ends_terminal(last.text):
                bad_end += 1
        out["mid_thought_start_rate"] = round(bad_open / n, 3)
        out["unfinished_end_rate"] = round(bad_end / n, 3)
        sims = []
        for a, b in pairs:
            ta = set(L.content_words(" ".join(u.text for u in units if a[0] <= u.start and u.end <= a[1])))
            tb = set(L.content_words(" ".join(u.text for u in units if b[0] <= u.start and u.end <= b[1])))
            sims.append(len(ta & tb) / len(ta | tb) if ta and tb else 0.0)
        out["diversity"] = round(1 - sum(sims) / len(sims), 3) if sims else 1.0
    return out


def gold_metrics(clips: list[tuple[float, float]], gold: list[tuple[float, float]], bad: list[tuple[float, float]]) -> dict:
    """Fixture check: how many chosen clips sit inside developer-annotated good moments / bad stretches (NOT human ratings)."""
    n = len(clips)
    if n == 0:
        return {"clips": 0}
    hit = sum(1 for c in clips if any(_inside(c, g) >= 0.8 for g in gold))
    miss = sum(1 for c in clips if any(_inside(c, b) >= 0.5 for b in bad))
    found = sum(1 for g in gold if any(_inside(c, g) >= 0.6 or _iou(c, g) >= 0.5 for c in clips))
    return {"clips": n, "inside_gold_rate": round(hit / n, 3), "in_bad_stretch_rate": round(miss / n, 3),
            "gold_moments_found": found, "gold_moments_total": len(gold)}


def labeled_metrics(clips: list[tuple[float, float]], labels: list[dict], k: int | None = None) -> dict:
    """Join clips to human labels by time overlap (IoU ≥ 0.6) and summarise. Unrated clips are counted, never guessed."""
    use = clips[:k] if k else clips
    got = []
    for c in use:
        best = max(labels, key=lambda l: _iou(c, (l["start"], l["end"])), default=None)
        if best is not None and _iou(c, (best["start"], best["end"])) >= SPAN_MATCH_IOU:
            got.append(best["label"])
    out = {"clips": len(use), "rated": len(got), "unrated": len(use) - len(got)}
    if got:
        out.update(mean_grade=round(sum(GRADE[g] for g in got) / len(got), 2),
                   pct_coherent=round(100 * sum(g in COHERENT for g in got) / len(got), 1),
                   pct_self_contained=round(100 * sum(g not in NOT_SELF_CONTAINED for g in got) / len(got), 1))
    return out


def sample_note(n_rated: int) -> str:
    if n_rated == 0:
        return "No human ratings yet: ranking quality is unverified. Rate clips as Excellent/Good/Weak/Incomplete/Repetitive/Missing context to measure it."
    if n_rated < MIN_RATED_FOR_CONCLUSIONS:
        return f"Only {n_rated} rated clip(s); at least {MIN_RATED_FOR_CONCLUSIONS} are needed before differences mean anything. Treat these numbers as anecdotes."
    return f"{n_rated} rated clips: enough to see large differences, still small for fine-grained conclusions."


def summarize_feedback(rows: list[dict]) -> dict:
    by_label: dict[str, int] = {}
    by_engine: dict[str, list[int]] = {}
    for r in rows:
        by_label[r["label"]] = by_label.get(r["label"], 0) + 1
        by_engine.setdefault(r.get("engine") or "unknown", []).append(GRADE[r["label"]])
    n = len(rows)
    return {"rated": n, "by_label": by_label,
            "by_engine": {e: {"rated": len(g), "mean_grade": round(sum(g) / len(g), 2)} for e, g in by_engine.items()},
            "note": sample_note(n)}


def compare_weight_sets(rows: list[dict], sets: dict[str, dict | None]) -> dict:
    """Pairwise ordering accuracy (0.5 = chance) of each weight set on rated clips, from stored feature snapshots only."""
    rated = [r for r in rows if r.get("features") and r["label"] in GRADE]
    note = sample_note(len(rated))
    out = {}
    for name, w in sets.items():
        feats = [{k: {"value": v} for k, v in r["features"].items()} for r in rated]
        scores = [scoring.combine(f, scoring.weights(w))["score"] for f in feats]
        good = total = 0
        for i in range(len(rated)):
            for j in range(i + 1, len(rated)):
                gi, gj = GRADE[rated[i]["label"]], GRADE[rated[j]["label"]]
                if gi == gj:
                    continue
                total += 1
                good += (scores[i] > scores[j]) == (gi > gj) if scores[i] != scores[j] else 0.5
        out[name] = round(good / total, 3) if total else None
    return {"pairwise_accuracy": out, "rated": len(rated), "note": note}

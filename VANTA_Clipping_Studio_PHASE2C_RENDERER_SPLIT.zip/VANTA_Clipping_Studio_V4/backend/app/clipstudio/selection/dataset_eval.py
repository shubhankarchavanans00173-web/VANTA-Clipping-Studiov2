"""Evaluation of rankers against HUMAN-labelled real videos (never against the synthetic fixtures).

Dataset JSON (see docs/CLIP_SELECTION_EVALUATION.md):
{"dataset": {"name", "kind": "human", "annotator", "notes"},
 "settings": {"target": 30, "k": 5, "tuned_on_split": null | "dev" | "test"},
 "videos": [{"id", "duration", "transcript": "<srt|vtt|json path, relative to the dataset file>", "split": "dev" | "test",
             "labels": [{"start", "end", "label"}], "good_moments_exhaustive": false}]}

Metrics are computed per ranker. Clips without a human label are counted as ``unrated`` and are NEVER assumed good or bad:
precision/acceptance use rated clips only, NDCG treats unrated as grade 0 (and reports the rated share so the bias is visible).
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from .. import analysis
from ..transcript import Transcript, load_transcript_file
from . import engine
from . import evaluation as E

LABELS = E.LABELS
GOOD = E.COHERENT                   # excellent / good
RANKERS = ("baseline", "multi-signal")
MIN_CLIPS_FOR_CONCLUSIONS = 30


class DatasetError(ValueError):
    pass


def load_dataset(path: Path) -> dict:
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise DatasetError(f"Cannot read dataset {path}: {error}") from error
    meta = data.get("dataset") or {}
    if meta.get("kind") != "human":
        raise DatasetError('dataset.kind must be "human". Synthetic fixtures are evaluated separately by evaluate_ranking.py and are never mixed in.')
    vids = data.get("videos")
    if not isinstance(vids, list) or not vids:
        raise DatasetError("The dataset needs a non-empty 'videos' list.")
    ids = set()
    for v in vids:
        for key in ("id", "duration", "transcript", "labels"):
            if key not in v:
                raise DatasetError(f"Video entry is missing '{key}': {v.get('id', v)}")
        if v["id"] in ids:
            raise DatasetError(f"Duplicate video id {v['id']!r}.")
        ids.add(v["id"])
        v.setdefault("split", "dev")
        if v["split"] not in {"dev", "test"}:
            raise DatasetError(f"Video {v['id']}: split must be 'dev' or 'test'.")
        for lab in v["labels"]:
            if lab.get("label") not in LABELS or not (0 <= float(lab["start"]) < float(lab["end"]) <= float(v["duration"]) + 0.5):
                raise DatasetError(f"Video {v['id']}: invalid label {lab}. Labels must be one of {LABELS} with 0 <= start < end <= duration.")
        tp = Path(v["transcript"])
        v["_transcript_path"] = tp if tp.is_absolute() else path.parent / tp
    data.setdefault("settings", {})
    return data


def _iou(a, b) -> float:
    return E._iou(a, b)


def match_label(clip: tuple[float, float], labels: list[dict]) -> str | None:
    best = max(labels, key=lambda l: _iou(clip, (l["start"], l["end"])), default=None)
    return best["label"] if best is not None and _iou(clip, (best["start"], best["end"])) >= E.SPAN_MATCH_IOU else None


def precision_at_k(grades: list[str | None], k: int) -> float | None:
    """Share of RATED clips among the top k that are Excellent/Good. None when nothing in the top k is rated."""
    rated = [g for g in grades[:k] if g is not None]
    return round(sum(g in GOOD for g in rated) / len(rated), 3) if rated else None


def ndcg_at_k(grades: list[str | None], k: int, ideal_pool: list[str]) -> float | None:
    """NDCG@k with gain 2^grade-1 (excellent=3, good=2, others 0). Unrated = 0. ``ideal_pool`` = every label known for this video."""
    gain = lambda g: (2 ** E.GRADE[g] - 1) if g else 0
    dcg = sum(gain(g) / math.log2(i + 2) for i, g in enumerate(grades[:k]))
    ideal = sorted((gain(g) for g in ideal_pool), reverse=True)[:k]
    idcg = sum(x / math.log2(i + 2) for i, x in enumerate(ideal))
    return round(dcg / idcg, 3) if idcg > 0 else None


def recall_at_k(clips: list[tuple[float, float]], good: list[tuple[float, float]], k: int) -> float | None:
    if not good:
        return None
    found = sum(1 for g in good if any(_iou(c, g) >= 0.5 or E._inside(c, g) >= 0.6 for c in clips[:k]))
    return round(found / len(good), 3)


def duplicate_rate(clips: list[tuple[float, float]]) -> float:
    pairs = [(a, b) for i, a in enumerate(clips) for b in clips[i + 1:]]
    if not pairs:
        return 0.0
    return round(sum(1 for a, b in pairs if _iou(a, b) > 0.3 or E._inside(a, b) > 0.5 or E._inside(b, a) > 0.5) / len(pairs), 3)


def rank_video(name: str, v: dict, tr: Transcript, target: float, k: int) -> list[tuple[float, float]]:
    dur = float(v["duration"])
    if name == "baseline":
        return [(c.start, c.end) for c in analysis.suggest_clips(dur, tr, [], [], target, k)]
    return [(c.start, c.end) for c in engine.rank(dur, tr, [], [], target, k)[0]]


def evaluate(path: Path) -> dict:
    data = load_dataset(path)
    st = data["settings"]
    target, k = float(st.get("target", 30)), int(st.get("k", 5))
    tuned_on = st.get("tuned_on_split")
    per: dict[str, dict[str, list]] = {s: {r: [] for r in RANKERS} for s in ("dev", "test")}
    for v in data["videos"]:
        tr = load_transcript_file(v["_transcript_path"], "dataset")
        dur = float(v["duration"])
        lo, hi = analysis.length_bounds(target, dur)
        labels = [{"start": float(l["start"]), "end": float(l["end"]), "label": l["label"]} for l in v["labels"]]
        good = [(l["start"], l["end"]) for l in labels if l["label"] in GOOD]
        for r in RANKERS:
            clips = rank_video(r, v, tr, target, k)
            grades = [match_label(c, labels) for c in clips]
            struct = E.structural_metrics(clips, dur, lo, hi, tr)
            per[v["split"]][r].append({
                "video": v["id"], "clips": clips, "grades": grades, "p_at_k": precision_at_k(grades, k),
                "ndcg": ndcg_at_k(grades, k, [l["label"] for l in labels]),
                "recall": recall_at_k(clips, good, k) if v.get("good_moments_exhaustive") else None,
                "duplicate_rate": duplicate_rate(clips), "struct": struct})
    return {"dataset": data["dataset"], "settings": {"target": target, "k": k, "tuned_on_split": tuned_on},
            "results": {s: {r: summarize(rows, k) for r, rows in d.items()} for s, d in per.items() if any(d[r] for r in RANKERS)},
            "warnings": warnings(per, tuned_on)}


def _mean(xs):
    xs = [x for x in xs if x is not None]
    return round(sum(xs) / len(xs), 3) if xs else None


def summarize(rows: list[dict], k: int) -> dict:
    grades = [g for r in rows for g in r["grades"]]
    rated = [g for g in grades if g is not None]
    n_clips = len(grades)
    s = [r["struct"] for r in rows]
    return {"videos": len(rows), "clips": n_clips, "rated_clips": len(rated), "rated_share": round(len(rated) / n_clips, 3) if n_clips else None,
            f"precision@{k}": _mean([r["p_at_k"] for r in rows]), f"ndcg@{k}": _mean([r["ndcg"] for r in rows]),
            f"recall@{k} (only videos with exhaustive labels)": _mean([r["recall"] for r in rows]),
            "human_acceptance_rate": round(sum(g in GOOD for g in rated) / len(rated), 3) if rated else None,
            "self_contained_rate": round(sum(g not in E.NOT_SELF_CONTAINED for g in rated) / len(rated), 3) if rated else None,
            "repetitive_rate": round(sum(g == "repetitive" for g in rated) / len(rated), 3) if rated else None,
            "duplicate_rate": _mean([r["duplicate_rate"] for r in rows]),
            "invalid_boundary_rate": _mean([x.get("invalid_boundary_rate") for x in s]),
            "duration_fit_rate": _mean([x.get("within_duration_rate") for x in s]),
            "mid_thought_start_rate": _mean([x.get("mid_thought_start_rate") for x in s]),
            "unfinished_end_rate": _mean([x.get("unfinished_end_rate") for x in s])}


def warnings(per: dict, tuned_on: str | None) -> list[str]:
    w = []
    for split, d in per.items():
        n = sum(len(r["grades"]) for r in d["multi-signal"]) if d["multi-signal"] else 0
        if 0 < n < MIN_CLIPS_FOR_CONCLUSIONS:
            w.append(f"Split '{split}': only {n} clips per ranker; fewer than {MIN_CLIPS_FOR_CONCLUSIONS}, so differences are anecdotes, not evidence.")
        rated = [g for r in d["multi-signal"] + d["baseline"] for g in r["grades"] if g is not None]
        total = sum(len(r["grades"]) for r in d["multi-signal"] + d["baseline"])
        if total and len(rated) / total < 0.8:
            w.append(f"Split '{split}': only {len(rated)}/{total} chosen clips have a human label. Unrated clips are not counted as good or bad, which can favour whichever ranker was labelled more. "
                     "Build labels from the pooled top-K of BOTH rankers (--export-pool).")
    if tuned_on in {"dev", "test"}:
        w.append(f"Weights/rules were tuned on the '{tuned_on}' split. Metrics on that split are optimistic; quote only the other split as a fair comparison.")
    if "test" not in per or not any(per["test"][r] for r in RANKERS):
        w.append("No held-out 'test' split: every number here comes from data that could have been used for tuning.")
    return w


def export_pool(videos: list[dict], target: float, k: int, out: Path) -> dict:
    """Template dataset: for each video the union of both rankers' top-k clips, ready for a human to fill in 'label'."""
    items = []
    for v in videos:
        tr = load_transcript_file(Path(v["transcript"]), "dataset")
        spans = {}
        for r in RANKERS:
            for s, e in rank_video(r, v, tr, target, k):
                spans[(round(s, 1), round(e, 1))] = spans.get((round(s, 1), round(e, 1)), []) + [r]
        items.append({"id": v["id"], "duration": v["duration"], "transcript": v["transcript"], "split": v.get("split", "dev"), "good_moments_exhaustive": False,
                      "labels": [{"start": s, "end": e, "label": None, "proposed_by": by, "text": " ".join(x.text for x in tr.segments if x.end > s and x.start < e)[:300]} for (s, e), by in sorted(spans.items())]})
    data = {"dataset": {"name": "TEMPLATE - fill in every label", "kind": "human", "annotator": "", "notes": "Set each label to one of: " + ", ".join(LABELS) + ". Watch the clip before labelling; the text is only a hint."},
            "settings": {"target": target, "k": k, "tuned_on_split": None}, "videos": items}
    Path(out).write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    return data


def render(res: dict) -> str:
    k = res["settings"]["k"]
    lines = [f"Human-labelled evaluation: {res['dataset'].get('name')} (annotator: {res['dataset'].get('annotator') or 'unspecified'}), target {res['settings']['target']}s, top {k}.", ""]
    for split, d in res["results"].items():
        lines += [f"### Split: {split}", "", "| Metric | Baseline | Multi-signal |", "|---|---|---|"]
        for key in d["baseline"] if "baseline" in d else []:
            lines.append(f"| {key} | {d['baseline'].get(key)} | {d['multi-signal'].get(key)} |")
        lines.append("")
    lines += ["### Warnings", ""] + ([f"* {w}" for w in res["warnings"]] or ["* none"])
    return "\n".join(lines)

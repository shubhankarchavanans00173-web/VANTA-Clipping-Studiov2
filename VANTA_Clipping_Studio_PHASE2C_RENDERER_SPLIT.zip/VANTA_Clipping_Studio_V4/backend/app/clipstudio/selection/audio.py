"""Lightweight audio loudness envelope (stdlib only: FFmpeg -> 8 kHz mono PCM -> RMS in dBFS per hop).

What this measures: how loud the signal is over time. It does NOT detect laughter, applause or emotion; no sound-event
classifier is bundled, and the engine never claims those signals.
"""
from __future__ import annotations

import array
import math
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

HOP = 0.25            # seconds per envelope sample
SAMPLE_RATE = 8000
FLOOR_DB = -90.0
SPEECH_DB_MARGIN = 14.0   # a hop counts as "sound present" when within this many dB of the 90th-percentile level


class AudioAnalysisError(RuntimeError):
    pass


@dataclass
class Envelope:
    hop: float
    db: list[float]

    def to_dict(self) -> dict:
        return {"hop": self.hop, "db": [round(x, 1) for x in self.db]}

    @classmethod
    def from_dict(cls, d: dict | None) -> "Envelope | None":
        if not d or not d.get("db"):
            return None
        try:
            return cls(float(d.get("hop", HOP)), [float(x) for x in d["db"]])
        except (TypeError, ValueError):
            return None

    # ---- derived views
    @property
    def reference_db(self) -> float:
        s = sorted(self.db)
        return s[int(0.9 * (len(s) - 1))] if s else FLOOR_DB

    def active(self) -> list[bool]:
        thr = max(self.reference_db - SPEECH_DB_MARGIN, FLOOR_DB + 5)
        return [v >= thr for v in self.db]

    def slice(self, start: float, end: float) -> list[float]:
        a, b = int(start / self.hop), max(int(start / self.hop) + 1, int(math.ceil(end / self.hop)))
        return self.db[a:b]

    def speech_ratio(self, start: float, end: float) -> float | None:
        act = self.active()[int(start / self.hop):int(math.ceil(end / self.hop))]
        return sum(act) / len(act) if act else None

    def dynamics(self, start: float, end: float) -> float | None:
        """Std-dev of loudness inside the window relative to the whole video's (1.0 = typical variation)."""
        win = [v for v, a in zip(self.slice(start, end), self.active()[int(start / self.hop):]) if a]
        whole = [v for v, a in zip(self.db, self.active()) if a]
        if len(win) < 4 or len(whole) < 8:
            return None
        sd = lambda xs: math.sqrt(sum((x - sum(xs) / len(xs)) ** 2 for x in xs) / len(xs))
        base = sd(whole)
        return sd(win) / base if base > 0.5 else None

    def pause_before(self, t: float, min_pause: float = 0.4, lookback: float = 2.0) -> float:
        """Length (s) of the longest low-level stretch ending within ``lookback`` seconds before ``t`` (0 if none)."""
        act = self.active()
        i_end = min(len(act), int(t / self.hop) + 1)
        i_start = max(0, int((t - lookback) / self.hop))
        best = run = 0
        for k in range(i_start, i_end):
            if not act[k]:
                run += 1; best = max(best, run)
            else:
                run = 0
        return best * self.hop if best * self.hop >= min_pause else 0.0


def compute_envelope(path: Path, timeout: float = 1800) -> Envelope:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise AudioAnalysisError("FFmpeg is not installed.")
    cmd = [ffmpeg, "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", str(SAMPLE_RATE), "-f", "s16le", "-"]
    per_hop = int(SAMPLE_RATE * HOP)
    out: list[float] = []
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except OSError as e:
        raise AudioAnalysisError(f"Could not start FFmpeg: {e}") from e
    try:
        assert p.stdout is not None
        buf = b""
        while True:
            chunk = p.stdout.read(per_hop * 2 * 240)
            if not chunk:
                break
            buf += chunk
            usable = len(buf) - len(buf) % (per_hop * 2)
            if not usable:
                continue
            samples = array.array("h"); samples.frombytes(buf[:usable]); buf = buf[usable:]
            for i in range(0, len(samples), per_hop):
                seg = samples[i:i + per_hop]
                ms = sum(x * x for x in seg) / len(seg)
                out.append(10 * math.log10(ms / 32768 ** 2) if ms > 0 else FLOOR_DB)
        p.wait(timeout=timeout)
    except subprocess.TimeoutExpired as e:
        p.kill(); raise AudioAnalysisError("Audio analysis timed out.") from e
    finally:
        if p.poll() is None:
            p.kill()
    if p.returncode not in (0, None) or not out:
        err = (p.stderr.read().decode("utf-8", "replace")[-200:] if p.stderr else "")
        raise AudioAnalysisError("Audio analysis failed: " + (err.strip() or "no audio samples decoded"))
    return Envelope(HOP, [max(FLOOR_DB, v) for v in out])

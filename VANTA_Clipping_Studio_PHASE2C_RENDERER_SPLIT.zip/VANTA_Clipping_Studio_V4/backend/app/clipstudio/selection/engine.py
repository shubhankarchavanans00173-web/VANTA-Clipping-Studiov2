"""Multi-signal clip selection engine: candidates -> features -> relative score -> diverse selection -> evidence-based explanation."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from ..analysis import Candidate, build_units, length_bounds
from ..timeutil import MIN_CLIP_SECONDS
from ..transcript import Transcript
from . import candidates as C
from . import explain, quotes, scoring
from . import features as F
from . import lexicon as L
from .audio import Envelope

ENGINE_NAME = "multi-signal-rules"
ENGINE_VERSION = "2.0"
METHOD = "multi-signal"
METHOD_NO_TEXT = "signal-segmentation"
MAX_OVERLAP = 0.15
MAX_TOPIC_SIMILARITY = 0.55
DIVERSITY_PENALTY = 30.0       # points removed per 1.0 of topical similarity to an already-chosen clip


@dataclass
class Scored:
    window: F.Window
    feats: dict
    combo: dict
    analysis: dict = field(default_factory=dict)

    @property
    def score(self) -> float:
        return self.combo["score"]


def _overlap(a: F.Window, b: F.Window) -> float:
    inter = max(0.0, min(a.end, b.end) - max(a.start, b.start))
    return inter / max(1e-6, min(a.end - a.start, b.end - b.start))


def _topic(w: F.Window) -> set[str]:
    return set(L.content_words(w.text))


def _similarity(a: F.Window, b: F.Window) -> float:
    ta, tb = _topic(a), _topic(b)
    return len(ta & tb) / len(ta | tb) if ta and tb else 0.0


def _boundary(feats: dict) -> float:
    vals = [feats[k]["value"] for k in ("opening_quality", "ending_quality") if feats.get(k, {}).get("value") is not None]
    return sum(vals) / len(vals) if vals else 0.3


def score_window(w: F.Window, scenes_known: bool, weights: dict | None = None) -> Scored:
    if w.units:
        feats = F.extract(w, scenes_known)
    else:  # no transcript: only duration/audio/scene features exist; text features are explicitly unavailable
        none = {"value": None, "evidence": "No transcript, so this was not assessed."}
        feats = {k: dict(none) for k in scoring.DEFAULT_WEIGHTS}
        feats.update(duration_fit=F.duration_fit(w), speech_activity=F.speech_activity(w), energy_dynamics=F.energy_dynamics(w),
                     visual_activity=F.visual_activity(w, scenes_known))
    return Scored(w, feats, scoring.combine(feats, weights))


def select_diverse(pool: list[Scored], count: int) -> list[Scored]:
    chosen: list[Scored] = []
    remaining = sorted(pool, key=lambda s: (-s.score, s.window.start))
    while remaining and len(chosen) < count:
        best, best_adj = None, -1e9
        for s in remaining:
            if any(_overlap(s.window, c.window) > MAX_OVERLAP for c in chosen):
                continue
            sim = max((_similarity(s.window, c.window) for c in chosen), default=0.0)
            if sim > MAX_TOPIC_SIMILARITY:
                continue
            adj = s.score - DIVERSITY_PENALTY * sim
            if adj > best_adj:
                best, best_adj = s, adj
        if best is None:
            break
        chosen.append(best); remaining.remove(best)
    return chosen


def _alternates(sel: Scored, pool: list[Scored], limit: int = 2) -> list[dict]:
    out = []
    for s in sorted(pool, key=lambda s: -s.score):
        if s is sel or _overlap(s.window, sel.window) < 0.5:
            continue
        ds, de = s.window.start - sel.window.start, s.window.end - sel.window.end
        if abs(ds) < 3 and abs(de) < 3:
            continue
        if any(abs(o["start"] - s.window.start) < 3 and abs(o["end"] - s.window.end) < 3 for o in out):
            continue
        parts = []
        if abs(ds) >= 3:
            parts.append(f"starts {abs(ds):.0f}s {'earlier' if ds < 0 else 'later'}")
        if abs(de) >= 3:
            parts.append(f"ends {abs(de):.0f}s {'earlier' if de < 0 else 'later'}")
        out.append({"start": s.window.start, "end": s.window.end, "score": s.score, "note": ", ".join(parts)})
        if len(out) >= limit:
            break
    return out


def _finish(sel: Scored, pool: list[Scored], signals_used: list[str], unavailable: list[str], blob: str = "") -> Candidate:
    w = sel.window
    has_text = bool(w.units)
    ex = explain.build(sel.feats, sel.combo["penalties"], w.units, signals_used, _boundary(sel.feats), sel.combo["coverage"], has_text)
    needs_setup = (sel.feats.get("context_dependency", {}).get("value") or 0) >= 0.4
    suggested = None
    if needs_setup and w.prev is not None:
        suggested = {"start": round(max(0.0, w.prev.start - 0.2), 3), "setup": w.prev.text}
    sel.analysis = {
        "engine": ENGINE_NAME, "engine_version": ENGINE_VERSION, "score_meaning": explain.SCORE_MEANING,
        "signals_used": signals_used, "signals_not_available": unavailable,
        "features": {k: {kk: vv for kk, vv in v.items() if kk in ("value", "evidence", "kind")} for k, v in sel.feats.items()},
        "weights_used": sel.combo["used"], "penalties": sel.combo["penalties"], "base_score": sel.combo["base"],
        "summary": ex["summary"], "caveats": ex["caveats"], "hook": ex["hook"], "payoff": ex["payoff"], "confidence": ex["confidence"],
        "needs_setup": needs_setup, "suggested_setup": suggested, "alternates": _alternates(sel, pool), "llm": None,
    }
    excerpt = w.text if has_text else ""
    sel.analysis, excerpt, _ = quotes.verify_analysis(sel.analysis, excerpt, blob)
    reasons = ex["reasons"] + [f"Caveat: {c}" for c in ex["caveats"]]
    return Candidate(w.start, w.end, sel.score, METHOD if has_text else METHOD_NO_TEXT, reasons, excerpt,
                     {"analysis": sel.analysis})


def signals_summary(has_text: bool, envelope: Envelope | None, scenes_known: bool, word_level: bool) -> tuple[list[str], list[str]]:
    used = (["transcript" + (" (word timings)" if word_level else " (sentence timings)")] if has_text else []) \
        + (["audio-loudness"] if envelope else []) + (["scene-cuts"] if scenes_known else [])
    na = [] if has_text else ["transcript"]
    if not envelope:
        na.append("audio-loudness")
    if not scenes_known:
        na.append("scene-cuts")
    na += ["sound events (laughter/applause)", "faces and emotions", "on-screen text", "vertical-crop suitability"]
    return used, na


def rank(duration: float, transcript: Transcript | None, silences: list[tuple[float, float]], scenes: list[tuple[float, float]],
         target: float, count: int, envelope: Envelope | None = None, scenes_known: bool = True,
         weights: dict | None = None) -> tuple[list[Candidate], list[Scored]]:
    """Return (selected candidates, full scored pool). Deterministic for identical inputs."""
    if duration < MIN_CLIP_SECONDS:
        return [], []
    lo, hi = length_bounds(float(target), duration)
    has_text = bool(transcript is not None and transcript.available)
    word_level = bool(has_text and transcript.word_level)
    if has_text:
        units = build_units(transcript)
        wins = C.generate(units, duration, float(target), lo, hi, envelope, list(scenes), word_level) if units else []
    else:
        wins = []
    if not wins:
        has_text = False
        wins = C.signal_windows(duration, envelope, list(silences), list(scenes), float(target), lo, hi)
    pool = [score_window(w, scenes_known, weights) for w in wins]
    used, na = signals_summary(has_text, envelope, scenes_known, word_level)
    chosen = select_diverse(pool, int(count))
    blob = quotes.transcript_blob(transcript) if has_text else ""
    return [_finish(s, pool, used, na, blob) for s in chosen], pool

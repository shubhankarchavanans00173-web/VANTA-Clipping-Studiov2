"""Candidate generation: anchor on promising sentences, then vary the start (with setup) and the end (at natural boundaries).

Windows are built from sentence units, never from arbitrary fixed-length slices, so clips start and end on sentence edges.
"""
from __future__ import annotations

from ..analysis import Unit
from . import features as F
from . import lexicon as L
from .audio import Envelope

MAX_ANCHORS = 70
MAX_PAUSE_ANCHORS = 40
MAX_STARTS_PER_ANCHOR = 3
MAX_ENDS_PER_START = 4


def _anchor_value(units: list[Unit], k: int) -> float:
    u = units[k]
    probe = F.Window([u], u.start, u.end, k, k, units, 30, 5, 90)
    v = F.hook(probe)["value"] or 0.0
    if F.payoff(F.Window(units[k:k + 3], u.start, units[min(len(units) - 1, k + 2)].end, k, min(len(units) - 1, k + 2), units, 30, 5, 90))["value"] >= 0.8:
        v = max(v, 0.5)
    return v


def anchors(units: list[Unit]) -> list[int]:
    scored = sorted(range(len(units)), key=lambda k: (-_anchor_value(units, k), k))
    chosen = [k for k in scored[:MAX_ANCHORS] if _anchor_value(units, k) >= 0.45]
    pause = [k for k in range(len(units)) if k == 0 or units[k].start - units[k - 1].end >= 0.8][:MAX_PAUSE_ANCHORS]
    return sorted(set(chosen) | set(pause))


def _starts(units: list[Unit], k: int) -> list[int]:
    out = [k]
    first = units[k].text
    needs_setup = bool(L.DANGLING.search(first) or L.BACKREF.search(first) or L.FILLER_START.match(first))
    for back in (1, 2):
        p = k - back
        if p < 0 or units[k].start - units[p].start > 25:
            break
        if needs_setup or (back == 1 and "?" in units[p].text):
            out.append(p)
        if len(out) > 1 and back == 1 and not needs_setup:
            break
    return out[:MAX_STARTS_PER_ANCHOR]


def _ends(units: list[Unit], s: int, target: float, min_len: float, max_len: float) -> list[int]:
    valid = [j for j in range(s, len(units)) if min_len <= units[j].end - units[s].start <= max_len]
    if not valid:
        return []
    term = [j for j in valid if L.ends_terminal(units[j].text)] or valid
    by_target = sorted(term, key=lambda j: abs(units[j].end - units[s].start - target))[:3]
    pauses = [j for j in valid if j + 1 < len(units) and units[j + 1].start - units[j].end >= 0.6]
    extra = sorted(pauses, key=lambda j: abs(units[j].end - units[s].start - target))[:1]
    ends = list(dict.fromkeys(by_target + extra))
    return ends[:MAX_ENDS_PER_START]


def generate(units: list[Unit], duration: float, target: float, min_len: float, max_len: float, envelope: Envelope | None,
             scenes: list[tuple[float, float]], word_level: bool) -> list[F.Window]:
    from ..timeutil import MAX_CLIP_SECONDS, MIN_CLIP_SECONDS
    seen: set[tuple[int, int]] = set()
    out: list[F.Window] = []
    for a in anchors(units):
        for s in _starts(units, a):
            for j in _ends(units, s, target, min_len, max_len):
                if (s, j) in seen:
                    continue
                seen.add((s, j))
                lo = max(0.0, (units[s - 1].end + units[s].start) / 2 if s else units[s].start - 0.2)
                hi = min(duration, (units[j].end + units[j + 1].start) / 2 if j + 1 < len(units) else units[j].end + 0.3)
                start, end = max(lo, units[s].start - 0.2), min(hi, units[j].end + 0.3)
                if not (MIN_CLIP_SECONDS <= end - start <= MAX_CLIP_SECONDS):
                    continue
                out.append(F.Window(units[s:j + 1], round(start, 3), round(end, 3), s, j, units, target, min_len, max_len,
                                    envelope, scenes, word_level))
    return dedupe(out)


def dedupe(wins: list[F.Window], tol: float = 1.0) -> list[F.Window]:
    """Drop windows whose start AND end are both within ``tol`` seconds of an already-kept window. Different boundaries survive."""
    kept: list[F.Window] = []
    for w in wins:
        if not any(abs(w.start - k.start) < tol and abs(w.end - k.end) < tol for k in kept):
            kept.append(w)
    return kept


def signal_windows(duration: float, envelope: Envelope | None, silences: list[tuple[float, float]],
                   scenes: list[tuple[float, float]], target: float, min_len: float, max_len: float) -> list[F.Window]:
    """No transcript: windows start where sound resumes or the scene changes and end on the quiet point nearest the target."""
    from ..timeutil import MIN_CLIP_SECONDS
    starts = {0.0} | {e for _, e in silences if e < duration - min_len} | {t for t, _ in scenes if t < duration - min_len}
    step = max(5.0, target / 2)
    starts |= {k * step for k in range(int(duration // step) + 1) if k * step < duration - min_len}
    quiet = sorted(s for s, _ in silences)
    out: list[F.Window] = []
    for a in sorted(starts):
        end = min(duration, a + target)
        near = [s for s in quiet if abs(s - end) <= max(2.0, target * 0.2) and min_len <= s - a <= max_len]
        if near:
            end = min(near, key=lambda s: abs(s - end))
        if end - a >= max(min_len, MIN_CLIP_SECONDS):
            out.append(F.Window([], round(a, 3), round(end, 3), -1, -1, [], target, min_len, max_len, envelope, scenes, False))
    return dedupe(out, tol=1.5)

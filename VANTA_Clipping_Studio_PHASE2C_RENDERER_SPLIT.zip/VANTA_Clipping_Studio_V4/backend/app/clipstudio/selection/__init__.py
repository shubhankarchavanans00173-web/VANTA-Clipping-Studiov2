"""Intelligent clip selection (rule-based multi-signal engine + optional local LLM + evaluation tooling)."""
from .engine import ENGINE_NAME, ENGINE_VERSION, METHOD, METHOD_NO_TEXT, rank  # noqa: F401

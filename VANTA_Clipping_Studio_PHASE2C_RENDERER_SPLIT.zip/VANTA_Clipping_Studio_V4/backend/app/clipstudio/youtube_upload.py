"""VANTA export review and explicit YouTube upload service.

This module only runs after the VANTA HTTP route has received a fresh, explicit
confirmation.  It is intentionally not imported by the scheduler.
"""
from __future__ import annotations

import re
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .. import youtube
from . import db, settings

_EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="vanta-youtube")
_LOCK = threading.Lock()
_IN_FLIGHT: set[str] = set()
_THUMB_NAME = re.compile(r"^(t\d{1,2}|custom_\d{1,6})\.jpg$")


class UploadError(RuntimeError):
    pass


def _safe_status() -> dict:
    raw = youtube.status()
    return {key: raw.get(key) for key in ("libraries", "client_secret_found", "connected", "channel", "connect_state", "connect_error")}


def status() -> dict:
    return _safe_status()


def connect() -> dict:
    try:
        return {**_safe_status(), **youtube.start_connect()}
    except RuntimeError as error:
        raise UploadError(str(error)) from error


def disconnect() -> dict:
    youtube.disconnect()
    return {"connected": False}


def _export_video(export: dict) -> Path:
    path = Path(export.get("path") or "")
    if not path.is_file() or not settings.is_inside(path, settings.EXPORT_DIR):
        raise UploadError("The exported MP4 is no longer available locally.")
    return path


def _thumbnail(export: dict, use_thumbnail: bool) -> Path | None:
    if not use_thumbnail:
        return None
    choice = (export.get("meta") or {}).get("thumbnail") or {}
    name = str(choice.get("name") or "")
    safe_id = re.sub(r"[^a-z0-9]", "", export["id"].lower())
    path = settings.EXPORT_DIR / "_thumbs" / safe_id / name
    if name and _THUMB_NAME.fullmatch(name) and path.is_file() and settings.is_inside(path, settings.EXPORT_DIR):
        return path
    return None


def _request_values(export: dict, request: dict) -> dict:
    publish = (export.get("meta") or {}).get("publish") or {}
    title = str(request.get("title") or publish.get("title") or Path(export["filename"]).stem).strip()
    description = str(request.get("description") if request.get("description") is not None else publish.get("description") or "")
    raw_tags = request.get("tags") or publish.get("hashtags") or []
    if isinstance(raw_tags, str):
        raw_tags = raw_tags.split()
    tags = [str(tag).lstrip("#").strip() for tag in raw_tags if str(tag).strip()]
    return {
        "title": title[:100],
        "description": description[:5000],
        "tags": tags[:30],
        "privacy": request.get("privacy", "private"),
        "made_for_kids": bool(request.get("made_for_kids", False)),
        "ai_disclosure": bool(request.get("ai_disclosure", True)),
        "set_thumbnail": bool(request.get("set_thumbnail", True)),
    }


def _state(eid: str, **values) -> None:
    db.merge_export_meta(eid, {"youtube_upload": values})


def _worker(eid: str, request: dict) -> None:
    try:
        export = db.get_export(eid)
        if export is None:
            raise UploadError("This export no longer exists.")
        values = _request_values(export, request)
        video = _export_video(export)
        thumbnail = _thumbnail(export, values["set_thumbnail"])
        duration = float(export.get("duration") or 0)
        _state(eid, state="uploading", progress=0, privacy=values["privacy"], started_at=db.now())
        result = youtube.upload(
            video, thumbnail, title=values["title"], description=values["description"], tags=values["tags"],
            privacy=values["privacy"], made_for_kids=values["made_for_kids"], ai_disclosure=values["ai_disclosure"],
            category_id="22", publish_at=None, shorts=export.get("aspect") == "9:16" and duration <= 180,
            progress=lambda progress: _state(eid, state="uploading", progress=max(0, min(99, int(progress))), privacy=values["privacy"]),
        )
        video_id = result.get("video_id")
        if not video_id:
            raise UploadError("YouTube did not confirm a video ID. Upload is not recorded as successful.")
        _state(
            eid, state="completed", progress=100, privacy=values["privacy"], video_id=video_id,
            url=result.get("url"), studio_url=result.get("studio_url"), notes=result.get("notes") or [], completed_at=db.now(),
        )
    except Exception as error:
        # Deliberately do not create a video_id on an error, even if a lower API
        # layer supplied partial response data.
        _state(eid, state="error", error=str(error)[:500], failed_at=db.now())
    finally:
        with _LOCK:
            _IN_FLIGHT.discard(eid)


def submit(eid: str, request: dict) -> dict:
    export = db.get_export(eid)
    if export is None:
        raise UploadError("Export not found.")
    current = (export.get("meta") or {}).get("youtube_upload") or {}
    if current.get("video_id") or current.get("state") == "completed":
        raise UploadError("This export already has a YouTube video ID; duplicate upload is blocked.")
    with _LOCK:
        if eid in _IN_FLIGHT or current.get("state") in {"queued", "uploading"}:
            raise UploadError("An upload is already running for this export.")
        _IN_FLIGHT.add(eid)
    values = _request_values(export, request)
    _state(eid, state="queued", progress=0, privacy=values["privacy"], requested_at=db.now())
    _EXECUTOR.submit(_worker, eid, values)
    return {"accepted": True, "export_id": eid, "state": "queued", "privacy": values["privacy"]}


def recover_interrupted() -> int:
    """A process restart cannot safely resume an unknown HTTP upload session."""
    recovered = 0
    for export in db.list_exports():
        current = (export.get("meta") or {}).get("youtube_upload") or {}
        if current.get("state") in {"queued", "uploading"}:
            _state(export["id"], state="error", error="Backend restarted before the YouTube upload completed. Review and explicitly retry.", failed_at=db.now())
            recovered += 1
    return recovered

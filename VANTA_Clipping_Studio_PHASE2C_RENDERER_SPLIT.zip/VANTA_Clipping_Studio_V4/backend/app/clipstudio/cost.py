"""Gate for OPTIONAL paid cloud AI. Everything here is OFF by default and never runs without explicit per-request confirmation.

Rules enforced in code (and covered by tests):
  * disabled unless VANTA_CLOUD_AI_ENABLED=1, a key exists in the *backend* environment and a model is named;
  * every request first needs an estimate, then an explicit ``confirm=true`` that references that estimate;
  * an estimate is single-use and expires - there are no automatic retries and no silent provider switching;
  * keys are never returned to the frontend or written to logs.
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid

import httpx

ESTIMATE_TTL_SECONDS = 15 * 60
API_URL = "https://api.anthropic.com/v1/messages"
MAX_OUTPUT_TOKENS = 1500
_ESTIMATES: dict[str, dict] = {}
_LOCK = threading.Lock()


class PaidAIError(RuntimeError):
    """``status`` is an HTTP-ish status the API layer can reuse."""

    def __init__(self, status: int, code: str, message: str):
        super().__init__(message)
        self.status, self.code = status, code


def _float_env(name: str) -> float | None:
    try:
        return float(os.environ[name])
    except (KeyError, ValueError):
        return None


def provider_status() -> dict:
    enabled = os.getenv("VANTA_CLOUD_AI_ENABLED") == "1"
    model = os.getenv("VANTA_CLOUD_AI_MODEL", "").strip()
    has_key = bool(os.getenv("ANTHROPIC_API_KEY", "").strip())
    problems = []
    if not enabled:
        problems.append("Disabled (default). Set VANTA_CLOUD_AI_ENABLED=1 to allow optional cloud ranking.")
    if enabled and not has_key:
        problems.append("ANTHROPIC_API_KEY is not set in the backend environment.")
    if enabled and not model:
        problems.append("VANTA_CLOUD_AI_MODEL is not set.")
    return {"provider": "anthropic", "model": model or None, "enabled": enabled, "configured": enabled and has_key and bool(model),
            "paid": True, "requires_confirmation": True, "detail": " ".join(problems) or "Ready. Every request still needs your explicit confirmation.",
            "prices_configured": _float_env("VANTA_CLOUD_PRICE_IN_PER_MTOK") is not None and _float_env("VANTA_CLOUD_PRICE_OUT_PER_MTOK") is not None}


def _require_ready() -> dict:
    st = provider_status()
    if not st["enabled"]:
        raise PaidAIError(403, "disabled", "Cloud AI is disabled. Nothing was sent anywhere.")
    if not st["configured"]:
        raise PaidAIError(503, "not_configured", st["detail"])
    return st


def estimate(input_chars: int) -> dict:
    st = _require_ready()
    in_tokens = max(1, input_chars // 3) + 300            # deliberately conservative (3 chars/token + instructions)
    out_tokens = MAX_OUTPUT_TOKENS
    pin, pout = _float_env("VANTA_CLOUD_PRICE_IN_PER_MTOK"), _float_env("VANTA_CLOUD_PRICE_OUT_PER_MTOK")
    cost = round(in_tokens / 1e6 * pin + out_tokens / 1e6 * pout, 4) if pin is not None and pout is not None else None
    est = {"estimate_id": uuid.uuid4().hex, "provider": st["provider"], "model": st["model"], "est_input_tokens": in_tokens,
           "est_output_tokens_max": out_tokens, "est_cost_usd": cost, "price_known": cost is not None,
           "note": "Upper-bound estimate from text length." + ("" if cost is not None else " No prices are configured (VANTA_CLOUD_PRICE_IN_PER_MTOK / _OUT_PER_MTOK), so the cost is unknown - check your provider's pricing before confirming.")}
    with _LOCK:
        _purge()
        _ESTIMATES[est["estimate_id"]] = {**est, "created": time.time()}
    return est


def _purge() -> None:
    cutoff = time.time() - ESTIMATE_TTL_SECONDS
    for k in [k for k, v in _ESTIMATES.items() if v["created"] < cutoff]:
        _ESTIMATES.pop(k, None)


def authorize(estimate_id: str | None, confirm: bool | None) -> dict:
    """Consume an estimate. Raises unless cloud AI is enabled, estimated first and explicitly confirmed."""
    _require_ready()
    if confirm is not True:
        raise PaidAIError(428, "confirmation_required", "This is a paid request. Review the estimate and confirm explicitly.")
    with _LOCK:
        _purge()
        est = _ESTIMATES.pop(estimate_id or "", None)
    if est is None:
        raise PaidAIError(409, "estimate_missing", "Request a fresh cost estimate first (estimates are single-use and expire after 15 minutes).")
    return est


def build_prompt(items: list[dict]) -> str:
    lines = [f"[{i['id']}] ({i['start']:.1f}s-{i['end']:.1f}s) {i['excerpt'][:900]}" for i in items]
    return ("You rate candidate short-form video clips from a transcript. For each clip give an integer 0-100 for how well it works as a standalone, "
            "engaging Short (hook, clarity, self-contained, payoff) and one short reason. This is a quality rating, not a view prediction. "
            'Reply with ONLY JSON: {"ratings":[{"id":"...","score":0,"reason":"..."}]}\n\n' + "\n".join(lines))


def rank_with_claude(items: list[dict], est: dict, transport: httpx.BaseTransport | None = None) -> dict:
    """One single, non-retried request. Returns {"ratings": {id: {score, reason}}, "usage": {...}, "provider", "model"}."""
    key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not key:
        raise PaidAIError(503, "not_configured", "ANTHROPIC_API_KEY is not set in the backend environment.")
    body = {"model": est["model"], "max_tokens": est["est_output_tokens_max"], "messages": [{"role": "user", "content": build_prompt(items)}]}
    try:
        with httpx.Client(timeout=httpx.Timeout(60, connect=15), transport=transport) as client:
            r = client.post(API_URL, json=body, headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    except httpx.HTTPError as error:
        raise PaidAIError(502, "provider_unavailable", f"The AI provider could not be reached ({type(error).__name__}). Nothing was retried.") from error
    if r.status_code >= 400:
        raise PaidAIError(502, "provider_error", f"The AI provider answered HTTP {r.status_code}. Nothing was retried.")
    try:
        data = r.json()
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        ratings = json.loads(text[text.index("{"): text.rindex("}") + 1])["ratings"]
        out = {str(x["id"]): {"score": max(0, min(100, int(x["score"]))), "reason": str(x.get("reason", ""))[:200]} for x in ratings}
    except (ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        raise PaidAIError(502, "bad_response", "The AI provider returned an unreadable answer.") from error
    usage = data.get("usage") or {}
    return {"ratings": out, "provider": est["provider"], "model": est["model"],
            "usage": {"input_tokens": usage.get("input_tokens"), "output_tokens": usage.get("output_tokens")}}

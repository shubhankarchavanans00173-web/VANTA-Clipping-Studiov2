"""Structured, user-facing link/download failure (shared by ``links`` and ``ytdlp`` to avoid circular imports)."""
from __future__ import annotations


class LinkError(RuntimeError):
    """A link or download failure that is safe to show to the user.

    ``code`` is machine readable, e.g. invalid_url, blocked_host, unsupported_platform, unavailable, login_required, bot_check,
    live_unavailable, geo_blocked, drm, rate_limited, network_error, timeout, server_error, access_denied, extraction_failed,
    format_unavailable, ffmpeg_missing, adapter_disabled, adapter_missing, disk_full, permission_denied, too_large, not_video,
    invalid_media, download_failed, cancelled, unknown_error.
    ``retryable`` tells the UI whether a Retry button makes sense; ``hint`` is the next step; ``details`` are short, scrubbed
    diagnostic lines taken from the downloader (never environment variables or credentials).
    """

    def __init__(self, code: str, message: str, *, retryable: bool = False, hint: str | None = None, details: list[str] | None = None):
        super().__init__(message)
        self.code = code
        self.retryable = retryable
        self.hint = hint
        self.details = list(details or [])

    def to_dict(self) -> dict:
        return {"code": self.code, "message": str(self), "retryable": self.retryable, "hint": self.hint, "details": self.details}

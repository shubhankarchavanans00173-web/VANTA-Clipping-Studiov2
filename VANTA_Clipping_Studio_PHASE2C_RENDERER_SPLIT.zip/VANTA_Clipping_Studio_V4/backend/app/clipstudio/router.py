"""HTTP API for VANTA Clipping Studio (mounted under /api/vanta).

The route handlers live in ``clipstudio/routes/*.py`` (one module per area). This module assembles them into the single
``router`` that ``app/main.py`` mounts, and re-exports every name that used to be defined here so that
``from app.clipstudio import router`` and ``mock.patch("app.clipstudio.router.youtube_upload.status")`` keep working.
"""
from __future__ import annotations

from fastapi import APIRouter

# Modules re-exported for compatibility (tests patch e.g. ``router.youtube_upload.status``; the route modules use the same module objects).
from . import analysis, cost, db, envsettings, links, media, metadata, pipeline, scheduler, settings, ytdlp, youtube_upload  # noqa: F401
from . import whisper_local  # noqa: F401
from .routes import candidates as _candidates, cloud_ai as _cloud_ai, exports as _exports, projects as _projects, publishing as _publishing
from .routes import render_jobs as _render_jobs, scheduling as _scheduling, system as _system, templates as _templates, transcription as _transcription
from .routes.common import VERSION, _candidate, _export, _export_file, _ffmpeg_version, _project, _public_project, _safe_name, _save_upload  # noqa: F401
from .routes.candidates import *  # noqa: F401,F403
from .routes.candidates import _duration_of  # noqa: F401
from .routes.cloud_ai import *  # noqa: F401,F403
from .routes.cloud_ai import _ai_items  # noqa: F401
from .routes.exports import *  # noqa: F401,F403
from .routes.exports import _export_transcript, _thumb_dir, _thumb_urls  # noqa: F401
from .routes.projects import *  # noqa: F401,F403
from .routes.projects import _attach_transcript  # noqa: F401
from .routes.publishing import *  # noqa: F401,F403
from .routes.render_jobs import *  # noqa: F401,F403
from .routes.render_jobs import _probe_audio  # noqa: F401
from .routes.scheduling import *  # noqa: F401,F403
from .routes.system import *  # noqa: F401,F403
from .routes.templates import *  # noqa: F401,F403
from .routes.transcription import *  # noqa: F401,F403

router = APIRouter(prefix="/api/vanta", tags=["vanta"])
for _module in (_system, _scheduling, _projects, _transcription, _candidates, _render_jobs, _exports, _publishing, _templates, _cloud_ai):
    router.include_router(_module.router)

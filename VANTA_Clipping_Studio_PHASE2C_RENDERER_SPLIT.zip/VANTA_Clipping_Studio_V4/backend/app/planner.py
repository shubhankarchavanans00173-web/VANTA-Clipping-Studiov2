"""Deterministic, clearly-labelled local planning fallback.

This module deliberately does not claim to be an LLM.  It turns supplied text into
editable scenes when a local language model has not been configured.
"""
from __future__ import annotations

import math
import re


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def _sentences(text: str) -> list[str]:
    pieces=[_clean(item) for item in re.split(r"(?<=[.!?])\s+|\n+",text) if _clean(item)]
    return pieces or [text]


def _title(text: str, fallback: str) -> str:
    words=re.findall(r"[\w'-]+",text)
    return " ".join(words[:6]).title() or fallback


_STOP=set("a an the and or but if then than that this these those is are was were be been being am do does did have has had of to in on at by for with from as into over under about it its it's we you they he she i me my our your their his her them us not no so very can could would should will just more most some any each every how what when where why which who whom there here also".split())


def extract_keywords(text: str, limit: int=3) -> str:
    """Pick concrete words for a stock-footage search (longest, most frequent first)."""
    words=[w.lower() for w in re.findall(r"[A-Za-z][A-Za-z'-]{3,}",text or "")]
    counts={}
    for w in words:
        if w in _STOP: continue
        counts[w]=counts.get(w,0)+1
    ranked=sorted(counts,key=lambda w:(-counts[w],-len(w)))
    return " ".join(ranked[:limit])


def make_hashtags(subject: str, extra: str="", aspect: str="9:16", limit: int=8) -> list[str]:
    tags=[]
    if aspect=="9:16": tags.append("#Shorts")
    for w in extract_keywords(subject+" "+extra,5).split():
        tag="#"+re.sub(r"\W+","",w).capitalize()
        if tag not in tags: tags.append(tag)
    return tags[:limit]


def template_script(topic: str, duration: int, style: str) -> str:
    subject=_clean(topic) or "this topic"
    return (
        f"Here is the key idea behind {subject}. "
        f"We will look at what matters, why it is useful to understand, and one practical takeaway. "
        f"The important point is to stay curious and check reliable sources before drawing conclusions about {subject}. "
        f"That is the short version of {subject}."
    )


def _chunk(sentences: list[str], scene_count: int) -> list[str]:
    # Split long scripts by approximate word count while preserving the supplied order.
    words=" ".join(sentences).split()
    if not words:
        return ["Add your scene text here."]
    chunk_size=max(8,math.ceil(len(words)/scene_count))
    chunks=[" ".join(words[index:index+chunk_size]) for index in range(0,len(words),chunk_size)]
    if len(chunks)>scene_count:
        head=chunks[:scene_count-1]
        head.append(" ".join(chunks[scene_count-1:]))
        return head
    return chunks


def _timed(chunks: list[str], duration: int) -> list[tuple[float,float]]:
    """Give each scene time proportional to its word count (min 1.5 s)."""
    weights=[max(3,len(c.split())) for c in chunks]
    total=sum(weights); spans=[]; start=0.0
    for index,weight in enumerate(weights):
        end=float(duration) if index==len(weights)-1 else round(start+duration*weight/total,3)
        spans.append((round(start,3),end)); start=end
    return spans


def build_plan(
    *,
    topic: str,
    script: str | None,
    source_text: str | None,
    duration: int,
    style: str,
    input_type: str,
    character_description: str = "",
    environment_description: str = "",
    aspect_ratio: str = "9:16",
    language: str = "English",
    use_llm: bool = True,
) -> dict:
    seed=_clean(script or source_text or "")
    subject=_clean(topic) or _title(seed,"Untitled short")
    prompt_as_story=not seed and len(subject.split())>12
    llm_data=None; llm_error=None
    if use_llm and not seed and not prompt_as_story:
        try:
            from . import llm
            if llm.provider_name(): llm_data=llm.write_script(subject,duration,language,style)
        except RuntimeError as error:
            llm_error=str(error)
    used_template=not bool(seed) and not prompt_as_story and llm_data is None
    queries=[]; scene_titles=[]
    if llm_data:
        chunks=[sc["narration"] for sc in llm_data["scenes"]]
        queries=[sc["search_query"] for sc in llm_data["scenes"]]
        scene_titles=[sc["title"] for sc in llm_data["scenes"]]
        final_script=" ".join(chunks)
    else:
        final_script=seed or subject if prompt_as_story else seed or template_script(subject,duration,style)
        scene_count=max(3,min(40,round(duration/8)))
        chunks=_chunk(_sentences(final_script),scene_count)
    spans=_timed(chunks,duration)
    scenes=[]
    for index,chunk in enumerate(chunks,1):
        start,end=spans[index-1]
        caption=" ".join(chunk.split()[:18])
        query=(queries[index-1] if index-1<len(queries) and queries[index-1] else
               (extract_keywords(chunk,2)+" "+extract_keywords(subject,1)).strip())
        scenes.append({
            "id":index,
            "title":(scene_titles[index-1] if index-1<len(scene_titles) and scene_titles[index-1] else _title(chunk,f"Scene {index}")),
            "narration":chunk,
            "caption":caption,
            "search_query":query,
            "visual_prompt":". ".join(value for value in (
                f"Original {style.replace('_',' ')} scene about {subject}: {chunk}",
                _clean(character_description),
                _clean(environment_description),
            ) if value),
            "start_seconds":start,
            "end_seconds":end,
        })
    safe_title=(llm_data["titles"][0] if llm_data and llm_data["titles"] else subject)[:90]
    titles=(llm_data["titles"] if llm_data and llm_data["titles"] else [safe_title,f"The key idea: {safe_title}",f"A short guide to {safe_title}"])[:3]
    tags=(llm_data["hashtags"] if llm_data and llm_data["hashtags"] else make_hashtags(subject,final_script,aspect_ratio))
    if aspect_ratio=="9:16" and "#Shorts" not in tags: tags=["#Shorts",*tags][:10]
    description=(llm_data["description"] if llm_data and llm_data["description"] else f"{safe_title}. Made with Universal AI Shorts Studio.")
    if llm_data: notice=f"Script written by {llm.provider_name()} - review and edit it before producing."
    elif used_template: notice="Template fallback is active - add your own script or configure Ollama/Claude (see README) for real scripts."+(f" ({llm_error})" if llm_error else "")
    elif prompt_as_story: notice="Detailed prompt split into timed story beats."
    else: notice="Scenes were segmented from your supplied text."
    return {
        "script":final_script,
        "planner":"llm" if llm_data else "template_fallback" if used_template else "prompt_segmentation" if prompt_as_story else "text_segmentation",
        "planner_notice":notice,
        "scenes":scenes,
        "metadata":{"titles":titles,"description":description,"hashtags":tags},
        "render_mode":"motion_graphics",
        "input_type":input_type,
        "character_description":_clean(character_description),
        "environment_description":_clean(environment_description),
    }

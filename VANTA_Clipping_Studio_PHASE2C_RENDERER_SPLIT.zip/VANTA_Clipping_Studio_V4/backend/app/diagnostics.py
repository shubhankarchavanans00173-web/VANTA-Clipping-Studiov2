from __future__ import annotations

import importlib.util
import shutil
import subprocess
import sys

from .config import DATA_DIR, OUTPUT_DIR, ROOT


def _gpu() -> dict:
    executable=shutil.which("nvidia-smi")
    if not executable: return {"available":False,"detail":"nvidia-smi was not found."}
    try:
        result=subprocess.run([executable,"--query-gpu=name,memory.total,driver_version","--format=csv,noheader"],capture_output=True,text=True,timeout=8)
        return {"available":result.returncode==0,"detail":result.stdout.strip() or result.stderr.strip()}
    except (OSError,subprocess.TimeoutExpired) as error:
        return {"available":False,"detail":str(error)}


def _tts() -> dict:
    """Probe the installed offline TTS engine, not just its Python package."""
    if importlib.util.find_spec("pyttsx3") is None:
        return {"installed":False,"working":False,"detail":"pyttsx3 is not installed."}
    try:
        # SAPI can block or crash inside COM on a machine with no voice token.
        # Keep that probe out of the API process and cap it to five seconds.
        code="import pyttsx3; e=pyttsx3.init(); print(len(e.getProperty('voices') or [])); e.stop()"
        result=subprocess.run([sys.executable,"-c",code],capture_output=True,text=True,timeout=5)
        if result.returncode!=0:
            detail=(result.stderr or "system voice probe failed").strip().splitlines()[-1]
            return {"installed":True,"working":False,"detail":f"System voice probe failed: {detail}"}
        count=int(result.stdout.strip() or "0")
        if count<1:
            return {"installed":True,"working":False,"detail":"pyttsx3 is installed, but no system voice is available."}
        return {"installed":True,"working":True,"voices":count,"detail":"System voice available."}
    except subprocess.TimeoutExpired:
        return {"installed":True,"working":False,"detail":"System voice probe timed out."}
    except Exception as error:
        return {"installed":True,"working":False,"detail":f"System voice probe failed: {error}"}


def diagnostics() -> dict:
    disk=shutil.disk_usage(DATA_DIR)
    worker_dir=ROOT/"backend"/"video_engine"
    candidates=["animatediff_worker.py","cinematic_multishot_worker.py"]
    return {
        "ffmpeg":bool(shutil.which("ffmpeg")),
        "ffprobe":bool(shutil.which("ffprobe")),
        "gpu":_gpu(),
        "free_disk_gib":round(disk.free/(1024**3),2),
        "data_directory":str(DATA_DIR),
        "output_writable":OUTPUT_DIR.exists() and OUTPUT_DIR.is_dir(),
        "python_packages":{
            "pyttsx3":importlib.util.find_spec("pyttsx3") is not None,
            "edge_tts":importlib.util.find_spec("edge_tts") is not None,
            "torch":importlib.util.find_spec("torch") is not None,
            "diffusers":importlib.util.find_spec("diffusers") is not None,
        },
        "tts":_tts(),
        "python":sys.executable,
        "animation_workers":{name:(worker_dir/name).exists() for name in candidates},
        "notes":[
            "Motion Graphics is separate; genuine AI-video availability and tested limits are reported under providers.",
            "No standalone animation worker scripts are bundled. Local AI generation uses the application provider adapter and requires compatible cached model weights."
        ],
    }

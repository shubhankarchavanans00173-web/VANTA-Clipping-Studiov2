"""Real stock footage from Pexels (free API key: https://www.pexels.com/api/).

Pexels licence allows free commercial use without attribution; we still collect the
creator names so they can be credited in the YouTube description.
"""
from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

import httpx

from .config import CACHE_DIR

API="https://api.pexels.com/videos/search"
STOCK_DIR=CACHE_DIR/"stock"
STOCK_DIR.mkdir(parents=True,exist_ok=True)


def api_key() -> str | None:
    return os.getenv("PEXELS_API_KEY") or None


def orientation_for(aspect: str) -> str:
    return {"9:16":"portrait","16:9":"landscape","1:1":"square"}.get(aspect,"landscape")


def pick_file(video: dict, width: int, height: int) -> dict | None:
    """Prefer the smallest MP4 that is still at least the target size (sharp but not 4K-huge)."""
    files=[f for f in video.get("video_files",[]) if f.get("file_type")=="video/mp4" and f.get("width") and f.get("height") and f.get("link")]
    if not files: return None
    need=min(width,height)
    big=[f for f in files if min(f["width"],f["height"])>=need]
    if big: return min(big,key=lambda f:f["width"]*f["height"])
    return max(files,key=lambda f:f["width"]*f["height"])


def pick_video(results: list[dict], min_seconds: float, used: set[int], width: int, height: int) -> tuple[dict,dict] | None:
    """Choose an unused clip, preferring ones at least as long as the scene."""
    ranked=sorted(results,key=lambda v:(v.get("id") in used, (v.get("duration") or 0)<min_seconds, -(v.get("duration") or 0) if (v.get("duration") or 0)<min_seconds else (v.get("duration") or 0)))
    for video in ranked:
        chosen=pick_file(video,width,height)
        if chosen: return video,chosen
    return None


def search(query: str, aspect: str, per_page: int=15) -> list[dict]:
    key=api_key()
    if not key: raise RuntimeError("PEXELS_API_KEY is not set.")
    r=httpx.get(API,params={"query":query,"orientation":orientation_for(aspect),"size":"medium","per_page":per_page},headers={"Authorization":key},timeout=30)
    if r.status_code==401: raise RuntimeError("Pexels rejected the API key (401). Check PEXELS_API_KEY in .env.")
    if r.status_code==429: raise RuntimeError("Pexels rate limit reached; try again later.")
    r.raise_for_status()
    return r.json().get("videos",[])


def download(link: str) -> Path:
    name=hashlib.sha1(link.encode()).hexdigest()[:16]+".mp4"
    target=STOCK_DIR/name
    if target.is_file() and target.stat().st_size>10000: return target
    tmp=target.with_suffix(".part")
    with httpx.stream("GET",link,timeout=120,follow_redirects=True) as r:
        r.raise_for_status()
        with tmp.open("wb") as handle:
            for chunk in r.iter_bytes(1024*256): handle.write(chunk)
    tmp.replace(target)
    return target


def fetch_for_scene(query: str, fallbacks: list[str], aspect: str, min_seconds: float, width: int, height: int, used: set[int]) -> dict | None:
    """Return {path, id, credit} or None if nothing matched (callers fall back to animated backgrounds)."""
    for q in [query,*fallbacks]:
        q=re.sub(r"\s+"," ",q or "").strip()
        if not q: continue
        picked=pick_video(search(q,aspect),min_seconds,used,width,height)
        if not picked: continue
        video,chosen=picked
        path=download(chosen["link"])
        used.add(video.get("id"))
        user=(video.get("user") or {}).get("name") or "Pexels contributor"
        return {"path":path,"id":video.get("id"),"credit":f"{user} / Pexels","query":q}
    return None

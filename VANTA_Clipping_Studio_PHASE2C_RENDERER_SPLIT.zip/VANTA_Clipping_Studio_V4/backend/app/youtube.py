"""YouTube Data API v3 upload (official OAuth, resumable upload, thumbnail).

Secrets stay on this machine:  data/secrets/client_secret.json  (you download it)  and
data/secrets/youtube_token.json (created after you click "Connect YouTube").
"""
from __future__ import annotations

import os
import re
import threading
import time
from pathlib import Path
from typing import Callable

from .config import ROOT, SECRETS_DIR

SCOPES=["https://www.googleapis.com/auth/youtube.upload","https://www.googleapis.com/auth/youtube.readonly"]
TOKEN_PATH=SECRETS_DIR/"youtube_token.json"
_connect_state={"state":"idle","error":None}
_lock=threading.Lock()


def client_secret_path() -> Path:
    env=os.getenv("YOUTUBE_CLIENT_SECRET_FILE")
    if env:
        p=Path(env); return p if p.is_absolute() else (ROOT/p)
    return SECRETS_DIR/"client_secret.json"


def libs_installed() -> bool:
    try:
        import googleapiclient, google_auth_oauthlib  # noqa: F401
        return True
    except ImportError:
        return False


def _credentials():
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    if not TOKEN_PATH.is_file(): return None
    try:
        creds=Credentials.from_authorized_user_file(str(TOKEN_PATH),SCOPES)
    except Exception as error:
        raise RuntimeError("Saved YouTube OAuth token could not be read. Disconnect it and connect again.") from error
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            TOKEN_PATH.write_text(creds.to_json(),encoding="utf-8")
        except Exception as error:
            raise RuntimeError("YouTube OAuth token refresh failed. Disconnect and connect again.") from error
    return creds if creds and creds.valid else None


def status() -> dict:
    info={"libraries":libs_installed(),"client_secret_found":client_secret_path().is_file(),"client_secret_path":str(client_secret_path()),
          "connected":False,"channel":None,"connect_state":_connect_state["state"],"connect_error":_connect_state["error"]}
    if not info["libraries"] or not TOKEN_PATH.is_file(): return info
    try:
        creds=_credentials()
        if creds:
            from googleapiclient.discovery import build
            yt=build("youtube","v3",credentials=creds,cache_discovery=False)
            items=yt.channels().list(part="snippet",mine=True).execute().get("items",[])
            info["connected"]=True; info["channel"]=items[0]["snippet"]["title"] if items else "(no channel found on this Google account)"
    except Exception as error:
        info["connect_error"]=f"Saved login is no longer valid: {str(error)[:160]}. Click Connect again."
    return info


def start_connect() -> dict:
    if not libs_installed(): raise RuntimeError("Install the YouTube libraries: pip install google-api-python-client google-auth-oauthlib")
    if not client_secret_path().is_file(): raise RuntimeError(f"Missing OAuth client file: {client_secret_path()} (see docs/YOUTUBE_SETUP.md).")
    with _lock:
        if _connect_state["state"]=="waiting": return {"state":"waiting"}
        _connect_state.update(state="waiting",error=None)
    def work():
        try:
            from google_auth_oauthlib.flow import InstalledAppFlow
            flow=InstalledAppFlow.from_client_secrets_file(str(client_secret_path()),SCOPES)
            creds=flow.run_local_server(port=0,open_browser=True,prompt="consent",authorization_prompt_message="Opening your browser to connect YouTube...",timeout_seconds=300)
            TOKEN_PATH.write_text(creds.to_json(),encoding="utf-8"); _connect_state.update(state="done",error=None)
        except Exception as error:
            _connect_state.update(state="error",error=str(error)[:300])
    threading.Thread(target=work,daemon=True,name="youtube-oauth").start()
    return {"state":"waiting"}


def disconnect() -> None:
    TOKEN_PATH.unlink(missing_ok=True); _connect_state.update(state="idle",error=None)


def clean_title(title: str, shorts: bool) -> str:
    title=re.sub(r"[<>]","",re.sub(r"\s+"," ",title)).strip() or "Untitled video"
    if shorts and "#shorts" not in title.lower() and len(title)<=91: title+=" #Shorts"
    return title[:100]


def clean_tags(tags: list[str]) -> list[str]:
    out=[]; total=0
    for t in tags:
        t=re.sub(r"[<>,#]","",t).strip()
        if t and len(t)<=60 and t.lower() not in [x.lower() for x in out] and total+len(t)+1<480:
            out.append(t); total+=len(t)+1
    return out


def upload(video: Path, thumbnail: Path | None, *, title: str, description: str, tags: list[str], privacy: str, made_for_kids: bool,
           ai_disclosure: bool, category_id: str, publish_at: str | None, shorts: bool,
           progress: Callable[[int],None]=lambda p:None) -> dict:
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaFileUpload
    if privacy not in {"private","unlisted","public"}:
        raise RuntimeError("YouTube privacy must be private, unlisted, or public.")
    if not video.is_file():
        raise RuntimeError("The exported MP4 is no longer on disk.")
    creds=_credentials()
    if not creds: raise RuntimeError("YouTube is not connected. Click 'Connect YouTube' first.")
    yt=build("youtube","v3",credentials=creds,cache_discovery=False)
    desc=description.strip()
    if shorts and "#shorts" not in desc.lower(): desc=(desc+"\n\n#Shorts").strip()
    body={"snippet":{"title":clean_title(title,shorts),"description":re.sub(r"[<>]","",desc)[:5000],"tags":clean_tags(tags),"categoryId":category_id or "22"},
          "status":{"privacyStatus":"private" if publish_at else privacy,"selfDeclaredMadeForKids":bool(made_for_kids)}}
    if publish_at: body["status"]["publishAt"]=publish_at
    notes=[]
    def run(include_synthetic: bool):
        b={**body,"status":{**body["status"]}}
        if include_synthetic: b["status"]["containsSyntheticMedia"]=True
        media=MediaFileUpload(str(video),mimetype="video/mp4",chunksize=8*1024*1024,resumable=True)
        req=yt.videos().insert(part="snippet,status",body=b,media_body=media)
        response=None; retries=0
        while response is None:
            try:
                st,response=req.next_chunk()
                if st: progress(int(st.progress()*100))
                retries=0
            except HttpError as error:
                status=getattr(getattr(error,"resp",None),"status",0)
                if status not in {500,502,503,504} or retries >= 3:
                    raise
                retries+=1; time.sleep(2 ** (retries-1))
            except (OSError, TimeoutError):
                if retries >= 3: raise
                retries+=1; time.sleep(2 ** (retries-1))
        return response
    try:
        response=run(ai_disclosure)
    except HttpError as error:
        if ai_disclosure and "containsSyntheticMedia" in str(error):
            notes.append("YouTube API did not accept the AI-disclosure flag; set 'Altered content' manually in YouTube Studio.")
            response=run(False)
        else:
            raise RuntimeError(_explain(error)) from error
    video_id=(response or {}).get("id")
    if not video_id:
        raise RuntimeError("YouTube did not confirm an uploaded video ID; no local upload success was recorded.")
    progress(100)
    if thumbnail and thumbnail.is_file():
        try:
            yt.thumbnails().set(videoId=video_id,media_body=MediaFileUpload(str(thumbnail),mimetype="image/jpeg")).execute()
        except HttpError as error:
            notes.append("Thumbnail not set: "+_explain(error)+" (custom thumbnails need a verified channel).")
    if body["status"]["privacyStatus"]=="private" and not publish_at:
        notes.append("Uploaded as PRIVATE. Projects created after July 2020 that have not passed Google's API audit are locked to private - open YouTube Studio to publish.")
    return {"video_id":video_id,"url":f"https://youtu.be/{video_id}","studio_url":f"https://studio.youtube.com/video/{video_id}/edit","notes":notes}


def _explain(error) -> str:
    text=str(error)
    if "quotaExceeded" in text: return "Daily YouTube API quota is used up (an upload costs 1,600 of 10,000 units). Try again tomorrow."
    if "uploadLimitExceeded" in text: return "YouTube upload limit reached for this channel today."
    if "invalid_grant" in text or "unauthorized" in text.lower(): return "YouTube login has expired or was revoked. Disconnect and connect again."
    if "rateLimitExceeded" in text or "userRateLimitExceeded" in text: return "YouTube is rate-limiting this account. Wait and retry the explicitly confirmed upload."
    if "forbidden" in text.lower(): return "YouTube refused the request (403). Check the channel is verified and the API is enabled."
    return text[:300]

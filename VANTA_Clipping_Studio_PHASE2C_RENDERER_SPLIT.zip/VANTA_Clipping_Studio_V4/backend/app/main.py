from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import re
import threading
from urllib.parse import urlparse
import uuid
import zipfile

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from .config import MAX_UPLOAD_BYTES, OUTPUT_DIR, UPLOAD_DIR
from . import stock, tts, youtube
from .diagnostics import diagnostics
from .planner import build_plan
from .renderer import render_video
from .schemas import CreateJobRequest, ProduceJobRequest, UpdateMetadataRequest, UpdateScriptRequest, UpdateStoryboardRequest, YouTubeAnalyzeRequest, YouTubeUploadRequest
from .store import create_job, delete_job, get_job, init_db, list_jobs, recover_interrupted_jobs, update_job, update_settings
from .video_providers import get_video_provider, online_provider_identifier, provider_status
from .clipstudio import pipeline as vanta_pipeline, router as vanta_router, scheduler as vanta_scheduler, youtube_upload as vanta_youtube_upload

app=FastAPI(title="VANTA Clipping Studio (on the Universal AI Shorts Studio backend)",version="4.0.0")
app.include_router(vanta_router.router)
app.add_middleware(CORSMiddleware,allow_origins=["http://localhost:3000","http://127.0.0.1:3000"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])

# One worker prevents concurrent GPU/CPU-heavy local renders. Queueing is deliberate.
EXECUTOR=ThreadPoolExecutor(max_workers=1,thread_name_prefix="studio-render")
UPLOADER=ThreadPoolExecutor(max_workers=1,thread_name_prefix="studio-youtube")
IN_FLIGHT:set[str]=set()
CANCEL_REQUESTED:set[str]=set()
QUEUE_LOCK=threading.Lock()
VIDEO_EXTENSIONS={".mp4",".mov",".mkv",".webm"}
AUDIO_EXTENSIONS={".mp3",".wav",".m4a",".aac",".ogg"}
IMAGE_EXTENSIONS={".png",".jpg",".jpeg",".webp"}


def importlib_found(name: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(name) is not None


@app.on_event("startup")
def startup() -> None:
    init_db()
    recover_interrupted_jobs()
    vanta_pipeline.startup()
    vanta_youtube_upload.recover_interrupted()
    vanta_scheduler.startup()


@app.on_event("shutdown")
def shutdown() -> None:
    vanta_scheduler.shutdown()


def _not_found(job_id: str) -> dict:
    job=get_job(job_id)
    if not job: raise HTTPException(404,"Job not found")
    return job


def _safe_output_path(job: dict, setting_name: str) -> Path:
    value=job["settings"].get(setting_name) if setting_name!="output_path" else job.get("output_path")
    if not value: raise HTTPException(404,"Requested output is not ready")
    path=Path(value).resolve()
    if OUTPUT_DIR.resolve() not in path.parents or not path.is_file():
        raise HTTPException(404,"Requested output is unavailable")
    return path


def _progress(job_id: str, value: int, message: str) -> None:
    if _cancelled(job_id): return
    update_job(job_id,progress=max(0,min(99,value)))
    update_settings(job_id,status_message=message)
    # Keep the persisted state useful to the dashboard and to recovery logic.
    if value >= 80 or message.lower().startswith("validat"):
        update_job(job_id,status="validating")
    elif value >= 15:
        update_job(job_id,status="producing")


def _cancelled(job_id: str) -> bool:
    with QUEUE_LOCK:
        return job_id in CANCEL_REQUESTED


def _online_generation(job: dict) -> bool:
    settings=job["settings"]
    return settings.get("generation_mode")=="online_ai" or (
        settings.get("generation_mode")=="hybrid" and settings.get("hybrid_online_enabled",False)
    )


def _generation_provider(job: dict) -> str:
    mode=job["settings"].get("generation_mode","motion_graphics")
    if mode=="motion_graphics":
        return "motion_graphics"
    if mode=="hybrid" and job["settings"].get("hybrid_online_enabled",False):
        return "online_ai"
    return "local_ai" if mode=="hybrid" else mode


def _produce_job(job_id: str) -> None:
    try:
        job=_not_found(job_id)
        if job["status"]=="cancelled": return
        update_job(job_id,status="planning",progress=5,error=None,output_path=None)
        _progress(job_id,10,"Preparing selected renderer")
        result=render_video(
            job_id,
            get_job(job_id),
            lambda progress,message:_progress(job_id,progress,message),
            lambda:_cancelled(job_id),
        )
        if _cancelled(job_id):
            update_job(job_id,status="cancelled",progress=0,error=None,output_path=None)
            return
        update_settings(job_id,**result)
        update_job(job_id,status="completed",progress=100,output_path=result["output_path"],error=None)
    except Exception as error:
        cancelled=_cancelled(job_id)
        update_job(
            job_id,
            status="cancelled" if cancelled else "failed",
            progress=0 if cancelled else int(get_job(job_id)["progress"] or 0),
            error=None if cancelled else str(error)[:3000],
        )
    finally:
        with QUEUE_LOCK:
            IN_FLIGHT.discard(job_id)
            CANCEL_REQUESTED.discard(job_id)


def _enqueue(job_id: str, preserve_generated_clips: bool=False) -> bool:
    with QUEUE_LOCK:
        if job_id in IN_FLIGHT: return False
        IN_FLIGHT.add(job_id)
    # A rerender must not keep exposing a previous MP4 while the new one is running.
    job=get_job(job_id)
    if job:
        settings=job["settings"]
        keys=("output_path","captions_path","thumbnail_path","validation","render_notice","status_message")
        if not preserve_generated_clips:
            keys=(*keys,"generated_clips","regenerate_scene_id")
        for key in keys:
            settings.pop(key,None)
        update_job(job_id,settings=settings)
    update_job(job_id,status="queued",progress=0,error=None,output_path=None)
    EXECUTOR.submit(_produce_job,job_id)
    return True


@app.get("/api/health")
def health():
    report=diagnostics()
    ready=report["ffmpeg"] and report["ffprobe"] and report["output_writable"]
    return {
        "status":"ok" if ready else "degraded",
        "service":"Universal AI Shorts Studio backend",
        "host":"127.0.0.1",
        "port":int(os.getenv("STUDIO_PORT","8000")),
        "ffmpeg":report["ffmpeg"],
        "ffprobe":report["ffprobe"],
        "output_writable":report["output_writable"],
    }


@app.get("/api/diagnostics")
def get_diagnostics():
    report=diagnostics()
    report["providers"]=provider_status()
    from . import llm
    report["studio"]={
        "stock_footage":bool(stock.api_key()),
        "neural_voice_package":importlib_found("edge_tts"),
        "script_writer":llm.provider_name(),
        "youtube":youtube.status(),
    }
    return report


@app.get("/api/providers")
def providers(): return provider_status()


@app.get("/api/jobs")
def jobs(): return list_jobs()


@app.post("/api/jobs")
def new_job(req: CreateJobRequest):
    payload=req.model_dump()
    plan=build_plan(
        topic=req.topic,script=req.script,source_text=req.source_text,duration=req.duration_seconds,
        style=req.visual_style,input_type=req.input_type,
        character_description=req.character_description,environment_description=req.environment_description,
        aspect_ratio=req.aspect_ratio,language=req.language,
    )
    job_id=uuid.uuid4().hex[:10]
    topic=req.topic.strip() or plan["metadata"]["titles"][0]
    settings={key:value for key,value in payload.items() if key not in {"topic","script","source_text"}}
    settings.update(plan)
    if req.input_type=="video_clips":
        url_title=Path(urlparse(req.source_video_url or "").path).name
        uploaded=list(UPLOAD_DIR.glob(f"{req.source_upload_id}_*")) if req.source_upload_id and re.fullmatch(r"[a-f0-9]{32}",req.source_upload_id) else []
        upload_title=Path(uploaded[0].name.split("_",1)[-1]).stem if uploaded else ""
        topic=req.topic.strip() or upload_title or Path(url_title).stem or "Source video clips"
    settings["selected_video_provider"]={
        "motion_graphics":"motion_graphics",
        "local_ai":"animatediff_local",
        "online_ai":online_provider_identifier(),
        "hybrid":online_provider_identifier() if req.hybrid_online_enabled else "animatediff_local",
    }[req.generation_mode]
    if req.input_type=="video_clips":
        settings["selected_video_provider"]="source_footage_ffmpeg"
    settings["online_approval_granted"]=False
    create_job(job_id,topic,plan["script"],settings)
    if req.workflow_mode=="auto" and req.generation_mode!="online_ai" and not (req.generation_mode=="hybrid" and req.hybrid_online_enabled):
        _enqueue(job_id)
    elif req.workflow_mode=="auto":
        update_settings(job_id,status_message="Paid online video is never started automatically. Select Produce and approve the request first.")
    return _not_found(job_id)


@app.get("/api/jobs/{job_id}")
def detail(job_id: str): return _not_found(job_id)


@app.get("/api/jobs/{job_id}/storyboard")
def storyboard(job_id: str):
    job=_not_found(job_id)
    return {"script":job.get("script") or "","scenes":job["settings"].get("scenes",[]),"planner":job["settings"].get("planner"),"planner_notice":job["settings"].get("planner_notice")}


@app.put("/api/jobs/{job_id}/script")
def edit_script(job_id: str, req: UpdateScriptRequest):
    job=_not_found(job_id)
    if job["status"] in {"queued","planning","producing","validating"}: raise HTTPException(409,"Wait for the active render before changing its script.")
    plan=build_plan(
        topic=job["topic"],script=req.script,source_text=None,duration=int(job["settings"]["duration_seconds"]),
        style=job["settings"].get("visual_style","motion_graphics"),input_type=job["settings"].get("input_type","script"),
        character_description=job["settings"].get("character_description",""),
        environment_description=job["settings"].get("environment_description",""),
        aspect_ratio=job["settings"].get("aspect_ratio","9:16"),language=job["settings"].get("language","English"),use_llm=False,
    )
    settings=job["settings"]; settings.update(plan)
    for key in ("output_path","captions_path","thumbnail_path","validation","render_notice","status_message","generated_clips","regenerate_scene_id"):
        settings.pop(key,None)
    update_job(job_id,script=plan["script"],settings=settings,status="draft",progress=0,error=None,output_path=None)
    return _not_found(job_id)


@app.put("/api/jobs/{job_id}/storyboard")
def edit_storyboard(job_id: str, req: UpdateStoryboardRequest):
    job=_not_found(job_id)
    if job["status"] in {"queued","planning","producing","validating"}: raise HTTPException(409,"Wait for the active render before changing its storyboard.")
    settings=job["settings"]; settings["scenes"]=req.scenes
    for key in ("output_path","captions_path","thumbnail_path","validation","render_notice","status_message","generated_clips","regenerate_scene_id"):
        settings.pop(key,None)
    update_job(job_id,settings=settings,status="draft",progress=0,error=None,output_path=None)
    return _not_found(job_id)


@app.put("/api/jobs/{job_id}/metadata")
def edit_metadata(job_id: str, req: UpdateMetadataRequest):
    job=_not_found(job_id)
    if job["status"] in {"queued","planning","producing","validating"}:
        raise HTTPException(409,"Wait for the active render before changing metadata.")
    settings=job["settings"]
    settings["metadata"]=req.model_dump()
    if job["status"]=="completed": update_job(job_id,settings=settings)      # keep the finished video
    else: update_job(job_id,settings=settings,status="draft",progress=0,error=None)
    return _not_found(job_id)


def _queue_requested_job(job_id: str, req: ProduceJobRequest, regenerate_scene_id: int | None=None):
    job=_not_found(job_id)
    if job["status"] in {"queued","planning","producing","validating"}: return {"accepted":False,"job_id":job_id,"message":"This job is already in the local render queue."}
    if regenerate_scene_id is not None:
        if job["settings"].get("generation_mode","motion_graphics")=="motion_graphics":
            raise HTTPException(409,"Scene-level regeneration is available only for AI-video jobs.")
        if job["status"]!="completed" or not job["settings"].get("generated_clips"):
            raise HTTPException(409,"Render the AI video successfully before regenerating an individual scene.")
        scene_ids={scene.get("id") for scene in job["settings"].get("scenes",[]) if isinstance(scene,dict)}
        if regenerate_scene_id not in scene_ids:
            raise HTTPException(404,"Storyboard scene not found.")
    online=_online_generation(job)
    if online and not req.approve_online:
        raise HTTPException(428,"This generation uses a paid online video provider. Explicit approval is required before a provider request can be made.")
    generation_mode=_generation_provider(job)
    if generation_mode!="motion_graphics":
        try:
            provider=get_video_provider(generation_mode)
        except RuntimeError as error:
            raise HTTPException(503,str(error)) from error
        update_settings(
            job_id,
            selected_video_provider=getattr(provider,"identifier",provider.name),
            online_approval_granted=bool(online and req.approve_online),
            regenerate_scene_id=regenerate_scene_id,
        )
    preserve_clips=regenerate_scene_id is not None or job["settings"].get("input_type")=="video_clips"
    if not _enqueue(job_id,preserve_generated_clips=preserve_clips):
        return {"accepted":False,"job_id":job_id,"message":"This job is already in the local render queue."}
    return {"accepted":True,"job_id":job_id}


@app.post("/api/jobs/{job_id}/produce")
def produce(job_id: str, req: ProduceJobRequest=ProduceJobRequest()):
    return _queue_requested_job(job_id,req)


@app.post("/api/jobs/{job_id}/approve")
def approve(job_id: str, req: ProduceJobRequest=ProduceJobRequest()):
    return _queue_requested_job(job_id,req)


@app.post("/api/jobs/{job_id}/retry")
def retry(job_id: str, req: ProduceJobRequest=ProduceJobRequest()):
    return _queue_requested_job(job_id,req)


@app.post("/api/jobs/{job_id}/scenes/{scene_id}/regenerate")
def regenerate_scene(job_id: str, scene_id: int, req: ProduceJobRequest=ProduceJobRequest()):
    return _queue_requested_job(job_id,req,regenerate_scene_id=scene_id)


@app.post("/api/jobs/{job_id}/cancel")
def cancel(job_id: str):
    job=_not_found(job_id)
    if job["status"] in {"planning","producing","validating"} and (
        job["settings"].get("generation_mode")!="motion_graphics"
        or job["settings"].get("input_type")=="video_clips"
    ):
        with QUEUE_LOCK: CANCEL_REQUESTED.add(job_id)
        update_job(job_id,status="cancelling")
        return {"cancelled":True,"job_id":job_id,"message":"Cancellation requested; the active local/model step will stop safely."}
    if job["status"] not in {"draft","queued"}:
        raise HTTPException(409,"Only draft or queued jobs, and active AI-video jobs, can be cancelled.")
    update_job(job_id,status="cancelled",progress=0,error=None)
    return {"cancelled":True,"job_id":job_id}


@app.get("/api/jobs/{job_id}/preview")
def preview(job_id: str): return FileResponse(_safe_output_path(_not_found(job_id),"output_path"),media_type="video/mp4")


@app.get("/api/jobs/{job_id}/download")
def download(job_id: str): return FileResponse(_safe_output_path(_not_found(job_id),"output_path"),media_type="video/mp4",filename=f"short_{job_id}.mp4")


@app.get("/api/jobs/{job_id}/captions")
def captions(job_id: str): return FileResponse(_safe_output_path(_not_found(job_id),"captions_path"),media_type="text/plain",filename=f"short_{job_id}.srt")


@app.get("/api/jobs/{job_id}/thumbnail")
def thumbnail(job_id: str):
    path=_safe_output_path(_not_found(job_id),"thumbnail_path")
    return FileResponse(path,media_type="image/jpeg" if path.suffix.lower()==".jpg" else "image/png",filename=f"thumbnail_{job_id}{path.suffix}")


@app.get("/api/jobs/{job_id}/clips/{clip_index}/preview")
def clip_preview(job_id: str, clip_index: int):
    job=_not_found(job_id)
    clip=next((item for item in job["settings"].get("generated_clips",[]) if item.get("index")==clip_index),None)
    if not clip: raise HTTPException(404,"Generated clip not found.")
    path=Path(clip["path"]).resolve()
    if OUTPUT_DIR.resolve() not in path.parents or not path.is_file():
        raise HTTPException(404,"Generated clip is unavailable.")
    return FileResponse(path,media_type="video/mp4",filename=f"scene_{clip.get('scene_index','')}_shot_{clip.get('segment_index','')}.mp4")


@app.get("/api/jobs/{job_id}/clips/{clip_index}/captions")
def clip_captions(job_id: str, clip_index: int):
    job=_not_found(job_id)
    clip=next((item for item in job["settings"].get("generated_clips",[]) if item.get("index")==clip_index),None)
    if not clip or not clip.get("captions_path"):
        raise HTTPException(404,"This clip has no subtitle export.")
    path=Path(str(clip["captions_path"])).resolve()
    if OUTPUT_DIR.resolve() not in path.parents or not path.is_file():
        raise HTTPException(404,"Clip subtitle is unavailable.")
    return FileResponse(path,media_type="text/plain",filename=path.name)


@app.get("/api/jobs/{job_id}/clips/download")
def download_clips(job_id: str):
    job=_not_found(job_id)
    clips=job["settings"].get("generated_clips",[])
    if job["settings"].get("input_type")!="video_clips" or not clips:
        raise HTTPException(404,"This job has no exported source-video clips.")
    archive=OUTPUT_DIR/job_id/"clips.zip"
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED) as bundle:
        manifest=[]
        for clip in clips:
            video=Path(str(clip.get("path",""))).resolve()
            if OUTPUT_DIR.resolve() not in video.parents or not video.is_file():
                raise HTTPException(404,"An exported clip is unavailable.")
            bundle.write(video,video.name)
            manifest.append({
                "clip":video.name,
                "start_seconds":clip.get("start_seconds"),
                "end_seconds":clip.get("end_seconds"),
                "duration_seconds":clip.get("duration_seconds"),
                "title":clip.get("title"),
                "has_audio":clip.get("has_audio"),
                "subtitle":Path(str(clip["captions_path"])).name if clip.get("captions_path") else None,
            })
            subtitle_value=clip.get("captions_path")
            if subtitle_value:
                subtitle=Path(str(subtitle_value)).resolve()
                if OUTPUT_DIR.resolve() not in subtitle.parents or not subtitle.is_file():
                    raise HTTPException(404,"An exported clip subtitle is unavailable.")
                bundle.write(subtitle,subtitle.name)
        bundle.writestr("clip_manifest.json",json.dumps(manifest,indent=2))
    return FileResponse(archive,media_type="application/zip",filename=f"clips_{job_id}.zip")


@app.post("/api/uploads")
async def upload(kind: str, file: UploadFile=File(...)):
    extensions={"video":VIDEO_EXTENSIONS,"audio":AUDIO_EXTENSIONS,"image":IMAGE_EXTENSIONS,"subtitle":{".srt",".vtt"}}.get(kind)
    if not extensions: raise HTTPException(400,"Upload kind must be video, audio, image, or subtitle.")
    original=Path(file.filename or "").name
    suffix=Path(original).suffix.lower()
    if suffix not in extensions: raise HTTPException(400,f"Unsupported {kind} file type.")
    upload_id=uuid.uuid4().hex
    target=UPLOAD_DIR/f"{upload_id}_{re.sub(r'[^A-Za-z0-9._-]','_',original)[:100]}"
    written=0
    try:
        with target.open("wb") as handle:
            while chunk:=await file.read(1024*1024):
                written+=len(chunk)
                if written>MAX_UPLOAD_BYTES: raise HTTPException(413,f"File exceeds the {MAX_UPLOAD_BYTES//(1024**3)} GiB local upload limit.")
                handle.write(chunk)
    except Exception:
        target.unlink(missing_ok=True)
        raise
    finally:
        await file.close()
    if written==0:
        target.unlink(missing_ok=True)
        raise HTTPException(400,"The uploaded file was empty.")
    return {"upload_id":upload_id,"name":original,"bytes":written,"kind":kind}


@app.post("/api/youtube/analyze")
def analyze(req: YouTubeAnalyzeRequest):
    parsed=urlparse(req.url)
    host=(parsed.hostname or "").lower()
    if host not in {"youtube.com","www.youtube.com","m.youtube.com","youtu.be","www.youtu.be"}:
        raise HTTPException(400,"Enter a valid YouTube URL.")
    return {
        "status":"limited",
        "mode":req.mode,
        "url":req.url,
        "message":"The URL is valid, but this local MVP does not download platform video or bypass access controls. For source clipping, upload video you are authorized to reuse. For remake mode, paste a permitted transcript or summary.",
    }


# ---------------------------------------------------------------- Studio Pro additions
@app.get("/api/voices")
def voices(): return {"voices":tts.list_voices()}


@app.delete("/api/jobs/{job_id}")
def remove_job(job_id: str):
    job=_not_found(job_id)
    if job["status"] in {"queued","planning","producing","validating","cancelling"}:
        raise HTTPException(409,"Cancel the active render before deleting this job.")
    import shutil
    folder=(OUTPUT_DIR/job_id).resolve()
    if OUTPUT_DIR.resolve() in folder.parents and folder.is_dir(): shutil.rmtree(folder,ignore_errors=True)
    delete_job(job_id)
    return {"deleted":True,"job_id":job_id}


@app.get("/api/youtube/status")
def youtube_status(): return youtube.status()


@app.post("/api/youtube/connect")
def youtube_connect():
    try: return youtube.start_connect()
    except RuntimeError as error: raise HTTPException(400,str(error)) from error


@app.post("/api/youtube/disconnect")
def youtube_disconnect():
    youtube.disconnect(); return {"connected":False}


def _upload_job(job_id: str, req: YouTubeUploadRequest) -> None:
    def state(**values): update_settings(job_id,youtube=values)
    try:
        job=_not_found(job_id); settings=job["settings"]; meta=settings.get("metadata") or {}
        video=_safe_output_path(job,"output_path")
        thumb=None
        if req.set_thumbnail and settings.get("thumbnail_path"):
            candidate=Path(str(settings["thumbnail_path"])).resolve()
            if OUTPUT_DIR.resolve() in candidate.parents and candidate.is_file(): thumb=candidate
        duration=float(settings.get("actual_duration_seconds") or settings.get("duration_seconds") or 0)
        shorts=settings.get("aspect_ratio")=="9:16" and duration<=180
        title=req.title.strip() or (meta.get("titles") or [job["topic"]])[0]
        hashtags=[h for h in meta.get("hashtags",[]) if h.strip()]
        description=req.description if req.description is not None else (meta.get("description","")+("\n\n"+" ".join(hashtags) if hashtags else ""))
        tags=req.tags or [h.lstrip("#") for h in hashtags]
        state(state="uploading",progress=0)
        result=youtube.upload(video,thumb,title=title,description=description,tags=tags,privacy=req.privacy,made_for_kids=req.made_for_kids,
                              ai_disclosure=req.ai_disclosure,category_id=req.category_id,publish_at=req.publish_at,shorts=shorts,
                              progress=lambda p:state(state="uploading",progress=p))
        state(state="done",progress=100,**result)
    except Exception as error:
        state(state="error",error=str(error)[:500])


@app.post("/api/jobs/{job_id}/youtube/upload")
def youtube_upload(job_id: str, req: YouTubeUploadRequest):
    job=_not_found(job_id)
    if job["status"]!="completed" or not job.get("output_path"): raise HTTPException(409,"Render the video successfully before uploading.")
    if (job["settings"].get("youtube") or {}).get("state")=="uploading": raise HTTPException(409,"An upload for this video is already running.")
    if req.publish_at:
        from datetime import datetime, timezone
        try: when=datetime.fromisoformat(req.publish_at.replace("Z","+00:00"))
        except ValueError as error: raise HTTPException(400,"publish_at must be an RFC 3339 date such as 2026-11-01T14:30:00Z.") from error
        if when.tzinfo is None or when<=datetime.now(timezone.utc): raise HTTPException(400,"Scheduled time must be in the future and include a timezone (use Z for UTC).")
    st=youtube.status()
    if not st["connected"]: raise HTTPException(409,"Connect YouTube first (YouTube panel -> Connect).")
    update_settings(job_id,youtube={"state":"queued","progress":0})
    UPLOADER.submit(_upload_job,job_id,req)
    return {"accepted":True,"job_id":job_id}

"""Narration, uploaded audio and audio-track mixing for the legacy renderer.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Callable
from .renderer_common import AUDIO_EXTENSIONS, _run, _safe_upload


def _voice(text: str, output: Path, speed: float) -> Path:
    try:
        import pyttsx3
        engine=pyttsx3.init()
        voices=engine.getProperty("voices") or []
        if not voices:
            engine.stop()
            raise RuntimeError("No Windows/system voice is installed. Add an offline system voice or disable narration.")
        engine.setProperty("rate",max(100,min(260,round(165*speed))))
        target=output/"narration.wav"
        engine.save_to_file(text[:8000],str(target)); engine.runAndWait(); engine.stop()
        if target.exists() and target.stat().st_size>1000: return target
    except Exception as error:
        detail=str(error).strip() or error.__class__.__name__
        raise RuntimeError(f"Local narration is unavailable: {detail}. Install/configure an offline system voice or disable narration.") from error
    raise RuntimeError("Local narration failed: pyttsx3 did not create an audio file. Disable narration or install/configure an offline system voice.")


def _audio_upload(settings: dict, setting_name: str, label: str) -> Path | None:
    upload_id=settings.get(setting_name)
    if not upload_id: return None
    path=_safe_upload(upload_id,AUDIO_EXTENSIONS)
    if not path:
        raise RuntimeError(f"The selected {label} upload is missing or has an unsupported audio format.")
    return path


def _optional_media(label: str, operation: Callable[[], Path | None], warnings: list[str]) -> Path | None:
    try:
        return operation()
    except Exception as error:
        warnings.append(f"{label} was skipped: {str(error).strip() or error.__class__.__name__}")
        return None


def _normalise_audio_track(source: Path, output: Path, name: str, duration: int) -> Path:
    ffmpeg=shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg is unavailable.")
    target=output/f"prepared_{name}.wav"
    _run(
        [
            ffmpeg,"-y","-hide_banner","-i",str(source),"-vn","-t",str(duration),
            "-ac","2","-ar","44100","-c:a","pcm_s16le",str(target),
        ],
        max(120,duration*10),
    )
    if not target.is_file() or target.stat().st_size<1000:
        raise RuntimeError("Audio conversion did not produce a usable track.")
    return target


def _add_audio_tracks(
    command: list[str],
    filters: list[str],
    input_index: int,
    duration: int,
    narration: Path | None,
    music: Path | None,
    sound_effects: Path | None,
) -> bool:
    tracks=[]
    for name,path,volume in (
        ("narration",narration,1.0),
        ("music",music,0.16),
        ("effects",sound_effects,0.35),
    ):
        if not path: continue
        if name=="music":
            command.extend(["-stream_loop","-1","-i",str(path)])
        else:
            command.extend(["-i",str(path)])
        label=f"audio_{name}"
        filters.append(
            f"[{input_index}:a]volume={volume},apad=pad_dur={duration},atrim=0:{duration}[{label}]"
        )
        tracks.append(f"[{label}]")
        input_index+=1
    if len(tracks)>1:
        filters.append("".join(tracks)+f"amix=inputs={len(tracks)}:duration=longest:dropout_transition=0[aout]")
    elif tracks:
        filters.append(f"{tracks[0]}anull[aout]")
    return bool(tracks)

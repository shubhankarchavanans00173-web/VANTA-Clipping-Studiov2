"""Shared helpers for the legacy renderer: constants, sizing, fonts, text wrap, safe upload lookup, FFmpeg runner.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import os
import re
import subprocess
from .config import UPLOAD_DIR
from PIL import Image, ImageFont
from io import BytesIO
from pathlib import Path


DEFAULT_FPS=30
AUDIO_EXTENSIONS={".mp3",".wav",".m4a",".aac",".ogg"}
MAX_DIRECT_VIDEO_BYTES=512*1024*1024


def dims(ratio: str, preset: str="balanced") -> tuple[int,int]:
    # These are deliberate local output caps, not claimed AI-model quality tiers.
    sizes={
        "draft":{"9:16":(360,640),"16:9":(640,360),"1:1":(480,480)},
        "balanced":{"9:16":(720,1280),"16:9":(1280,720),"1:1":(900,900)},
        "quality":{"9:16":(1080,1920),"16:9":(1920,1080),"1:1":(1080,1080)},
    }
    return sizes.get(preset,sizes["balanced"])[ratio]


def getfont(size: int):
    for candidate in [r"C:\Windows\Fonts\arial.ttf",r"C:\Windows\Fonts\segoeui.ttf","/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
        if os.path.exists(candidate):
            try: return ImageFont.truetype(candidate,size)
            except OSError: pass
    return ImageFont.load_default()


def wrap(text: str, limit: int) -> list[str]:
    words=text.split(); lines=[]; line=""
    for word in words:
        if len(line)+len(word)+1>limit and line:
            lines.append(line); line=word
        else: line=(line+" "+word).strip()
    if line: lines.append(line)
    return lines


def _safe_upload(upload_id: str | None, extensions: set[str]) -> Path | None:
    if not upload_id or not re.fullmatch(r"[a-f0-9]{32}",upload_id): return None
    found=list(UPLOAD_DIR.glob(f"{upload_id}_*"))
    if len(found)!=1: return None
    candidate=found[0].resolve()
    if UPLOAD_DIR.resolve() not in candidate.parents or candidate.suffix.lower() not in extensions:
        return None
    return candidate


def _timestamp(seconds: float) -> str:
    millis=round(max(0,seconds)*1000)
    hours,millis=divmod(millis,3_600_000)
    minutes,millis=divmod(millis,60_000)
    whole,millis=divmod(millis,1000)
    return f"{hours:02d}:{minutes:02d}:{whole:02d},{millis:03d}"


def _run(command: list[str], timeout: int, cwd: Path | None=None) -> None:
    result=subprocess.run(command,capture_output=True,text=True,timeout=timeout,cwd=cwd)
    if result.returncode:
        detail=(result.stderr or result.stdout or "unknown error")[-1800:]
        raise RuntimeError(f"FFmpeg render failed: {detail}")


def _fraction(value: str) -> float:
    try:
        numerator,denominator=value.split("/",1)
        return float(numerator)/float(denominator)
    except (ValueError,ZeroDivisionError,AttributeError): return 0.0


def _sample_image(ffmpeg: str, video: Path, at: float) -> Image.Image | None:
    result=subprocess.run([ffmpeg,"-v","error","-ss",str(max(0,at)),"-i",str(video),"-frames:v","1","-f","image2pipe","-vcodec","png","-"],capture_output=True,timeout=30)
    if result.returncode or not result.stdout: return None
    with Image.open(BytesIO(result.stdout)) as image:
        return image.convert("RGB").resize((32,32)).copy()

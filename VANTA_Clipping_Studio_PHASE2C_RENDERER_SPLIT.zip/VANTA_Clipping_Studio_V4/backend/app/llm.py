"""Optional script writer. Uses a FREE local Ollama model or the Claude API when configured.

Nothing here is required: if no provider is configured (or a call fails) the planner
falls back to deterministic text segmentation and says so in `planner_notice`.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

import httpx

SYSTEM="""You write voice-over scripts for YouTube videos. Reply with ONLY valid JSON, no markdown.
Schema: {"titles":[3 catchy titles <=70 chars],"description":"2-3 sentence YouTube description",
"hashtags":["#tag",... max 8],"scenes":[{"title":"2-4 word scene title","narration":"spoken text","search_query":"2-4 word concrete visual to search stock footage for"}]}
Rules: strong hook in scene 1, one idea per scene, plain spoken language, no stage directions, no emojis,
no claims you cannot stand behind, end with a short call to action. Narration is read aloud at ~2.5 words/second."""


def provider_name() -> str | None:
    if os.getenv("ANTHROPIC_API_KEY"): return "anthropic"
    if os.getenv("OLLAMA_MODEL"): return "ollama"
    return None


def _extract_json(text: str) -> dict[str, Any]:
    text=text.strip()
    text=re.sub(r"^```(?:json)?|```$","",text,flags=re.M).strip()
    start,end=text.find("{"),text.rfind("}")
    if start<0 or end<=start: raise ValueError("model did not return JSON")
    return json.loads(text[start:end+1])


def _validate(data: dict[str, Any]) -> dict[str, Any]:
    scenes=[]
    for item in data.get("scenes") or []:
        narration=str(item.get("narration","")).strip()
        if len(narration)<3: continue
        scenes.append({"title":str(item.get("title") or "")[:80],"narration":narration[:900],"search_query":str(item.get("search_query") or "")[:80]})
    if not scenes: raise ValueError("model returned no usable scenes")
    titles=[str(t).strip()[:100] for t in (data.get("titles") or []) if str(t).strip()][:3]
    tags=[("#"+re.sub(r"\W+","",str(t).lstrip("#")))[:40] for t in (data.get("hashtags") or []) if re.sub(r"\W+","",str(t))][:10]
    return {"scenes":scenes[:60],"titles":titles,"description":str(data.get("description") or "")[:4000],"hashtags":tags}


def write_script(topic: str, duration: int, language: str, style: str) -> dict[str, Any]:
    """Return validated script JSON or raise RuntimeError with a human-readable reason."""
    provider=provider_name()
    if not provider: raise RuntimeError("no LLM configured")
    words=int(duration*2.5)
    user=(f"Topic / idea: {topic}\nLanguage: {language}\nVisual style: {style.replace('_',' ')}\n"
          f"Target length: about {words} spoken words (~{duration} seconds). Use {max(3,min(40,round(duration/8)))} scenes.")
    try:
        if provider=="anthropic":
            r=httpx.post("https://api.anthropic.com/v1/messages",timeout=90,headers={
                "x-api-key":os.environ["ANTHROPIC_API_KEY"],"anthropic-version":"2023-06-01","content-type":"application/json"},
                json={"model":os.getenv("STUDIO_LLM_MODEL","claude-haiku-4-5"),"max_tokens":4000,"system":SYSTEM,
                      "messages":[{"role":"user","content":user}]})
            r.raise_for_status()
            text="".join(b.get("text","") for b in r.json().get("content",[]))
        else:
            r=httpx.post(os.getenv("OLLAMA_URL","http://127.0.0.1:11434")+"/api/chat",timeout=300,json={
                "model":os.environ["OLLAMA_MODEL"],"stream":False,"format":"json",
                "messages":[{"role":"system","content":SYSTEM},{"role":"user","content":user}]})
            r.raise_for_status()
            text=r.json()["message"]["content"]
        return _validate(_extract_json(text))
    except Exception as error:
        raise RuntimeError(f"{provider} script generation failed: {error}") from error

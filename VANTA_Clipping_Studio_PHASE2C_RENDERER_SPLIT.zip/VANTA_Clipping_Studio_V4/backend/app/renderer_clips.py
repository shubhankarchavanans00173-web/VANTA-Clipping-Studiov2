"""Source-clip window selection, SRT slicing and the clip render path of the legacy renderer.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import shutil
import subprocess
import textwrap
from PIL import Image, ImageDraw
from pathlib import Path
from typing import Callable
from .renderer_common import _run, _safe_upload, _timestamp, getfont
from .renderer_validate import validate_output


def _scene_changes(ffmpeg: str, source: Path, threshold: float=0.25) -> list[tuple[float,float]]:
    result=subprocess.run(
        [
            ffmpeg,"-hide_banner","-i",str(source),
            "-vf",f"select='gt(scene,{threshold})',metadata=print",
            "-an","-f","null","-",
        ],
        capture_output=True,text=True,timeout=300,
    )
    if result.returncode and "Output file is empty" not in result.stderr:
        raise RuntimeError("Scene analysis failed: "+(result.stderr or "FFmpeg returned an error")[-1200:])
    events=[]
    current_time=None
    current_score=0.0
    for line in result.stderr.splitlines():
        pts=re.search(r"pts_time:([0-9]+(?:\.[0-9]+)?)",line)
        score=re.search(r"lavfi\.scene_score=([0-9]+(?:\.[0-9]+)?)",line)
        if pts:
            current_time=float(pts.group(1))
            current_score=0.0
        elif score and current_time is not None:
            current_score=float(score.group(1))
            events.append((current_time,current_score))
            current_time=None
    return events


def _select_clip_windows(
    source_duration: float,
    scene_changes: list[tuple[float,float]],
    clip_seconds: float,
    max_clips: int,
) -> list[tuple[float,float]]:
    clip_seconds=min(max(1.0,clip_seconds),source_duration)
    count=min(max(1,max_clips),max(1,math.ceil(source_duration/clip_seconds)))
    if source_duration<clip_seconds+0.05:
        return [(0.0,source_duration)]

    def score(start: float,window_seconds: float) -> float:
        end=start+window_seconds
        return sum(scene_score for at,scene_score in scene_changes if start-0.25<=at<=end+0.25)

    windows=[]
    for index in range(count):
        band_start=source_duration*index/count
        band_end=source_duration*(index+1)/count
        window_seconds=min(clip_seconds,band_end-band_start)
        band_max_start=max(band_start,band_end-window_seconds)
        candidates={round(band_start,3),round(band_max_start,3)}
        candidates.update(
            round(max(band_start,min(band_max_start,at-window_seconds/2)),3)
            for at,_ in scene_changes
        )
        selected=max(candidates,key=lambda start:(score(start,window_seconds),-start))
        windows.append((selected,min(source_duration,selected+window_seconds)))
    return windows


def _parse_srt_time(value: str) -> float:
    match=re.fullmatch(r"(?:(\d{2}):)?(\d{2}):(\d{2})[,.](\d{3})",value.strip())
    if not match:
        raise ValueError("Invalid subtitle timestamp.")
    hours,minutes,seconds,millis=(int(part or 0) for part in match.groups())
    return hours*3600+minutes*60+seconds+millis/1000


def _slice_srt(source: Path, destination: Path, start: float, end: float) -> bool:
    text=source.read_text(encoding="utf-8-sig")
    if text.lstrip().startswith("WEBVTT"):
        text=re.sub(r"^\s*WEBVTT[^\n]*\n","",text.lstrip(),count=1)
        text=re.sub(r"(?m)(\d{2}:\d{2}:\d{2})\.(\d{3})",r"\1,\2",text)
    blocks=[]
    for block in re.split(r"\r?\n\s*\r?\n",text.strip()):
        lines=block.splitlines()
        timing_index=next((index for index,line in enumerate(lines) if "-->" in line),None)
        if timing_index is None:
            continue
        time_match=re.match(r"\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[,.]\d{3})",lines[timing_index])
        if not time_match:
            continue
        cue_start,cue_end=map(_parse_srt_time,time_match.groups())
        visible_start=max(start,cue_start)
        visible_end=min(end,cue_end)
        caption="\n".join(lines[timing_index+1:]).strip()
        if visible_start>=visible_end or not caption:
            continue
        blocks.append(
            f"{len(blocks)+1}\n{_timestamp(visible_start-start)} --> {_timestamp(visible_end-start)}\n{caption}"
        )
    if not blocks:
        return False
    destination.write_text("\n\n".join(blocks)+"\n",encoding="utf-8")
    return True


def _title_overlay(title: str, path: Path, width: int) -> None:
    height=max(72,int(width*0.16))
    image=Image.new("RGBA",(width,height),(0,0,0,0))
    draw=ImageDraw.Draw(image)
    margin=max(10,int(width*0.035))
    draw.rounded_rectangle((margin,margin,width-margin,height-margin),radius=max(8,int(width*.025)),fill=(0,0,0,170))
    font=getfont(max(18,int(width*.042)))
    lines=textwrap.wrap(title,max(14,width//24))[:2]
    line_height=max(24,int(width*.05))
    y=(height-line_height*len(lines))//2
    for line in lines:
        bounds=draw.textbbox((0,0),line,font=font,stroke_width=1)
        x=(width-(bounds[2]-bounds[0]))//2
        draw.text((x,y),line,font=font,fill=(255,255,255,255),stroke_width=1,stroke_fill=(0,0,0,255))
        y+=line_height
    image.save(path)


def _render_video_clips(
    job_id: str,
    settings: dict,
    source: Path,
    output: Path,
    width: int,
    height: int,
    fps: int,
    progress: Callable[[int,str],None],
    cancelled: Callable[[],bool],
) -> dict:
    ffmpeg=shutil.which("ffmpeg")
    ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        raise RuntimeError("FFmpeg and ffprobe must both be available for Video-to-Clips.")
    probe=subprocess.run(
        [ffprobe,"-v","error","-show_streams","-show_format","-of","json",str(source)],
        capture_output=True,text=True,timeout=30,
    )
    if probe.returncode:
        raise RuntimeError("Could not analyze the source video: "+probe.stderr[-1000:])
    media=json.loads(probe.stdout)
    stream=next((item for item in media.get("streams",[]) if item.get("codec_type")=="video"),None)
    source_duration=float(media.get("format",{}).get("duration") or 0)
    if not stream or source_duration<=0:
        raise RuntimeError("The source must contain a decodable video stream with a known duration.")
    has_audio=any(item.get("codec_type")=="audio" for item in media.get("streams",[]))
    source_stat=source.stat()
    source_fingerprint=hashlib.sha256(
        f"{source.resolve()}:{source_stat.st_size}:{source_stat.st_mtime_ns}".encode("utf-8")
    ).hexdigest()
    progress(20,"Analyzing source duration and visual scene changes")
    scene_changes=_scene_changes(ffmpeg,source)
    clip_seconds=float(settings.get("clip_duration_seconds",settings.get("duration_seconds",15)))
    windows=_select_clip_windows(source_duration,scene_changes,clip_seconds,int(settings.get("clip_count",5)))
    optional_warnings=[]
    subtitle_id=settings.get("subtitle_upload_id")
    subtitle=_safe_upload(subtitle_id,{".srt",".vtt"}) if subtitle_id else None
    if subtitle_id and not subtitle:
        optional_warnings.append("Uploaded subtitles were skipped because the file is missing or unavailable.")
    clips=[]
    segment_manifest=[]
    subtitle_export_count=0
    title=settings.get("clip_title") or settings.get("topic") or "Video highlights"
    for index,(start,end) in enumerate(windows,1):
        if cancelled():
            raise RuntimeError("Video clipping was cancelled.")
        clip_duration=end-start
        clip=output/f"clip_{index:02d}.mp4"
        local_srt=output/f"clip_{index:02d}.srt" if subtitle else None
        try:
            has_clip_subtitles=bool(subtitle and _slice_srt(subtitle,local_srt,start,end))
        except (OSError,UnicodeError,ValueError) as error:
            has_clip_subtitles=False
            optional_warnings.append(f"Subtitle processing for clip {index} was skipped: {error}")
        overlay=output/f"clip_{index:02d}_title.png"
        use_title=bool(settings.get("clip_title_overlay",True))
        if use_title:
            _title_overlay(f"{title} · Clip {index}",overlay,width)
        clip_metadata_path=output/f"clip_{index:02d}.json"
        expected_metadata={
            "source_fingerprint":source_fingerprint,
            "start_seconds":round(start,3),
            "end_seconds":round(end,3),
            "width":width,
            "height":height,
            "fps":fps,
            "title":title,
            "title_overlay":use_title,
            "subtitle_upload_id":subtitle_id,
        }
        command=[ffmpeg,"-y","-hide_banner","-ss",f"{start:.3f}","-i",str(source),"-t",f"{clip_duration:.3f}"]
        if use_title:
            command.extend(["-loop","1","-i",str(overlay)])
        video_filter=(
            f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},fps={fps},setsar=1"
        )
        filters=[f"[0:v]{video_filter},format=rgba[vbase]"]
        current="[vbase]"
        if has_clip_subtitles:
            filters.append(f"{current}subtitles=filename='clip_{index:02d}.srt'[vsub]")
            current="[vsub]"
        if use_title:
            filters.append(f"{current}[1:v]overlay=(W-w)/2:H*0.04:shortest=1[vtitle]")
            current="[vtitle]"
        filters.append(f"{current}format=yuv420p[vout]")
        command.extend(["-filter_complex",";".join(filters),"-map","[vout]"])
        if has_audio:
            command.extend(["-map","0:a?","-c:a","aac","-b:a","128k"])
        command.extend(["-t",f"{clip_duration:.3f}","-r",str(fps),"-c:v","libx264","-preset","veryfast","-crf","23","-movflags","+faststart",str(clip)])
        progress(25+round(45*(index-1)/max(1,len(windows))),f"Exporting source clip {index}/{len(windows)} at {start:.2f}s")
        reuse=False
        if clip.is_file():
            try:
                existing=validate_output(clip,width,height,max(1,int(clip_duration)),has_audio,fps)
                saved_metadata=json.loads(clip_metadata_path.read_text(encoding="utf-8"))
                reuse=(
                    existing["valid"]
                    and existing["duration_seconds"]>=clip_duration*.75
                    and all(saved_metadata.get(key)==value for key,value in expected_metadata.items())
                )
            except (OSError,RuntimeError,ValueError,KeyError,json.JSONDecodeError):
                reuse=False
        if not reuse:
            try:
                _run(command,max(180,int(clip_duration*30)),cwd=output)
            except RuntimeError as error:
                if not (use_title or has_clip_subtitles):
                    raise
                optional_warnings.append(f"Optional title or subtitle overlay for clip {index} was skipped: {error}")
                clip.unlink(missing_ok=True)
                use_title=False
                has_clip_subtitles=False
                expected_metadata["title_overlay"]=False
                expected_metadata["subtitle_upload_id"]=None
                fallback=[
                    ffmpeg,"-y","-hide_banner","-ss",f"{start:.3f}","-i",str(source),
                    "-t",f"{clip_duration:.3f}","-vf",f"{video_filter},format=yuv420p",
                    "-map","0:v:0",
                ]
                if has_audio:
                    fallback.extend(["-map","0:a?","-c:a","aac","-b:a","128k"])
                fallback.extend(["-t",f"{clip_duration:.3f}","-r",str(fps),"-c:v","libx264","-preset","veryfast","-crf","23","-movflags","+faststart",str(clip)])
                _run(fallback,max(180,int(clip_duration*30)),cwd=output)
                has_clip_subtitles=False
        validation=validate_output(clip,width,height,max(1,int(clip_duration)),has_audio,fps)
        if not validation["valid"]:
            raise RuntimeError(f"Source clip {index} failed output validation.")
        clip_metadata_path.write_text(json.dumps(expected_metadata,indent=2),encoding="utf-8")
        if has_clip_subtitles:
            subtitle_export_count+=1
        entry={
            "index":index,
            "scene_index":index,
            "segment_index":1,
            "path":str(clip),
            "title":f"{title} · Clip {index}",
            "start_seconds":round(start,3),
            "end_seconds":round(end,3),
            "duration_seconds":round(clip_duration,3),
            "motion_score":None,
            "has_audio":has_audio,
            "captions_path":str(local_srt) if has_clip_subtitles else None,
            "validation":validation,
        }
        clips.append(entry)
        segment_manifest.append({key:entry[key] for key in ("index","title","start_seconds","end_seconds","duration_seconds","has_audio")})
    if not clips:
        raise RuntimeError("Scene analysis did not produce any exportable video clips.")
    thumbnail=output/"thumbnail.png"
    _run([ffmpeg,"-y","-hide_banner","-ss","0.2","-i",clips[0]["path"],"-frames:v","1",str(thumbnail)],30)
    return {
        "output_path":clips[0]["path"],
        "captions_path":None,
        "thumbnail_path":str(thumbnail) if thumbnail.exists() else None,
        "render_mode":"ffmpeg_source_clips",
        "generation_mode":"source_clips",
        "generated_clips":clips,
        "validation":{
            **clips[0]["validation"],
            "clip_count":len(clips),
            "source_duration_seconds":round(source_duration,3),
            "source_width":stream.get("width"),
            "source_height":stream.get("height"),
            "scene_change_count":len(scene_changes),
            "clips":segment_manifest,
        },
        "render_notice":(
            f"Exported {len(clips)} real source-footage clips with timestamped cuts, "
            f"cropped to {settings['aspect_ratio']}; source audio was "
            f"{'preserved' if has_audio else 'not present'}. "
        f"{f'Subtitles were trimmed for {subtitle_export_count} clip(s).' if subtitle_export_count else 'No matching subtitles were exported.'} "
        f"{' '.join(optional_warnings)}"
        ),
    }

"""Studio Pro: narration-timed, stock-footage / animated-background video with burned-in captions.

Pipeline
  1. narration per scene (edge neural voice -> system voice -> silent) => real scene durations + word timings
  2. one background clip per scene (own images > Pexels stock > animated gradient) + shade + title chip
  3. ONE final encode: cross-fade chain, karaoke captions, progress bar, watermark, music ducking,
     -14 LUFS loudness, H.264 High / AAC 192k / bt709 / faststart (YouTube-friendly)
  4. YouTube-style thumbnail + word-timed SRT + validation
"""
from __future__ import annotations

import os
import re
import shutil
from pathlib import Path
from typing import Callable

from PIL import Image

from . import captions as cap
from . import stock, thumbs, tts
from .config import UPLOAD_DIR
from .renderer import (
    DEFAULT_FPS, _audio_upload, _normalise_scenes, _palette, _run, _safe_upload, validate_output,
)

TRANSITIONS=["fade","smoothleft","dissolve","smoothup","fade","circleopen"]
XFADE=0.4
IMAGE_EXT={".png",".jpg",".jpeg",".webp"}
QUALITY={  # preset -> (x264 preset, crf)
    "quality":("medium",17),
    "balanced":("fast",20),
    "draft":("veryfast",25),
}


def _hex(rgb) -> str:
    return "0x%02X%02X%02X"%tuple(max(0,min(255,int(v))) for v in rgb)


def _scale(rgb, k):
    return tuple(v*k for v in rgb)


def _palette_for(settings: dict, index: int):
    bg,accent,second=_palette(settings.get("visual_style","motion_graphics"))
    if settings.get("accent_color"): accent=thumbs.hex_rgb(settings["accent_color"],accent)
    cols=[_scale(accent,.95),_scale(second,.8),_scale(bg,2.6),_scale(accent,.5)]
    k=index%4
    return cols[k:]+cols[:k],accent


def _check(cancelled: Callable[[],bool]) -> None:
    if cancelled(): raise RuntimeError("Cancelled by user.")


def _reference_images(settings: dict) -> list[Path]:
    out=[]
    for upload_id in settings.get("reference_upload_ids") or []:
        p=_safe_upload(upload_id,IMAGE_EXT)
        if p: out.append(p)
    return out


def _chunks_for_words(text: str, start: float, end: float):
    return tts.estimate_words(text,max(0.2,end-start))


def _plan_audio(scenes, settings, work, progress, cancelled, warnings):
    """Return per-scene dicts with duration, narration audio, words (scene-relative)."""
    want=bool(settings.get("narration"))
    engine=settings.get("narration_engine","edge")
    if os.getenv("STUDIO_TTS_ENGINE")=="test": engine="test"
    voice=settings.get("voice") or "en-US-AndrewNeural"
    speed=float(settings.get("narration_speed",1.0))
    out=[]; tts_ok=want; fallback_used=False
    for i,scene in enumerate(scenes):
        _check(cancelled)
        planned=max(2.0,scene["end_seconds"]-scene["start_seconds"])
        info=None
        if tts_ok:
            progress(12+int(16*i/len(scenes)),f"Recording narration {i+1}/{len(scenes)}")
            order=[engine]+([] if engine in ("system","test") else ["system"])
            for eng in order:
                try:
                    info=tts.synthesize(scene["narration"],work,f"nar_{i:02d}",eng,voice,speed)
                    if eng!=engine and not fallback_used:
                        warnings.append("Neural voice unavailable - used the offline system voice instead."); fallback_used=True
                    break
                except RuntimeError as error:
                    last=str(error)
            if info is None:
                warnings.append(f"Narration skipped: {last}"); tts_ok=False
                out=[{**o,"audio":None} for o in out]
        if info:
            out.append({"duration":max(2.0,info["duration"]+(0.55 if i<len(scenes)-1 else 0.9)),"audio":info["path"],
                        "lead":0.12,"words":info["words"]})
        else:
            out.append({"duration":planned,"audio":None,"lead":0.2,"words":_chunks_for_words(scene["narration"],0,planned-0.5)})
    # if narration failed halfway, keep everything on the planned timeline for consistency
    if want and not tts_ok:
        out=[{"duration":max(2.0,s["end_seconds"]-s["start_seconds"]),"audio":None,"lead":0.2,
              "words":_chunks_for_words(s["narration"],0,max(1.0,s["end_seconds"]-s["start_seconds"]-0.5))} for s in scenes]
    return out


def _segment(i, n, scene, spec, settings, work, width, height, fps, source, shade, wm_dims, accent_rgb, cancelled):
    """Render one background clip (video only) of length duration(+xfade)."""
    ffmpeg=shutil.which("ffmpeg")
    length=spec["duration"]+(XFADE if (settings.get("transitions",True) and i<n-1) else 0)
    seg=work/f"seg_{i:02d}.mp4"
    show_title=bool(scene.get("title")) and spec["duration"]>=3.2 and not re.fullmatch(r"Scene \d+",scene["title"])
    cmd=[ffmpeg,"-y","-hide_banner","-loglevel","error"]
    grade="eq=brightness=-0.05:saturation=1.12:contrast=1.04,vignette=PI/6"
    if source["kind"]=="stock":
        cmd+=["-stream_loop","-1","-i",str(source["path"])]
        base=f"[0:v]scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps={fps},setsar=1,{grade}[bg]"
    elif source["kind"]=="image":
        cmd+=["-loop","1","-framerate",str(fps),"-i",str(source["path"])]
        inc=0.12/max(1,length*fps)
        z=f"min(1.12,1+{inc:.7f}*on)" if i%2==0 else f"max(1.0,1.12-{inc:.7f}*on)"
        base=(f"[0:v]scale={width*2}:{height*2}:force_original_aspect_ratio=increase,crop={width*2}:{height*2},"
              f"zoompan=z='{z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s={width}x{height}:fps={fps},setsar=1,{grade}[bg]")
    else:
        cols,_=_palette_for(settings,i)
        cmd+=["-f","lavfi","-i",f"gradients=s={width}x{height}:r={fps}:c0={_hex(cols[0])}:c1={_hex(cols[1])}:c2={_hex(cols[2])}:c3={_hex(cols[3])}:nb_colors=4:speed=0.025:seed={i*7+3}:duration={length:.3f}"]
        base=f"[0:v]noise=alls=4:allf=t,vignette=PI/5,setsar=1,fps={fps}[bg]"
    cmd+=["-loop","1","-framerate",str(fps),"-i",str(shade)]
    graph=[base,"[bg][1:v]overlay=0:0:format=auto[b2]"]
    if show_title:
        chip=work/f"chip_{i:02d}.png"; cw,ch=thumbs.title_chip(scene["title"],chip,width,accent_rgb)
        cmd+=["-loop","1","-framerate",str(fps),"-i",str(chip)]
        y0=round(height*(0.095 if height>width else 0.07)); x=(width-cw)//2
        graph.append("[2:v]format=rgba,fade=t=in:st=0.15:d=0.4:alpha=1,fade=t=out:st=2.7:d=0.4:alpha=1[ch]")
        graph.append(f"[b2][ch]overlay=x={x}:y='{y0}+26*pow(1-min(t/0.5\\,1)\\,2)':format=auto[v]")
    else:
        graph.append("[b2]null[v]")
    cmd+=["-filter_complex",";".join(graph),"-map","[v]","-t",f"{length:.3f}","-an","-r",str(fps),
          "-c:v","libx264","-preset","veryfast","-crf","12","-pix_fmt","yuv420p",str(seg)]
    _run(cmd,max(180,int(length*40)))
    return seg,length


def _narration_track(specs, work, total) -> Path | None:
    """Sample-accurate narration: each scene's clip is delayed, padded to its slot, then concatenated."""
    if not any(s["audio"] for s in specs): return None
    ffmpeg=shutil.which("ffmpeg"); cmd=[ffmpeg,"-y","-hide_banner","-loglevel","error"]; chains=[]; labels=[]; inp=0
    for n,s in enumerate(specs):
        if s["audio"]:
            lead=int(s["lead"]*1000)
            cmd+=["-i",str(s["audio"])]
            chains.append(f"[{inp}:a]aresample=48000,aformat=channel_layouts=stereo,adelay={lead}|{lead},apad=whole_dur={s['duration']:.3f},atrim=0:{s['duration']:.3f},asetpts=PTS-STARTPTS[n{n}]")
            inp+=1
        else:
            chains.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{s['duration']:.3f},asetpts=PTS-STARTPTS[n{n}]")
        labels.append(f"[n{n}]")
    chains.append("".join(labels)+f"concat=n={len(labels)}:v=0:a=1[nar]")
    out=work/"narration_full.wav"
    cmd+=["-filter_complex",";".join(chains),"-map","[nar]","-c:a","pcm_s16le",str(out)]
    _run(cmd,max(120,int(total*4)))
    return out


def render_pro(job_id: str, job: dict, progress: Callable[[int,str],None], cancelled: Callable[[],bool],
               output: Path, final: Path, width: int, height: int, fps: int) -> dict:
    settings=job["settings"]; aspect=settings["aspect_ratio"]
    ffmpeg=shutil.which("ffmpeg")
    if not ffmpeg: raise RuntimeError("FFmpeg not found on PATH. Install FFmpeg, reopen the terminal and retry.")
    work=output/"work"; shutil.rmtree(work,ignore_errors=True); work.mkdir(parents=True)
    planned_total=int(settings["duration_seconds"])
    scenes=_normalise_scenes(settings.get("scenes",[]),planned_total)
    warnings: list[str]=[]
    progress(11,"Planning scenes")
    specs=_plan_audio(scenes,settings,work,progress,cancelled,warnings)
    n=len(scenes)
    starts=[]; t=0.0
    for s in specs: starts.append(t); t+=s["duration"]
    total=t
    narrated=any(s["audio"] for s in specs)

    # ---------- visuals ----------
    progress(30,"Choosing footage")
    refs=_reference_images(settings)
    mode=settings.get("visual_source","auto")
    use_stock=mode in ("auto","stock") and not refs and bool(stock.api_key())
    if mode=="stock" and not stock.api_key() and not refs:
        warnings.append("Stock footage needs a free PEXELS_API_KEY in .env - used animated backgrounds instead.")
    used_ids: set[int]=set(); credits: list[str]=[]; counts={"stock":0,"image":0,"animated":0}
    shade=work/"shade.png"; thumbs.shade_overlay(shade,width,height)
    _,accent_rgb=_palette_for(settings,0)
    fallback_words=[w for w in re.findall(r"[A-Za-z]{4,}",str(job.get("topic") or ""))][:2]
    sources=[]
    for i,scene in enumerate(scenes):
        _check(cancelled)
        progress(30+int(10*i/n),f"Choosing footage {i+1}/{n}")
        source={"kind":"animated"}
        if refs:
            source={"kind":"image","path":refs[i%len(refs)]}
        elif use_stock:
            try:
                got=stock.fetch_for_scene(scene.get("search_query") or scene["title"],[" ".join(fallback_words),"abstract background"],aspect,
                                          specs[i]["duration"],width,height,used_ids)
                if got:
                    source={"kind":"stock","path":got["path"]}
                    if got["credit"] not in credits: credits.append(got["credit"])
                else: warnings.append(f"Scene {i+1}: no stock match for '{scene.get('search_query','')}' - animated background used.")
            except Exception as error:
                warnings.append(f"Stock footage unavailable ({str(error)[:140]}); remaining scenes use animated backgrounds.")
                use_stock=False
        counts[source["kind"]]+=1
        sources.append(source)
    workers=max(1,min(4,(os.cpu_count() or 2)//2 or 1,n))      # scenes render in parallel on multi-core PCs
    segments=[None]*n; done=0
    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures={pool.submit(_segment,i,n,scenes[i],specs[i],settings,work,width,height,fps,sources[i],shade,None,accent_rgb,cancelled):i for i in range(n)}
        try:
            for fut in as_completed(futures):
                _check(cancelled)
                seg,_=fut.result(); segments[futures[fut]]=seg; done+=1
                progress(40+int(22*done/n),f"Built scene {done}/{n}")
        except BaseException:
            for f in futures: f.cancel()
            raise

    # ---------- captions ----------
    all_words=[]
    for i,s in enumerate(specs):
        base=starts[i]+s["lead"]
        for w,a,b in s["words"]: all_words.append((w,base+a,base+b))
    captions_srt=None; ass_name=None
    if settings.get("captions",True) and all_words:
        ass=work/"captions.ass"
        cap.write_ass(all_words,ass,width,height,settings.get("caption_style","karaoke"),settings.get("accent_color") or "#FFD23F",aspect)
        ass_name=ass.name
        captions_srt=output/"captions.srt"; cap.write_srt(all_words,captions_srt,aspect)

    # ---------- audio ----------
    progress(62,"Mixing audio")
    narration=_narration_track(specs,work,total) if narrated else None
    music=_audio_upload(settings,"music_upload_id","music"); sfx=_audio_upload(settings,"sound_effects_upload_id","sound effects")

    cmd=[ffmpeg,"-y","-hide_banner","-loglevel","error"]
    for seg in segments: cmd+=["-i",str(seg)]
    idx=len(segments)
    graph=[]
    # video chain
    if settings.get("transitions",True) and n>1:
        prev="[0:v]"; cum=0.0
        for i in range(1,n):
            cum+=specs[i-1]["duration"]
            tr=TRANSITIONS[(i-1)%len(TRANSITIONS)]
            graph.append(f"{prev}[{i}:v]xfade=transition={tr}:duration={XFADE}:offset={cum:.3f}[x{i}]"); prev=f"[x{i}]"
        chain=prev
    elif n>1:
        graph.append("".join(f"[{i}:v]" for i in range(n))+f"concat=n={n}:v=1:a=0[xc]"); chain="[xc]"
    else:
        chain="[0:v]"
    if ass_name: graph.append(f"{chain}ass={ass_name}[vc]"); chain="[vc]"
    if settings.get("progress_bar",True):
        bar_h=max(6,round(height*0.006)); bar_y="0" if height>width else f"H-{bar_h}"
        cmd+=["-f","lavfi","-i",f"color=c={_hex(accent_rgb)}:s={width}x{bar_h}:r={fps}"]
        graph.append(f"{chain}[{idx}:v]overlay=x='-w+W*t/{total:.3f}':y={bar_y}:shortest=1[vp]"); chain="[vp]"; idx+=1
    wm_text=(settings.get("watermark") or "").strip()
    if wm_text:
        wm=work/"wm.png"; ww,wh=thumbs.watermark(wm_text,wm,width)
        cmd+=["-i",str(wm)]
        pad=round(width*0.04); top=round(height*0.04) if height<=width else round(height*0.17)
        graph.append(f"{chain}[{idx}:v]overlay=x=W-w-{pad}:y={top}[vw]"); chain="[vw]"; idx+=1
    graph.append(f"{chain}format=yuv420p[vout]")
    # audio chain
    labels=[]
    if narration:
        cmd+=["-i",str(narration)]; ni=idx; idx+=1
    if music:
        cmd+=["-stream_loop","-1","-i",str(music)]; mi=idx; idx+=1
    if sfx:
        cmd+=["-i",str(sfx)]; si=idx; idx+=1
    mv=float(settings.get("music_volume",0.12))
    if narration and music:
        graph.append(f"[{ni}:a]asplit=2[nar1][nar2]")
        graph.append(f"[{mi}:a]aresample=48000,aformat=channel_layouts=stereo,volume={mv*2.2:.3f}[m0]")
        graph.append("[m0][nar2]sidechaincompress=threshold=0.02:ratio=10:attack=15:release=450[duck]")
        labels+=["[nar1]","[duck]"]
    elif narration:
        labels.append(f"[{ni}:a]")
    elif music:
        graph.append(f"[{mi}:a]aresample=48000,aformat=channel_layouts=stereo,volume={mv*2.5:.3f}[mus]"); labels.append("[mus]")
    if sfx:
        graph.append(f"[{si}:a]aresample=48000,aformat=channel_layouts=stereo,volume=0.35[sf]"); labels.append("[sf]")
    has_audio=bool(labels)
    if has_audio:
        if len(labels)>1: graph.append("".join(labels)+f"amix=inputs={len(labels)}:duration=longest:dropout_transition=0:normalize=0[mix]"); a="[mix]"
        else: a=labels[0]
        graph.append(f"{a}atrim=0:{total:.3f},afade=t=out:st={max(0,total-1.2):.3f}:d=1.2,loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000[aout]")
    preset,crf=QUALITY.get(settings.get("resolution_preset","quality"),QUALITY["quality"])
    cap_mbps={"quality":14,"balanced":8,"draft":3}.get(settings.get("resolution_preset","quality"),14)*(1.6 if fps>30 else 1)
    cmd+=["-filter_complex",";".join(graph),"-map","[vout]"]
    if has_audio: cmd+=["-map","[aout]","-c:a","aac","-b:a","192k","-ar","48000"]
    cmd+=["-t",f"{total:.3f}","-r",str(fps),"-c:v","libx264","-preset",preset,"-crf",str(crf),"-profile:v","high",
          "-maxrate",f"{cap_mbps:.0f}M","-bufsize",f"{cap_mbps*2:.0f}M","-pix_fmt","yuv420p","-g",str(fps*2),"-bf","2","-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709",
          "-movflags","+faststart",str(final)]
    progress(68,"Final encode (high quality)")
    _check(cancelled)
    _run(cmd,max(600,int(total*30)),cwd=work)   # cwd=work lets the ass filter use a bare filename (Windows-safe)
    if not final.exists() or final.stat().st_size<5000: raise RuntimeError("Validation failed: output file is missing or too small.")

    # ---------- thumbnail + validation ----------
    progress(88,"Validating playable MP4")
    validation=validate_output(final,width,height,max(1,int(total)),has_audio,fps)
    if not validation["valid"]: raise RuntimeError("Validation failed: sampled output frames appear black.")
    frame=work/"frame.png"
    pick=segments[min(1,n-1)]; seg_len=specs[min(1,n-1)]["duration"]
    _run([ffmpeg,"-y","-hide_banner","-loglevel","error","-ss",f"{min(3.4,seg_len*0.85):.2f}","-i",str(pick),"-frames:v","1",str(frame)],60)
    titles=(settings.get("metadata") or {}).get("titles") or [job.get("topic") or "My video"]
    thumbnail=output/"thumbnail.jpg"
    thumbs.make_thumbnail(frame,titles[0],thumbnail,settings.get("accent_color") or "#FFD23F",settings.get("channel_name",""))
    shutil.rmtree(work,ignore_errors=True)

    metadata=dict(settings.get("metadata") or {})
    desc=re.sub(r"\n*Footage credits:.*\Z","",metadata.get("description",""),flags=re.S).rstrip()
    if credits: desc+="\n\nFootage credits: "+", ".join(credits[:12])+"."
    if total>=120 and settings.get("planner")=="llm" and n>=3:
        lines=[]; last=-99
        for i,sc in enumerate(scenes):
            if starts[i]-last>=10 or i==0:
                m,s_=divmod(int(starts[i]),60); lines.append(f"{m}:{s_:02d} {sc['title']}"); last=starts[i]
        desc=re.sub(r"\n*Chapters:.*?(?=\n\n|\Z)","",desc,flags=re.S).rstrip()+"\n\nChapters:\n"+"\n".join(lines)
    metadata["description"]=desc
    notes=[f"Studio Pro render {width}x{height}@{fps}fps, {total:.1f}s, {counts['stock']} stock / {counts['image']} image / {counts['animated']} animated scenes."]
    notes.append("Narrated with "+("neural/system voice." if narrated else "no narration (captions only)."))
    notes+=warnings
    return {
        "output_path":str(final),"captions_path":str(captions_srt) if captions_srt else None,"thumbnail_path":str(thumbnail),
        "validation":validation,"render_mode":"studio_pro","render_notice":" ".join(notes),"metadata":metadata,
        "actual_duration_seconds":round(total,2),
    }

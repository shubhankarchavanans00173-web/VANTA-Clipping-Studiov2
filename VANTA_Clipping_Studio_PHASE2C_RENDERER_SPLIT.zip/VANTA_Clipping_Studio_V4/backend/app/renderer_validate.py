"""Output validation and plain source-video rendering for the legacy renderer.

Split from renderer.py (Phase 2c); re-exported there, behaviour unchanged.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from PIL import ImageStat
from pathlib import Path
from typing import Callable
from .renderer_common import DEFAULT_FPS, _fraction, _run, _sample_image


def validate_output(video: Path, width: int, height: int, expected_duration: int, require_audio: bool, expected_fps: int=DEFAULT_FPS) -> dict:
    ffprobe=shutil.which("ffprobe")
    ffmpeg=shutil.which("ffmpeg")
    if not ffprobe or not ffmpeg: raise RuntimeError("FFmpeg and ffprobe must both be available for output validation.")
    result=subprocess.run([ffprobe,"-v","error","-show_streams","-show_format","-of","json",str(video)],capture_output=True,text=True,timeout=30)
    if result.returncode: raise RuntimeError("ffprobe could not decode the rendered MP4: "+result.stderr[-900:])
    data=json.loads(result.stdout)
    video_stream=next((stream for stream in data.get("streams",[]) if stream.get("codec_type")=="video"),None)
    audio_stream=next((stream for stream in data.get("streams",[]) if stream.get("codec_type")=="audio"),None)
    duration=float(data.get("format",{}).get("duration") or 0)
    fps=_fraction((video_stream or {}).get("avg_frame_rate","0/1"))
    if not video_stream: raise RuntimeError("Validation failed: no video stream was found.")
    if (video_stream.get("width"),video_stream.get("height"))!=(width,height):
        raise RuntimeError(f"Validation failed: expected {width}x{height}, got {video_stream.get('width')}x{video_stream.get('height')}.")
    if duration < max(1,expected_duration*.75):
        raise RuntimeError(f"Validation failed: output duration {duration:.2f}s is too short for the requested {expected_duration}s.")
    if abs(fps-expected_fps)>1.5: raise RuntimeError(f"Validation failed: expected about {expected_fps} fps, got {fps:.2f} fps.")
    if require_audio and not audio_stream: raise RuntimeError("Validation failed: audio was requested but no audio stream was found.")
    samples=[sample for sample in (_sample_image(ffmpeg,video,duration*ratio) for ratio in (.08,.5,.92)) if sample]
    means=[round(sum(ImageStat.Stat(sample).mean)/3,2) for sample in samples]
    black_suspected=bool(means) and all(value<4 for value in means)
    movement=[]
    for before,after in zip(samples,samples[1:]):
        movement.append(round(sum(abs(a-b) for a,b in zip(before.tobytes(),after.tobytes()))/len(before.tobytes()),2))
    return {"valid":not black_suspected,"duration_seconds":round(duration,3),"width":width,"height":height,"fps":round(fps,3),"has_audio":bool(audio_stream),"black_frame_suspected":black_suspected,"sample_luma":means,"sample_frame_difference":movement,"frozen_scene_suspected":bool(movement) and all(value<0.15 for value in movement)}


def _render_source_video(source: Path, final: Path, width: int, height: int, duration: int, fps: int, progress: Callable[[int,str],None]) -> tuple[bool,str]:
    ffmpeg=shutil.which("ffmpeg")
    ffprobe=shutil.which("ffprobe")
    if not ffmpeg or not ffprobe: raise RuntimeError("FFmpeg and ffprobe must be available for source-video mode.")
    probe=subprocess.run([ffprobe,"-v","error","-select_streams","a:0","-show_entries","stream=index","-of","csv=p=0",str(source)],capture_output=True,text=True,timeout=30)
    source_has_audio=probe.returncode==0 and bool(probe.stdout.strip())
    progress(35,"Reframing authorized source video")
    command=[ffmpeg,"-y","-hide_banner","-ss","0","-t",str(duration),"-i",str(source),"-map","0:v:0","-map","0:a?","-vf",f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height},fps={fps},setsar=1","-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-movflags","+faststart",str(final)]
    _run(command,max(180,duration*25))
    notice="Source video was reframed from the beginning of the authorized file. Choose precise clip points in a future release."
    if not source_has_audio:
        notice += " The source has no audio stream, so the export is silent."
    return source_has_audio,notice

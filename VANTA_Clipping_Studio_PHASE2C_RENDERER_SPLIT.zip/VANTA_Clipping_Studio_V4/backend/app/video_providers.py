from __future__ import annotations

import base64
import importlib.util
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import threading
import time
from typing import Callable, Protocol
from urllib.parse import urlparse

import httpx

REPLICATE_API = "https://api.replicate.com/v1"
DEFAULT_REPLICATE_MODEL = "minimax/video-01"
LOCAL_BASE_MODEL = "Lykon/dreamshaper-8"
LOCAL_MOTION_MODEL = "guoyww/animatediff-motion-adapter-v1-5-2"
MAX_PROVIDER_OUTPUT_BYTES = 512 * 1024 * 1024
LOCAL_FRAME_COUNT = 8
LOCAL_INFERENCE_STEPS = 12
LOCAL_GENERATION_LOCK = threading.Lock()
_local_pipeline = None


class VideoProvider(Protocol):
    name: str

    def generate_clip(
        self,
        prompt: str,
        duration_seconds: float,
        output_path: Path,
        progress: Callable[[int, str], None],
        cancelled: Callable[[], bool],
        reference_image: Path | None = None,
    ) -> None: ...


def _cache_root() -> Path:
    configured = os.getenv("HF_HUB_CACHE") or os.getenv("HUGGINGFACE_HUB_CACHE")
    return Path(configured).expanduser() if configured else Path.home() / ".cache" / "huggingface" / "hub"


def _cached_snapshot(repo_id: str) -> Path | None:
    repo_folder = "models--" + repo_id.replace("/", "--")
    repository = _cache_root() / repo_folder
    try:
        revision = (repository / "refs" / "main").read_text(encoding="utf-8").strip()
    except OSError:
        return None
    snapshot = repository / "snapshots" / revision
    return snapshot if snapshot.is_dir() else None


def local_model_status() -> dict:
    adapter = _cached_snapshot(LOCAL_MOTION_MODEL)
    base = _cached_snapshot(LOCAL_BASE_MODEL)
    packages = all(importlib.util.find_spec(name) is not None for name in ("torch", "diffusers", "accelerate"))
    if not packages:
        return {
            "configured": False,
            "available": False,
            "model": "AnimateDiff + DreamShaper 8",
            "detail": "Install compatible torch, diffusers, and accelerate packages in the backend environment.",
        }
    if not adapter or not base:
        missing = [name for name, path in ((LOCAL_MOTION_MODEL, adapter), (LOCAL_BASE_MODEL, base)) if not path]
        return {
            "configured": False,
            "available": False,
            "model": "AnimateDiff + DreamShaper 8",
            "detail": "Model weights are not cached locally: " + ", ".join(missing),
        }
    if not (adapter / "diffusion_pytorch_model.safetensors").is_file() or not (base / "unet" / "diffusion_pytorch_model.safetensors").is_file():
        return {
            "configured": False,
            "available": False,
            "model": "AnimateDiff + DreamShaper 8",
            "detail": "Cached model weights are incomplete.",
        }

    try:
        import torch

        cuda_available = torch.cuda.is_available()
        device = torch.cuda.get_device_name(0) if cuda_available else "CPU"
        memory_gib = round(torch.cuda.get_device_properties(0).total_memory / (1024**3), 1) if cuda_available else 0
    except (ImportError, RuntimeError, OSError) as error:
        return {
            "configured": False,
            "available": False,
            "model": "AnimateDiff + DreamShaper 8",
            "detail": f"Could not initialize the local model runtime: {error}",
        }

    if not cuda_available:
        return {
            "configured": True,
            "available": False,
            "model": "AnimateDiff + DreamShaper 8",
            "detail": "The cached model is present, but CUDA is unavailable. CPU video generation is not enabled.",
        }
    tested = "GeForce GTX 1650" in device and 3.5 <= memory_gib <= 4.5
    return {
        "configured": True,
        "available": True,
        "tested": tested,
        "model": "AnimateDiff + DreamShaper 8",
        "device": device,
        "vram_gib": memory_gib,
        "clip_seconds": 1,
        "inference_steps": LOCAL_INFERENCE_STEPS,
        "detail": (
            "Smoke-tested with real changing video frames on a GTX 1650 4 GB. This configuration is intentionally tiny (128x128, 8 frames, full precision with CPU offload) and slow: about 2.5 minutes per one-second clip. "
            "It is an experimental local option, not a fast or high-resolution renderer."
            if tested
            else "Cached text-to-video weights and CUDA detected. This device/configuration has not been smoke-tested."
        ),
        "license": "DreamShaper 8: CreativeML OpenRAIL-M; AnimateDiff motion-adapter model card does not state a license.",
    }


def provider_status() -> dict:
    provider, model = online_provider_identifier().split(":", 1)
    configured = bool(os.getenv("REPLICATE_API_TOKEN", "").strip())
    max_runtime_seconds = int(os.getenv("STUDIO_REPLICATE_MAX_RUNTIME_SECONDS", "3600"))
    return {
        "local": local_model_status(),
        "online": {
            "provider": "Replicate" if provider == "replicate" else provider,
            "model": model,
            "configured": configured and provider == "replicate",
            "available": False,
            "account_access_verified": False,
            "approval_required": True,
            "paid_requests_enabled_by_default": False,
            "estimated_cost_usd": None,
            "max_runtime_seconds": max_runtime_seconds,
            "detail": (
                "Backend API token is present, but account/model access has not been verified. Each generation request still requires explicit approval; "
                "the model page does not provide a fixed per-video estimate."
                if configured and provider == "replicate"
                else f"Online provider '{provider}' has no adapter in this build. Set STUDIO_ONLINE_PROVIDER=replicate to use the configured Replicate adapter."
                if provider != "replicate"
                else "Not configured. Set REPLICATE_API_TOKEN in the backend process environment. No cloud request will be made."
            ),
            "capabilities": ["text-to-video", "up to 6 seconds per generated clip"],
            "model_url": f"https://replicate.com/{model}",
            "pricing_url": "https://replicate.com/pricing",
            "identifier": f"{provider}:{model}",
        },
    }


def online_provider_identifier() -> str:
    provider = os.getenv("STUDIO_ONLINE_PROVIDER", "replicate").strip().lower() or "replicate"
    model = os.getenv("STUDIO_REPLICATE_MODEL", DEFAULT_REPLICATE_MODEL).strip() or DEFAULT_REPLICATE_MODEL
    return f"{provider}:{model}"


def _run_ffmpeg(command: list[str]) -> None:
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("FFmpeg is required to encode generated AI-video clips.")
    result = subprocess.run([ffmpeg, *command], capture_output=True, text=True, timeout=120)
    if result.returncode:
        detail = (result.stderr or result.stdout or "unknown FFmpeg error")[-1800:]
        raise RuntimeError(f"Generated clip encoding failed: {detail}")


def _load_local_pipeline():
    global _local_pipeline
    if _local_pipeline is not None:
        return _local_pipeline

    import torch
    from diffusers import AnimateDiffPipeline, MotionAdapter

    adapter_path = _cached_snapshot(LOCAL_MOTION_MODEL)
    base_path = _cached_snapshot(LOCAL_BASE_MODEL)
    if not adapter_path or not base_path:
        raise RuntimeError("Local AnimateDiff and DreamShaper weights are not both cached.")
    adapter = MotionAdapter.from_pretrained(str(adapter_path), torch_dtype=torch.float32, local_files_only=True)
    pipeline = AnimateDiffPipeline.from_pretrained(
        str(base_path),
        motion_adapter=adapter,
        torch_dtype=torch.float32,
        local_files_only=True,
    )
    pipeline.enable_model_cpu_offload()
    pipeline.enable_attention_slicing("max")
    pipeline.vae.enable_slicing()
    from diffusers import DDIMScheduler

    pipeline.scheduler = DDIMScheduler.from_config(
        pipeline.scheduler.config,
        clip_sample=False,
        timestep_spacing="linspace",
        steps_offset=1,
    )
    _local_pipeline = pipeline
    return pipeline


class AnimateDiffLocalProvider:
    name = "animatediff_local"

    def generate_clip(
        self,
        prompt: str,
        duration_seconds: float,
        output_path: Path,
        progress: Callable[[int, str], None],
        cancelled: Callable[[], bool],
        reference_image: Path | None = None,
    ) -> None:
        if reference_image:
            raise RuntimeError("The cached AnimateDiff model is text-to-video only; remove the reference image or use an image-to-video provider.")
        status = local_model_status()
        if not status["available"]:
            raise RuntimeError("Local video generation is unavailable: " + status["detail"])
        if cancelled():
            raise RuntimeError("Video generation was cancelled.")

        import torch
        from diffusers.utils import export_to_video

        with LOCAL_GENERATION_LOCK:
            pipeline = _load_local_pipeline()
            result = None
            try:
                progress(0, "Generating an 8-frame, 128×128 AnimateDiff clip in full precision with CPU offload")

                def step_progress(pipeline, step_index: int, timestep, callback_kwargs: dict) -> dict:
                    if cancelled():
                        raise RuntimeError("Video generation was cancelled.")
                    progress(round((step_index+1)*100/LOCAL_INFERENCE_STEPS), f"AnimateDiff denoising step {step_index+1}/{LOCAL_INFERENCE_STEPS}")
                    return callback_kwargs

                result = pipeline(
                    prompt=prompt,
                    negative_prompt="still image, frozen frame, text, logo, watermark, deformed, low quality",
                    num_frames=LOCAL_FRAME_COUNT,
                    height=128,
                    width=128,
                    num_inference_steps=LOCAL_INFERENCE_STEPS,
                    guidance_scale=5.0,
                    generator=torch.Generator(device="cpu").manual_seed(int(time.time_ns() % (2**31))),
                    callback_on_step_end=step_progress,
                )
                if cancelled():
                    raise RuntimeError("Video generation was cancelled.")
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with tempfile.TemporaryDirectory(prefix="animatediff-frames-") as temp_dir:
                    raw_video = Path(temp_dir) / "generated.mp4"
                    export_to_video(result.frames[0], str(raw_video), fps=8)
                    _run_ffmpeg([
                        "-y", "-hide_banner", "-i", str(raw_video), "-t", f"{max(0.5, duration_seconds):.3f}",
                        "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                        "-movflags", "+faststart", str(output_path),
                    ])
                progress(100, "AnimateDiff clip generated")
            finally:
                if result is not None:
                    del result
                pipeline.maybe_free_model_hooks()
                torch.cuda.empty_cache()


def _provider_error(response: httpx.Response, token: str) -> RuntimeError:
    try:
        body = response.json()
        detail = body.get("detail") or body.get("error") or body.get("title") or response.text
        if isinstance(detail, (dict, list)):
            detail = str(detail)
    except ValueError:
        detail = response.text
    safe_detail = str(detail).replace(token, "[redacted]")[:1200]
    return RuntimeError(f"Replicate request failed ({response.status_code}): {safe_detail or 'provider returned an error'}")


def _safe_output_url(value: str) -> str:
    parsed = urlparse(value)
    hostname = (parsed.hostname or "").lower()
    if (
        parsed.scheme != "https"
        or parsed.username
        or parsed.password
        or parsed.port not in {None, 443}
        or not (hostname == "replicate.delivery" or hostname.endswith(".replicate.delivery"))
    ):
        raise RuntimeError("Replicate returned an unexpected video URL; refusing to download it.")
    return value


class ReplicateVideoProvider:
    name = "replicate_minimax_video_01"
    timeout_seconds = 60 * 60

    def __init__(self) -> None:
        self.model = os.getenv("STUDIO_REPLICATE_MODEL", DEFAULT_REPLICATE_MODEL).strip() or DEFAULT_REPLICATE_MODEL
        self.identifier = f"replicate:{self.model}"
        try:
            self.timeout_seconds = int(os.getenv("STUDIO_REPLICATE_MAX_RUNTIME_SECONDS", "3600"))
        except ValueError as error:
            raise RuntimeError("STUDIO_REPLICATE_MAX_RUNTIME_SECONDS must be a whole number of seconds.") from error
        if not 60 <= self.timeout_seconds <= 24 * 60 * 60:
            raise RuntimeError("STUDIO_REPLICATE_MAX_RUNTIME_SECONDS must be between 60 and 86400 seconds.")

    def generate_clip(
        self,
        prompt: str,
        duration_seconds: float,
        output_path: Path,
        progress: Callable[[int, str], None],
        cancelled: Callable[[], bool],
        reference_image: Path | None = None,
    ) -> None:
        token = os.getenv("REPLICATE_API_TOKEN", "").strip()
        if not token:
            raise RuntimeError("Replicate is not configured. Set REPLICATE_API_TOKEN in the backend environment.")

        model = self.model
        if not re.fullmatch(r"[A-Za-z0-9_-]+/[A-Za-z0-9_.-]+", model):
            raise RuntimeError("STUDIO_REPLICATE_MODEL must be a Replicate model identifier such as minimax/video-01.")
        if reference_image and reference_image.stat().st_size > 10 * 1024 * 1024:
            raise RuntimeError("Reference images sent to Replicate must be 10 MiB or smaller.")
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        input_data: dict[str, object] = {"prompt": prompt}
        if reference_image:
            if model != DEFAULT_REPLICATE_MODEL:
                raise RuntimeError("Reference-image generation is only wired for the configured MiniMax Video-01 adapter.")
            extension = reference_image.suffix.lower()
            mime = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}.get(extension)
            if not mime:
                raise RuntimeError("Reference image must be PNG, JPEG, or WebP.")
            encoded = base64.b64encode(reference_image.read_bytes()).decode("ascii")
            input_data["first_frame_image"] = f"data:{mime};base64,{encoded}"

        timeout = httpx.Timeout(connect=20, read=60, write=60, pool=20)
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                f"{REPLICATE_API}/models/{model}/predictions",
                headers={**headers, "Prefer": "wait=5"},
                json={"input": input_data},
            )
            if response.is_error:
                raise _provider_error(response, token)
            prediction = response.json()
            prediction_id = str(prediction.get("id") or "")
            if not re.fullmatch(r"[A-Za-z0-9_-]+", prediction_id):
                raise RuntimeError("Replicate returned a prediction without a valid job ID.")

            started = time.monotonic()
            terminal_statuses={"succeeded","successful","failed","canceled","cancelled"}
            while prediction.get("status") not in terminal_statuses:
                if cancelled():
                    cancel_response = client.post(f"{REPLICATE_API}/predictions/{prediction_id}/cancel", headers=headers)
                    if cancel_response.is_error and cancel_response.status_code not in {409, 422}:
                        raise _provider_error(cancel_response, token)
                    raise RuntimeError("Replicate video generation was cancelled.")
                if time.monotonic() - started > self.timeout_seconds:
                    cancel_response = client.post(f"{REPLICATE_API}/predictions/{prediction_id}/cancel", headers=headers)
                    if cancel_response.is_error and cancel_response.status_code not in {409, 422}:
                        raise _provider_error(cancel_response, token)
                    raise RuntimeError("Replicate video generation exceeded the 60-minute timeout and was cancelled.")
                progress(10, "Waiting for Replicate video generation")
                time.sleep(3)
                response = client.get(f"{REPLICATE_API}/predictions/{prediction_id}", headers=headers)
                if response.is_error:
                    raise _provider_error(response, token)
                prediction = response.json()

            if prediction.get("status") not in {"succeeded","successful"}:
                detail = str(prediction.get("error") or "The provider marked this prediction as " + str(prediction.get("status"))).replace(token, "[redacted]")
                raise RuntimeError("Replicate video generation failed: " + detail[:1200])

            output = prediction.get("output")
            if isinstance(output, list):
                video_url=output[0] if output else None
            elif isinstance(output, dict):
                video_url=output.get("video") or output.get("video_url") or output.get("url")
            else:
                video_url=output
            if not isinstance(video_url, str):
                raise RuntimeError("Replicate completed without returning a video file.")
            video_url = _safe_output_url(video_url)
            progress(85, "Downloading generated video from Replicate")

        # Never forward the backend API token to the provider's output host.
        try:
            with httpx.stream("GET", video_url, timeout=httpx.Timeout(connect=20, read=60, write=20, pool=20)) as download:
                if download.is_error:
                    raise RuntimeError(f"Replicate output download failed ({download.status_code}).")
                output_path.parent.mkdir(parents=True, exist_ok=True)
                total = 0
                with output_path.open("wb") as handle:
                    for chunk in download.iter_bytes():
                        total += len(chunk)
                        if total > MAX_PROVIDER_OUTPUT_BYTES:
                            raise RuntimeError("Replicate output exceeds the 512 MiB per-clip download limit.")
                        handle.write(chunk)
        except Exception:
            output_path.unlink(missing_ok=True)
            raise
        if not output_path.is_file() or output_path.stat().st_size < 5000:
            output_path.unlink(missing_ok=True)
            raise RuntimeError("Replicate returned an empty or incomplete video file.")
        progress(100, "Replicate video clip downloaded")


def get_video_provider(generation_mode: str) -> VideoProvider:
    if generation_mode in {"local_ai", "hybrid"}:
        status = local_model_status()
        if status["available"]:
            return AnimateDiffLocalProvider()
        if generation_mode == "hybrid":
            if os.getenv("REPLICATE_API_TOKEN", "").strip():
                raise RuntimeError(
                    "Hybrid mode cannot run without explicit paid-generation approval. "
                    "Approve an Online AI job to use Replicate; no automatic cloud fallback is performed."
                )
        raise RuntimeError("Local video generation is unavailable: " + status["detail"])
    if generation_mode == "online_ai":
        if (os.getenv("STUDIO_ONLINE_PROVIDER", "replicate").strip().lower() or "replicate") != "replicate":
            raise RuntimeError("No adapter is implemented for STUDIO_ONLINE_PROVIDER. Set it to 'replicate' or choose Local AI.")
        if not os.getenv("REPLICATE_API_TOKEN", "").strip():
            raise RuntimeError("Online AI is not configured. Set REPLICATE_API_TOKEN in the backend environment.")
        return ReplicateVideoProvider()
    raise RuntimeError(f"Unsupported AI generation mode: {generation_mode}")

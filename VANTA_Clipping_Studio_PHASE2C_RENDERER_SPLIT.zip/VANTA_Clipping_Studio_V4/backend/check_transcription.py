"""Real local-transcription self-check (run it on YOUR machine; the test suite uses a stub model).

    python check_transcription.py                       # status only: library, model, device. No network, no download.
    python check_transcription.py --download tiny       # asks "y/N" first, then downloads that model once (about 75 MB)
    python check_transcription.py --file talk.mp4       # really transcribes (first 60 s) with the configured model
    python check_transcription.py --file talk.mp4 --model tiny --seconds 30

Exit codes: 0 = OK, 1 = a step failed, 2 = cannot run (library or model missing).
It prints measured facts only: real-time factor, number of segments, whether word timings exist, the first lines of text.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.clipstudio import whisper_local as wl  # noqa: E402
from app.clipstudio.transcript import TranscriptError  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--download", metavar="MODEL", help="download this model after you confirm")
    ap.add_argument("--file", help="media file to transcribe")
    ap.add_argument("--model", help="model name (default: VANTA_WHISPER_MODEL or small)")
    ap.add_argument("--seconds", type=int, default=60, help="only transcribe the first N seconds (default 60)")
    ap.add_argument("--yes", action="store_true", help="do not ask before --download")
    a = ap.parse_args()
    model = a.model or wl.configured_model()
    st = wl.status()
    print(f"faster-whisper installed : {st['installed']} {st['library_version'] or ''}")
    print(f"model                    : {model} (downloaded: {wl.model_path(model) is not None})")
    print(f"model folder             : {st['cache_dir']}")
    print(f"device plan              : {st['device_reason']}; precision {st['compute_type']}")
    if not st["installed"]:
        print("[!!] Install it with enable_local_transcription.bat, then run this again.")
        return 2
    if a.download:
        mb = wl.MODEL_INFO.get(a.download)
        if mb is None:
            print(f"[!!] Unknown model {a.download!r}. Choose from: {', '.join(wl.MODEL_INFO)}"); return 1
        if not a.yes and input(f"Download '{a.download}' (about {mb} MB) from Hugging Face? [y/N] ").strip().lower() != "y":
            print("Cancelled; nothing was downloaded."); return 1
        try:
            wl.DOWNLOADER.start(a.download)
        except wl.DownloadError as e:
            print(f"[!!] {e}"); return 1
        while wl.DOWNLOADER.active():
            s = wl.DOWNLOADER.state(); print(f"  {s['message']}", end="\r"); time.sleep(1)
        s = wl.DOWNLOADER.state(); print()
        print(("[OK] " if s["status"] == "done" else "[!!] ") + (s["error"] or s["message"]))
        if s["status"] != "done":
            return 1
        model = a.download
    if not a.file:
        return 0 if wl.availability(model)[0] else 2
    ok, detail = wl.availability(model)
    if not ok:
        print("[!!] " + detail); return 2
    src = Path(a.file)
    if not src.is_file():
        print(f"[!!] File not found: {src}"); return 1
    tmp = Path(tempfile.mkdtemp(prefix="vanta-tr-"))
    try:
        clip = tmp / "sample.wav"
        r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-t", str(a.seconds), "-vn", "-ac", "1", "-ar", "16000", str(clip)],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print("[!!] FFmpeg could not read the audio: " + r.stderr[-200:]); return 1
        t0 = time.time(); last = [-1.0]

        def prog(p, m):
            if p is not None and int(p * 10) != last[0]:
                last[0] = int(p * 10); print(f"  {m}")
        try:
            tr, notes = wl.transcribe(clip, None, model, progress=prog, duration_hint=float(a.seconds))
        except TranscriptError as e:
            print("[!!] " + str(e)); return 1
        took = time.time() - t0
        dur = max(s.end for s in tr.segments)
        print(f"[OK] {len(tr.segments)} segment(s), language {tr.language}, word timings: {tr.word_level}")
        print(f"     {took:.1f} s for ~{dur:.0f} s of audio (real-time factor {took / max(dur, 1):.2f}; below 1.0 is faster than real time)")
        for n in notes:
            print("     note: " + n)
        for s in tr.segments[:5]:
            print(f"     [{s.start:6.1f}-{s.end:6.1f}] {s.text}")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())

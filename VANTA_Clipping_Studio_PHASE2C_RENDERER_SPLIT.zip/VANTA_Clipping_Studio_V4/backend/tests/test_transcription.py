"""TODO 4: local transcription. No real Whisper model is used here (the model host is not reachable from the test
sandbox): ``whisper_local._load_model`` is replaced by a fake that yields real-looking segment objects. What is tested
for real: model discovery, consent gating, device planning, word-timing hygiene, progress, cancel, CUDA->CPU fallback,
the content-hash cache, the child-process downloader (fake downloader command) and the whole analysis job through the HTTP API."""
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, pipeline, settings, whisper_local as wl
from app.clipstudio.transcript import Transcript, TranscriptCancelled, TranscriptError
from tests.vanta_fixtures import HAVE_FFMPEG, SCRIPT, isolate, make_video


def W(text, s, e):
    return NS(word=" " + text, start=s, end=e)


def seg(s, e, text, words="auto"):
    if words == "auto":
        toks = text.split()
        step = (e - s) / max(1, len(toks))
        words = [W(t, s + i * step, s + (i + 1) * step) for i, t in enumerate(toks)]
    return NS(start=s, end=e, text=" " + text, words=words)


class FakeModel:
    """Stands in for faster_whisper.WhisperModel."""
    calls: list = []

    def __init__(self, segments, duration=70.0, per_segment=None, language="en"):
        self.segments, self.duration, self.per_segment, self.language = segments, duration, per_segment, language

    def transcribe(self, media, **kw):
        FakeModel.calls.append(kw)

        def gen():
            for s in self.segments:
                if self.per_segment:
                    self.per_segment(s)
                yield s
        return gen(), NS(duration=self.duration, language=self.language, language_probability=0.99)


def install_fake_model(name="small", complete=True):
    snap = settings.MODELS_DIR / wl._repo_dirname(name) / "snapshots" / "abc123"
    snap.mkdir(parents=True, exist_ok=True)
    (snap / "model.bin").write_bytes(b"x")
    (snap / "config.json").write_text("{}")
    if complete:
        (snap / "tokenizer.json").write_text("{}")
    return snap


def script_segments():
    return [seg(a, b, t) for a, b, t in SCRIPT]


class Base(unittest.TestCase):
    def setUp(self):
        self._env = mock.patch.dict(os.environ, {}, clear=False); self._env.start()
        for k in ("VANTA_WHISPER_MODEL", "VANTA_WHISPER_DEVICE", "VANTA_WHISPER_COMPUTE", "VANTA_WHISPER_CACHE", "VANTA_WHISPER_THREADS"):
            os.environ.pop(k, None)
        self.tmp = isolate()
        self._inst = mock.patch.object(wl, "installed", return_value=True); self._inst.start()
        self._cuda = mock.patch.object(wl, "cuda_available", return_value=False); self._cuda.start()
        FakeModel.calls = []

    def tearDown(self):
        self._cuda.stop(); self._inst.stop(); self.tmp.cleanup(); self._env.stop()


class Discovery(Base):
    def test_not_installed(self):
        with mock.patch.object(wl, "installed", return_value=False):
            ok, detail = wl.availability("small")
        self.assertFalse(ok); self.assertIn("not installed", detail)

    def test_model_not_downloaded_is_not_available_and_mentions_size(self):
        ok, detail = wl.availability("small")
        self.assertFalse(ok); self.assertIn("not downloaded", detail); self.assertIn("485", detail)

    def test_incomplete_model_folder_is_not_cached(self):
        install_fake_model("small", complete=False)
        self.assertIsNone(wl.model_path("small"))
        install_fake_model("small", complete=True)
        self.assertIsNotNone(wl.model_path("small"))
        self.assertTrue(wl.availability("small")[0])

    def test_only_known_models_or_existing_local_folders(self):
        for bad in ("Systran/faster-whisper-evil", "", "../../etc", "gpt-4"):
            with self.subTest(bad=bad):
                with self.assertRaises(TranscriptError):
                    wl.validate_model(bad)
        local = Path(self.tmp.name) / "mymodel"; local.mkdir(); (local / "model.bin").write_bytes(b"x")
        self.assertEqual(wl.validate_model(str(local)), str(local))

    def test_default_model_is_small_and_env_overrides(self):
        self.assertEqual(wl.configured_model(), "small")
        os.environ["VANTA_WHISPER_MODEL"] = "base"
        self.assertEqual(wl.configured_model(), "base")

    def test_status_is_side_effect_free(self):
        before = sorted(p.name for p in Path(self.tmp.name).rglob("*"))
        st = wl.status()
        self.assertEqual(sorted(p.name for p in Path(self.tmp.name).rglob("*")), before)
        self.assertEqual(st["model"], "small"); self.assertFalse(st["ready"]); self.assertEqual(st["download"]["status"], "idle")
        self.assertEqual(st["device"], "cpu"); self.assertEqual(st["compute_type"], "int8")
        self.assertEqual({m["name"] for m in st["models"]}, set(wl.MODEL_INFO))


class DevicePlan(Base):
    def test_cpu_int8_by_default_even_with_cuda_and_big_model(self):
        with mock.patch.object(wl, "cuda_available", return_value=True):
            self.assertEqual(wl.plan_device("medium")[:2], ("cpu", "int8"))
            self.assertEqual(wl.plan_device("small")[:2], ("cuda", "int8_float16"))

    def test_forced_cpu_and_forced_cuda_without_cuda(self):
        os.environ["VANTA_WHISPER_DEVICE"] = "cpu"
        with mock.patch.object(wl, "cuda_available", return_value=True):
            self.assertEqual(wl.plan_device("small")[0], "cpu")
        os.environ["VANTA_WHISPER_DEVICE"] = "cuda"
        d, c, reason = wl.plan_device("small")
        self.assertEqual((d, c), ("cpu", "int8")); self.assertIn("no CUDA", reason)

    def test_compute_override(self):
        os.environ["VANTA_WHISPER_COMPUTE"] = "float32"
        self.assertEqual(wl.plan_device("small")[1], "float32")


class Transcribing(Base):
    def run_tr(self, segments, **kw):
        install_fake_model("small")
        fm = FakeModel(segments, **{k: v for k, v in kw.items() if k in {"duration", "per_segment"}})
        calls = []
        with mock.patch.object(wl, "_load_model", side_effect=lambda *a: (calls.append(a), fm)[1]):
            return wl.transcribe(Path("x.mp4"), kw.get("language"), "small", progress=kw.get("progress", lambda p, m: None),
                                 cancelled=kw.get("cancelled", lambda: False)), calls

    def test_word_timestamps_come_from_the_engine(self):
        (tr, notes), calls = self.run_tr(script_segments())
        self.assertEqual(tr.source, "faster-whisper"); self.assertTrue(tr.word_level); self.assertEqual(tr.language, "en")
        self.assertEqual(len(tr.segments), len(SCRIPT)); self.assertEqual(tr.segments[0].words[0].text, "Here")
        self.assertEqual(calls[0][1:], ("cpu", "int8"))
        self.assertTrue(FakeModel.calls[0]["word_timestamps"]); self.assertTrue(FakeModel.calls[0]["vad_filter"])
        self.assertFalse(FakeModel.calls[0]["condition_on_previous_text"])
        self.assertTrue(any("Transcribed locally" in n for n in notes))

    def test_malformed_word_timings_are_dropped_never_invented(self):
        bad = seg(1.0, 3.0, "alpha beta gamma delta", words=[
            W("alpha", 1.0, 1.4), W("beta", 1.5, 1.2),            # end < start -> dropped
            W("gamma", 40.0, 41.0),                                 # far outside the segment -> dropped
            W("delta", 1.3, 1.9),                                   # overlaps previous end -> start clamped to 1.4
        ])
        (tr, _), _ = self.run_tr([bad])
        words = tr.segments[0].words
        self.assertEqual([w.text for w in words], ["alpha", "delta"])
        self.assertEqual(words[1].start, 1.4)
        for a, b in zip(words, words[1:]):
            self.assertLessEqual(a.end, b.start)

    def test_segment_without_words_makes_transcript_sentence_level(self):
        (tr, notes), _ = self.run_tr([seg(0, 2, "hello there"), seg(2, 4, "no words here", words=None)])
        self.assertFalse(tr.word_level)
        self.assertIsNone(tr.segments[1].words)
        self.assertTrue(any("sentence-level" in n for n in notes))

    def test_empty_text_segments_are_skipped_and_no_speech_is_an_error(self):
        (tr, _), _ = self.run_tr([seg(0, 1, "   ", words=[]), seg(1, 3, "real words")])
        self.assertEqual(len(tr.segments), 1)
        with self.assertRaises(TranscriptError) as cm:
            self.run_tr([seg(0, 1, "  ", words=[])])
        self.assertIn("no speech", str(cm.exception))

    def test_progress_is_real_and_monotonic(self):
        ticks = iter(range(0, 1000))
        seen = []
        with mock.patch.object(wl.time, "monotonic", side_effect=lambda: next(ticks)):
            self.run_tr(script_segments(), progress=lambda p, m: seen.append(p), duration=70.0)
        self.assertGreater(len(seen), 3)
        self.assertEqual(seen, sorted(seen))
        self.assertTrue(all(0 <= p < 1 for p in seen[:-1])); self.assertEqual(seen[-1], 1.0)
        self.assertAlmostEqual(seen[0], SCRIPT[0][1] / 70.0, places=2)   # position / duration, not a fake timer

    def test_cancel_stops_between_segments(self):
        n = []
        with self.assertRaises(TranscriptCancelled):
            self.run_tr(script_segments(), per_segment=lambda s: n.append(1), cancelled=lambda: len(n) >= 2)
        self.assertEqual(len(n), 2)

    def test_not_downloaded_raises_without_network(self):
        with mock.patch.object(wl, "_load_model") as load, mock.patch.object(wl.DOWNLOADER, "start") as dl:
            with self.assertRaises(TranscriptError) as cm:
                wl.transcribe(Path("x.mp4"), None, "small")
        self.assertIn("not downloaded", str(cm.exception)); load.assert_not_called(); dl.assert_not_called()

    def test_cuda_failure_retries_once_on_cpu_with_a_note(self):
        install_fake_model("small")
        devices = []

        def load(path, device, compute):
            devices.append((device, compute))
            if device == "cuda":
                raise RuntimeError("Library cublas64_12.dll is not found")
            return FakeModel(script_segments())
        with mock.patch.object(wl, "cuda_available", return_value=True), mock.patch.object(wl, "_load_model", side_effect=load):
            tr, notes = wl.transcribe(Path("x.mp4"), None, "small")
        self.assertEqual(devices, [("cuda", "int8_float16"), ("cpu", "int8")])
        self.assertTrue(any("CUDA transcription failed" in n and "cublas" in n for n in notes)); self.assertTrue(tr.available)

    def test_cpu_failure_is_reported_not_retried(self):
        install_fake_model("small")
        with mock.patch.object(wl, "_load_model", side_effect=MemoryError("out of memory")) as load:
            with self.assertRaises(TranscriptError) as cm:
                wl.transcribe(Path("x.mp4"), None, "small")
        self.assertEqual(load.call_count, 1); self.assertIn("MemoryError", str(cm.exception))

    def test_load_model_is_offline_only(self):
        fake = mock.MagicMock()
        with mock.patch.dict(sys.modules, {"faster_whisper": NS(WhisperModel=fake)}):
            wl._load_model("/m", "cpu", "int8")
        self.assertTrue(fake.call_args.kwargs["local_files_only"])


class Cache(Base):
    def make(self, content=b"A" * 3_000_000, name="a.bin"):
        p = Path(self.tmp.name) / name; p.write_bytes(content); return p

    def test_same_content_other_name_hits_changed_content_or_settings_miss(self):
        a = self.make(); b = self.make(name="renamed.bin")
        k = wl.cache_key(a, "small", None)
        self.assertEqual(k, wl.cache_key(b, "small", None))
        self.assertNotEqual(k, wl.cache_key(a, "base", None)); self.assertNotEqual(k, wl.cache_key(a, "small", "hi"))
        self.assertNotEqual(k, wl.cache_key(self.make(b"A" * 2_999_999, "c.bin"), "small", None))
        self.assertNotEqual(k, wl.cache_key(self.make(b"A" * 1_000_000 + b"B" + b"A" * 1_999_999, "d.bin"), "small", None))   # edit near the middle
        self.assertNotEqual(k, wl.cache_key(self.make(b"A" * 2_999_999 + b"B", "e.bin"), "small", None))                       # edit at the very end

    def test_roundtrip_and_corruption_tolerance(self):
        tr = Transcript([wl.Segment(0, 1, "hi", [wl.Word("hi", 0, 1)])], "faster-whisper", "en")
        wl.cache_put("abc123", tr, "small", None)
        got = wl.cache_get("abc123")
        self.assertTrue(got.word_level); self.assertEqual(got.segments[0].text, "hi")
        (settings.TRANSCRIPT_CACHE_DIR / "bad.json").write_text("{not json")
        self.assertIsNone(wl.cache_get("bad")); self.assertIsNone(wl.cache_get("missing"))
        (settings.TRANSCRIPT_CACHE_DIR / "empty.json").write_text('{"transcript": {"segments": []}}')
        self.assertIsNone(wl.cache_get("empty"))

    def test_drop_ignores_path_tricks(self):
        wl.cache_put("abc123", Transcript([wl.Segment(0, 1, "hi")], "x"), "small", None)
        victim = settings.TRANSCRIPT_DIR / "victim.json"; victim.write_text("{}")
        wl.cache_drop("../victim"); wl.cache_drop(None)
        self.assertTrue(victim.exists()); self.assertIsNotNone(wl.cache_get("abc123"))
        wl.cache_drop("abc123"); self.assertIsNone(wl.cache_get("abc123"))

    def test_prunes_oldest(self):
        for i in range(5):
            wl.cache_put(f"a{i}", Transcript([wl.Segment(0, 1, "hi")], "x"), "small", None, keep=3); time.sleep(0.01)
        self.assertEqual(sorted(p.stem for p in settings.TRANSCRIPT_CACHE_DIR.glob("*.json")), ["a2", "a3", "a4"])


def fake_downloader(kind: str):
    """Child process standing in for the Hugging Face download."""
    def factory(model, models_dir):
        repo = wl._repo_dirname(model)
        code = {
            "ok": "import os,sys,time\nd=os.path.join(sys.argv[2],sys.argv[3],'snapshots','r1');os.makedirs(d)\n"
                  "time.sleep(0.6)\nfor n in ('model.bin','config.json','tokenizer.json'):open(os.path.join(d,n),'w').write('x')\n",
            "network": "import sys,os;os.makedirs(os.path.join(sys.argv[2],sys.argv[3],'blobs'));sys.stderr.write('requests.exceptions.ConnectionError: Max retries exceeded');sys.exit(1)",
            "disk": "import sys;sys.stderr.write('OSError: [Errno 28] No space left on device');sys.exit(1)",
            "incomplete": "import sys,os;os.makedirs(os.path.join(sys.argv[2],sys.argv[3],'snapshots','r1'))",
            "slow": "import os,sys,time\nos.makedirs(os.path.join(sys.argv[2],sys.argv[3],'blobs'));open(os.path.join(sys.argv[2],sys.argv[3],'blobs','x.incomplete'),'w').write('p')\ntime.sleep(60)",
        }[kind]
        return [sys.executable, "-c", code, model, str(models_dir), repo]
    return factory


def wait_state(dl, until, timeout=15):
    end = time.time() + timeout
    while time.time() < end:
        s = dl.state()
        if s["status"] in until:
            return s
        time.sleep(0.05)
    raise AssertionError(f"download state stuck: {dl.state()}")


class Downloader(Base):
    def new(self, kind):
        return wl.ModelDownloader(fake_downloader(kind), poll=0.05)

    def test_success_makes_the_model_available(self):
        dl = self.new("ok")
        self.assertEqual(dl.start("tiny")["status"], "downloading")
        s = wait_state(dl, {"done", "failed"})
        self.assertEqual(s["status"], "done", s); self.assertIsNotNone(wl.model_path("tiny"))
        self.assertEqual(s["progress"], 1.0)

    def test_second_start_while_running_and_already_downloaded_are_refused(self):
        dl = self.new("slow")
        dl.start("tiny")
        with self.assertRaises(wl.DownloadError) as cm:
            dl.start("base")
        self.assertEqual(cm.exception.code, "busy")
        dl.cancel(); wait_state(dl, {"cancelled"})
        install_fake_model("small")
        with self.assertRaises(wl.DownloadError) as cm:
            self.new("ok").start("small")
        self.assertEqual(cm.exception.code, "already_downloaded")

    def test_cancel_kills_the_process_and_removes_partial_files(self):
        dl = self.new("slow")
        dl.start("tiny")
        time.sleep(0.3)
        repo = settings.MODELS_DIR / wl._repo_dirname("tiny")
        self.assertTrue(repo.exists())
        proc = dl._proc
        dl.cancel()
        s = wait_state(dl, {"cancelled"})
        self.assertIn("cancelled", s["message"]); self.assertFalse(repo.exists())
        self.assertIsNotNone(proc.poll())          # the child really ended
        with self.assertRaises(wl.DownloadError):
            dl.cancel()                            # nothing running any more

    def test_cancel_keeps_a_previously_existing_partial_repo_folder_that_is_not_ours(self):
        (settings.MODELS_DIR / wl._repo_dirname("tiny")).mkdir(parents=True)
        (settings.MODELS_DIR / wl._repo_dirname("tiny") / "keep.txt").write_text("x")
        dl = self.new("slow"); dl.start("tiny"); time.sleep(0.2); dl.cancel(); wait_state(dl, {"cancelled"})
        self.assertTrue((settings.MODELS_DIR / wl._repo_dirname("tiny") / "keep.txt").exists())

    def test_network_failure_is_classified_and_cleaned_up(self):
        dl = self.new("network"); dl.start("tiny")
        s = wait_state(dl, {"failed"})
        self.assertEqual(s["error_code"], "network"); self.assertIn("internet", s["error"])
        self.assertFalse((settings.MODELS_DIR / wl._repo_dirname("tiny")).exists())

    def test_disk_error_and_incomplete_download(self):
        dl = self.new("disk"); dl.start("tiny")
        self.assertEqual(wait_state(dl, {"failed"})["error_code"], "disk_full")
        dl = self.new("incomplete"); dl.start("tiny")
        self.assertEqual(wait_state(dl, {"failed"})["error_code"], "incomplete")
        self.assertIsNone(wl.model_path("tiny"))

    def test_preflight_disk_check_and_unknown_model_and_missing_library(self):
        with mock.patch.object(wl.shutil, "disk_usage", return_value=NS(free=10 * 1024 * 1024)):
            with self.assertRaises(wl.DownloadError) as cm:
                self.new("ok").start("small")
        self.assertEqual(cm.exception.code, "disk_full")
        with self.assertRaises(wl.DownloadError) as cm:
            self.new("ok").start("Systran/other")
        self.assertEqual(cm.exception.code, "unknown_model")
        with mock.patch.object(wl, "installed", return_value=False), self.assertRaises(wl.DownloadError) as cm:
            self.new("ok").start("tiny")
        self.assertEqual(cm.exception.code, "not_installed")

    def test_cannot_start_child_process(self):
        dl = wl.ModelDownloader(lambda m, d: ["/definitely/not/a/program"], poll=0.05); dl.start("tiny")
        self.assertEqual(wait_state(dl, {"failed"})["status"], "failed")

    def test_real_command_targets_the_configured_cache_dir_and_is_isolated(self):
        cmd = wl._download_command("small", Path("/models"))
        self.assertEqual(cmd[1], "-I"); self.assertEqual(cmd[-2:], ["small", "/models"]); self.assertIn("download_model", cmd[3])


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class AnalyzeJobs(Base):
    @classmethod
    def setUpClass(cls):
        cls.media = tempfile.TemporaryDirectory()
        cls.video = make_video(Path(cls.media.name) / "talk.mp4", duration=70)
        cls.silent = make_video(Path(cls.media.name) / "quiet.mp4", duration=30, audio=False)

    @classmethod
    def tearDownClass(cls):
        cls.media.cleanup()

    def setUp(self):
        super().setUp()
        from app.main import app
        self.client = TestClient(app).__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        super().tearDown()

    def upload(self, video=None, name="t"):
        r = self.client.post("/api/vanta/projects/upload", files={"file": ("talk.mp4", (video or self.video).read_bytes(), "video/mp4")}, data={"name": name})
        self.assertEqual(r.status_code, 200, r.text)
        return r.json()["id"]

    def analyze(self, pid, until=("awaiting_approval", "failed", "cancelled"), **body):
        r = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={"engine_mode": "baseline", **body})
        self.assertEqual(r.status_code, 200, r.text)
        return self.wait(r.json()["id"], until)

    def wait(self, jid, until, timeout=120):
        end = time.time() + timeout
        while time.time() < end:
            j = self.client.get(f"/api/vanta/jobs/{jid}").json()
            if j["status"] in until:
                return j
            time.sleep(0.1)
        self.fail(f"job stuck: {j}")

    def test_model_missing_means_no_download_no_fake_transcript_and_a_clear_note(self):
        pid = self.upload()
        with mock.patch.object(wl.DOWNLOADER, "start") as dl, mock.patch.object(wl, "_load_model") as load:
            j = self.analyze(pid)
        dl.assert_not_called(); load.assert_not_called()
        self.assertEqual(j["status"], "awaiting_approval")
        notes = " ".join(j["result"]["notes"]); self.assertIn("not downloaded", notes); self.assertIn("audio and visual signals only", notes)
        self.assertIsNone(j["result"]["transcript_source"])
        self.assertFalse(self.client.get(f"/api/vanta/projects/{pid}").json()["has_transcript"])

    def test_full_job_transcribes_reports_progress_and_second_project_reuses_cache(self):
        install_fake_model("small")
        progress_seen, stop = [], threading.Event()
        fm = FakeModel(script_segments(), per_segment=lambda s: time.sleep(0.15))
        with mock.patch.object(wl, "_load_model", return_value=fm) as load:
            pid = self.upload()
            r = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={"engine_mode": "baseline"})
            jid = r.json()["id"]

            def poll():
                while not stop.is_set():
                    j = self.client.get(f"/api/vanta/jobs/{jid}").json()
                    if j["status"] == "transcribing" and j.get("progress") is not None:
                        progress_seen.append(j["progress"])
                    time.sleep(0.05)
            t = threading.Thread(target=poll); t.start()
            j = self.wait(jid, {"awaiting_approval", "failed"}); stop.set(); t.join()
            self.assertEqual(j["status"], "awaiting_approval", j)
            self.assertEqual(j["result"]["transcript_source"], "faster-whisper"); self.assertTrue(j["result"]["word_level"])
            self.assertTrue(any(0 < p < 1 for p in progress_seen), progress_seen)
            self.assertEqual(progress_seen, sorted(progress_seen))
            proj = self.client.get(f"/api/vanta/projects/{pid}").json()
            self.assertTrue(proj["has_transcript"]); self.assertEqual(proj["transcript_meta"]["source"], "faster-whisper")
            tr = self.client.get(f"/api/vanta/projects/{pid}/transcript").json()
            self.assertEqual(tr["segments"][0]["text"], SCRIPT[0][2]); self.assertEqual(load.call_count, 1)
            # same file in another project -> cached, model not loaded again
            pid2 = self.upload(name="again")
            j2 = self.analyze(pid2)
            self.assertEqual(j2["status"], "awaiting_approval"); self.assertEqual(load.call_count, 1)
            self.assertIn("Reused the saved transcript", " ".join(j2["result"]["notes"]))
            self.assertTrue(self.client.get(f"/api/vanta/projects/{pid2}").json()["has_transcript"])
            # the cache works even when the model has been removed afterwards
            import shutil
            shutil.rmtree(settings.MODELS_DIR)
            pid3 = self.upload(name="third")
            j3 = self.analyze(pid3)
            self.assertIn("Reused the saved transcript", " ".join(j3["result"]["notes"]))
            # deleting a project removes its cached transcript
            key = self.client.get(f"/api/vanta/projects/{pid3}").json()["transcript_meta"]["cache_key"]
            self.assertIsNotNone(wl.cache_get(key))
            self.assertEqual(self.client.delete(f"/api/vanta/projects/{pid3}").status_code, 200)
            self.assertIsNone(wl.cache_get(key))

    def test_cancel_during_transcription_ends_cancelled_and_saves_nothing(self):
        install_fake_model("small")
        started = threading.Event()

        def slow(s):
            started.set(); time.sleep(0.4)
        with mock.patch.object(wl, "_load_model", return_value=FakeModel(script_segments(), per_segment=slow)):
            pid = self.upload()
            jid = self.client.post(f"/api/vanta/projects/{pid}/analyze", json={"engine_mode": "baseline"}).json()["id"]
            self.assertTrue(started.wait(30))
            self.assertEqual(self.client.post(f"/api/vanta/jobs/{jid}/cancel").status_code, 200)
            j = self.wait(jid, {"cancelled", "failed", "awaiting_approval"})
        self.assertEqual(j["status"], "cancelled", j)
        self.assertFalse(self.client.get(f"/api/vanta/projects/{pid}").json()["has_transcript"])
        self.assertEqual(list(settings.TRANSCRIPT_CACHE_DIR.glob("*.json")), [])
        self.assertEqual(self.client.get(f"/api/vanta/projects/{pid}").json()["status"], "new")

    def test_engine_error_becomes_a_note_and_the_job_still_finishes(self):
        install_fake_model("small")
        with mock.patch.object(wl, "_load_model", side_effect=RuntimeError("corrupt model")):
            j = self.analyze(self.upload())
        self.assertEqual(j["status"], "awaiting_approval"); self.assertIn("corrupt model", " ".join(j["result"]["notes"]))
        self.assertEqual(list(settings.TRANSCRIPT_CACHE_DIR.glob("*.json")), [])

    def test_video_without_audio_is_not_transcribed(self):
        install_fake_model("small")
        with mock.patch.object(wl, "_load_model") as load:
            j = self.analyze(self.upload(self.silent))
        load.assert_not_called(); self.assertIn("no audio track", " ".join(j["result"]["notes"]))

    def test_uploaded_transcript_wins_and_engine_is_not_run(self):
        install_fake_model("small")
        from tests.vanta_fixtures import script_srt
        with mock.patch.object(wl, "_load_model") as load:
            pid = self.upload()
            r = self.client.post(f"/api/vanta/projects/{pid}/transcript", files={"file": ("t.srt", script_srt().encode(), "text/plain")})
            self.assertEqual(r.status_code, 200)
            j = self.analyze(pid)
        load.assert_not_called(); self.assertEqual(j["result"]["transcript_source"], "subtitle-file")

    def test_unknown_whisper_model_in_request_is_a_note_not_a_crash(self):
        j = self.analyze(self.upload(), whisper_model="Systran/evil")
        self.assertEqual(j["status"], "awaiting_approval"); self.assertIn("Unknown transcription model", " ".join(j["result"]["notes"]))


class Api(Base):
    def setUp(self):
        super().setUp()
        from app.main import app
        self.client = TestClient(app).__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        super().tearDown()

    def test_status_endpoint_and_health_expose_the_same_engine_info(self):
        st = self.client.get("/api/vanta/transcription/status").json()
        self.assertFalse(st["ready"]); self.assertEqual(st["model"], "small")
        eng = next(e for e in self.client.get("/api/vanta/health").json()["transcription_engines"] if e["id"] == "faster-whisper")
        self.assertFalse(eng["available"]); self.assertIn("not downloaded", eng["detail"]); self.assertEqual(eng["device"], "cpu")

    def test_download_requires_explicit_confirmation(self):
        with mock.patch.object(wl.DOWNLOADER, "start") as start:
            r = self.client.post("/api/vanta/transcription/models/download", json={"model": "small"})
            self.assertEqual(r.status_code, 400); self.assertIn("Confirmation required", r.json()["detail"]); self.assertIn("485", r.json()["detail"])
            r = self.client.post("/api/vanta/transcription/models/download", json={"model": "small", "confirm": False})
            self.assertEqual(r.status_code, 400)
            start.assert_not_called()
            self.assertEqual(self.client.post("/api/vanta/transcription/models/download", json={"model": "nope", "confirm": True}).status_code, 400)
            start.return_value = {"status": "downloading"}
            r = self.client.post("/api/vanta/transcription/models/download", json={"model": "small", "confirm": True})
            self.assertEqual(r.status_code, 200); start.assert_called_once_with("small")

    def test_download_and_cancel_through_the_api_with_a_fake_downloader(self):
        dl = wl.ModelDownloader(fake_downloader("slow"), poll=0.05)
        with mock.patch.object(wl, "DOWNLOADER", dl):
            r = self.client.post("/api/vanta/transcription/models/download", json={"model": "tiny", "confirm": True})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(self.client.post("/api/vanta/transcription/models/download", json={"model": "base", "confirm": True}).status_code, 409)
            self.assertEqual(self.client.get("/api/vanta/transcription/status").json()["download"]["status"], "downloading")
            self.assertEqual(self.client.post("/api/vanta/transcription/models/download/cancel").status_code, 200)
            wait_state(dl, {"cancelled"})
            self.assertEqual(self.client.post("/api/vanta/transcription/models/download/cancel").status_code, 409)

    def test_clear_cache(self):
        wl.cache_put("abc", Transcript([wl.Segment(0, 1, "hi")], "x"), "small", None)
        self.assertEqual(self.client.delete("/api/vanta/transcription/cache").json(), {"cleared": 1})
        self.assertIsNone(wl.cache_get("abc"))


if __name__ == "__main__":
    unittest.main()

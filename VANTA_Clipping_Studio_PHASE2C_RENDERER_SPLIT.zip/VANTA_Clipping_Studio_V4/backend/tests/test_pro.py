import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
_tmp=tempfile.mkdtemp(prefix="studio_test_")
os.environ.setdefault("STUDIO_DATA_DIR",_tmp)

from app import captions, llm, stock, tts, youtube  # noqa: E402
from app.planner import build_plan, extract_keywords, make_hashtags  # noqa: E402
from app.schemas import CreateJobRequest, YouTubeUploadRequest  # noqa: E402


class PlannerAndSchema(unittest.TestCase):
    def test_defaults_are_youtube_ready(self):
        req=CreateJobRequest(topic="space facts")
        self.assertEqual((req.resolution_preset,req.frame_rate,req.narration),("quality",30,True))
        self.assertEqual(req.narration_engine,"edge")

    def test_long_form_duration_allowed(self):
        self.assertEqual(CreateJobRequest(topic="x long",duration_seconds=600,aspect_ratio="16:9").duration_seconds,600)

    def test_keywords_and_hashtags(self):
        self.assertIn("volcano",extract_keywords("The volcano erupted and the volcano glowed"))
        self.assertEqual(make_hashtags("ocean waves","",  "9:16")[0],"#Shorts")
        self.assertNotIn("#Shorts",make_hashtags("ocean waves","","16:9"))

    def test_scene_time_is_proportional_and_has_search_queries(self):
        script="Short one. "+"This is a much longer sentence with many many more words in it for timing purposes today. "*3
        plan=build_plan(topic="demo",script=script,source_text=None,duration=40,style="cinematic",input_type="script")
        self.assertAlmostEqual(plan["scenes"][-1]["end_seconds"],40,places=2)
        self.assertTrue(all(s["search_query"] for s in plan["scenes"]))

    def test_llm_output_is_validated(self):
        data=llm._validate(llm._extract_json('```json\n{"titles":["A"],"hashtags":["x y"],"scenes":[{"title":"T","narration":"Hello there world","search_query":"sky"},{"narration":""}]}\n```'))
        self.assertEqual(len(data["scenes"]),1); self.assertEqual(data["hashtags"],["#xy"])
        with self.assertRaises(ValueError): llm._validate({"scenes":[]})

    def test_llm_plan_used_when_provider_available(self):
        fake={"scenes":[{"title":"Hook","narration":"Ever wondered why the sky is blue today","search_query":"blue sky"},
                        {"title":"Why","narration":"Sunlight scatters in the air so blue light reaches your eyes","search_query":"sunlight"}],
              "titles":["Why Is The Sky Blue?"],"description":"Sky science.","hashtags":["#sky"]}
        with patch("app.llm.provider_name",return_value="ollama"),patch("app.llm.write_script",return_value=fake):
            plan=build_plan(topic="sky",script=None,source_text=None,duration=30,style="cinematic",input_type="topic")
        self.assertEqual(plan["planner"],"llm"); self.assertEqual(plan["scenes"][0]["search_query"],"blue sky")
        self.assertIn("#Shorts",plan["metadata"]["hashtags"])

    def test_llm_failure_falls_back_with_notice(self):
        with patch("app.llm.provider_name",return_value="ollama"),patch("app.llm.write_script",side_effect=RuntimeError("down")):
            plan=build_plan(topic="sky",script=None,source_text=None,duration=30,style="cinematic",input_type="topic")
        self.assertEqual(plan["planner"],"template_fallback"); self.assertIn("down",plan["planner_notice"])

    def test_youtube_upload_request_defaults_private(self):
        self.assertEqual(YouTubeUploadRequest().privacy,"private")


class CaptionsAndStock(unittest.TestCase):
    WORDS=[("Hello",0.0,0.3),("brave",0.3,0.6),("new",0.6,0.8),("world.",0.8,1.2),("Second",1.3,1.6),("line",1.6,2.0)]

    def test_ass_has_highlight_event_per_word(self):
        p=Path(_tmp)/"c.ass"; captions.write_ass(self.WORDS,p,1080,1920,"karaoke","#FFD23F","9:16")
        text=p.read_text(); self.assertEqual(text.count("Dialogue:"),6); self.assertIn("&H003FD2FF&",text); self.assertIn("PlayResX: 1080",text)

    def test_srt_timestamps(self):
        p=Path(_tmp)/"c.srt"; captions.write_srt(self.WORDS,p,"9:16")
        self.assertIn("00:00:00,000 --> 00:00:01,200",p.read_text())

    def test_stock_prefers_smallest_file_that_is_sharp_enough(self):
        video={"id":1,"duration":10,"video_files":[
            {"file_type":"video/mp4","width":640,"height":360,"link":"a"},{"file_type":"video/mp4","width":1920,"height":1080,"link":"b"},
            {"file_type":"video/mp4","width":3840,"height":2160,"link":"c"},{"file_type":"video/webm","width":1920,"height":1080,"link":"d"}]}
        self.assertEqual(stock.pick_file(video,1920,1080)["link"],"b")

    def test_stock_avoids_reused_and_too_short_clips(self):
        mk=lambda i,d:{"id":i,"duration":d,"video_files":[{"file_type":"video/mp4","width":1920,"height":1080,"link":str(i)}]}
        video,_=stock.pick_video([mk(1,20),mk(2,12),mk(3,3)],8,{1},1920,1080)
        self.assertEqual(video["id"],2)

    def test_stock_without_key_raises_readable_error(self):
        with patch.dict(os.environ,{"PEXELS_API_KEY":""}):
            with self.assertRaises(RuntimeError): stock.search("x","9:16")

    def test_youtube_title_and_tags_are_sanitised(self):
        self.assertTrue(youtube.clean_title("My <b>Title</b>",True).endswith("#Shorts"))
        self.assertEqual(len(youtube.clean_title("x"*300,False)),100)
        self.assertEqual(youtube.clean_tags(["#a","a","b,c","<x>"]),["a","bc","x"])

    def test_tts_word_estimates_cover_duration(self):
        w=tts.estimate_words("one two three four",4.0)
        self.assertAlmostEqual(w[-1][2],4.0,places=2); self.assertEqual(len(w),4)


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"),"ffmpeg required")
class EndToEnd(unittest.TestCase):
    def _settings(self,plan,**extra):
        base=dict(plan,aspect_ratio="9:16",resolution_preset="draft",frame_rate=30,duration_seconds=15,visual_style="cinematic",
                  generation_mode="motion_graphics",narration=True,narration_engine="edge",captions=True,caption_style="karaoke",
                  transitions=True,progress_bar=True,watermark="@test",channel_name="Test",visual_source="animated",music_volume=0.12)
        base.update(extra); return base

    def test_studio_pro_renders_valid_video_with_thumbnail_and_srt(self):
        from app.config import OUTPUT_DIR
        from app.renderer import render_video
        plan=build_plan(topic="Test",script="Rain falls on the quiet city. People hurry home under umbrellas. Lights glow in every window tonight.",
                        source_text=None,duration=15,style="cinematic",input_type="script")
        (OUTPUT_DIR/"e2e1").mkdir(parents=True,exist_ok=True)
        with patch.dict(os.environ,{"STUDIO_TTS_ENGINE":"test"}):
            result=render_video("e2e1",{"settings":self._settings(plan),"script":plan["script"],"topic":"Test"},lambda p,m:None)
        self.assertEqual(result["render_mode"],"studio_pro"); self.assertTrue(result["validation"]["has_audio"])
        self.assertEqual((result["validation"]["width"],result["validation"]["height"]),(360,640))
        self.assertTrue(Path(result["thumbnail_path"]).is_file()); self.assertTrue(Path(result["captions_path"]).read_text().strip())

    def test_stock_scene_is_used_and_credited_when_available(self):
        from app.config import OUTPUT_DIR
        from app.renderer import render_video
        clip=Path(_tmp)/"stock.mp4"
        import subprocess
        subprocess.run(["ffmpeg","-y","-loglevel","error","-f","lavfi","-i","testsrc2=s=640x360:r=30:d=6","-pix_fmt","yuv420p",str(clip)],check=True)
        plan=build_plan(topic="Test",script="Waves roll onto the beach. Gulls circle above the shore.",source_text=None,duration=15,style="cinematic",input_type="script")
        (OUTPUT_DIR/"e2e2").mkdir(parents=True,exist_ok=True)
        fake=lambda *a,**k:{"path":clip,"id":7,"credit":"Jane Doe / Pexels","query":"waves"}
        with patch.dict(os.environ,{"STUDIO_TTS_ENGINE":"test","PEXELS_API_KEY":"dummy"}),patch("app.stock.fetch_for_scene",side_effect=fake):
            result=render_video("e2e2",{"settings":self._settings(plan,visual_source="stock",transitions=False),"script":plan["script"],"topic":"Test"},lambda p,m:None)
        self.assertIn("stock",result["render_notice"]); self.assertIn("Jane Doe / Pexels",result["metadata"]["description"])

    def test_stock_network_failure_falls_back_to_animated(self):
        from app.config import OUTPUT_DIR
        from app.renderer import render_video
        plan=build_plan(topic="Test",script="One short scene about nothing at all really.",source_text=None,duration=15,style="cinematic",input_type="script")
        (OUTPUT_DIR/"e2e3").mkdir(parents=True,exist_ok=True)
        with patch.dict(os.environ,{"STUDIO_TTS_ENGINE":"test","PEXELS_API_KEY":"dummy"}),patch("app.stock.fetch_for_scene",side_effect=RuntimeError("offline")):
            result=render_video("e2e3",{"settings":self._settings(plan,visual_source="auto",narration=False),"script":plan["script"],"topic":"Test"},lambda p,m:None)
        self.assertIn("animated",result["render_notice"]); self.assertIn("offline",result["render_notice"])


if __name__=="__main__":
    unittest.main()

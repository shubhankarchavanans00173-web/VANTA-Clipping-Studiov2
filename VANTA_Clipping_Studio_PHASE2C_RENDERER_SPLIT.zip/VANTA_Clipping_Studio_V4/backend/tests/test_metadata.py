"""TODO 6: thumbnails (real frames from the exported MP4), publish metadata (transcript-only suggestions, provenance, validation) and clip SRT."""
import hashlib
import re
import tempfile
import time
import unittest
from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image, ImageFilter

from app.clipstudio import metadata as md, settings
from app.clipstudio.transcript import Segment, Transcript
from tests.vanta_fixtures import HAVE_FFMPEG, SCRIPT, isolate, make_video, script_srt

TR = Transcript([
    Segment(0, 5, "Intro that is outside of the clip entirely."),
    Segment(10, 16, "Here is the mistake that ruins most videos. The mistake is skipping audio checks."),
    Segment(16, 22, "Audio checks take ten seconds and viewers notice instantly."),
    Segment(40, 45, "Unrelated outro about zebras."),
], "subtitle-file")


class Suggest(unittest.TestCase):
    def test_built_only_from_the_clip_text(self):
        s = md.suggest(TR, 10, 22)
        self.assertTrue(s["available"]); self.assertEqual(s["provenance"]["source"], "transcript")
        self.assertEqual(s["title"], "Here is the mistake that ruins most videos")
        text = md.clip_text(TR, 10, 22).lower()
        self.assertNotIn("zebras", text); self.assertNotIn("intro", text)
        self.assertTrue(set(re.sub(r"[^\w ]", "", s["description"].lower()).split()) <= set(re.sub(r"[^\w ]", "", text).split()))
        self.assertTrue(s["hashtags"])
        for tag in s["hashtags"]:
            self.assertTrue(tag.startswith("#") and tag[1:].lower() in text, tag)    # every keyword really occurs in the clip
        self.assertNotIn("#zebras", s["hashtags"]); self.assertNotIn("#that", s["hashtags"]); self.assertNotIn("#here", s["hashtags"])
        self.assertIn("#mistake", s["hashtags"]); self.assertIn("#audio", s["hashtags"])     # the repeated words come first

    def test_nothing_is_invented_without_text(self):
        for tr, a, b in ((None, 0, 10), (Transcript([], "none"), 0, 10), (TR, 25, 35)):
            s = md.suggest(tr, a, b)
            self.assertEqual((s["title"], s["description"], s["hashtags"], s["available"]), ("", "", [], False)); self.assertIn("without making it up", s["message"])

    def test_title_limit_and_non_latin_text(self):
        long = Transcript([Segment(0, 9, " ".join(["word"] * 60) + ".")], "x")
        self.assertLessEqual(len(md.suggest(long, 0, 9)["title"]), md.TITLE_MAX)
        hi = Transcript([Segment(0, 9, "यह वीडियो बहुत महत्वपूर्ण जानकारी देता है। जानकारी सबके लिए है।")], "x")
        s = md.suggest(hi, 0, 9)
        self.assertTrue(s["title"].startswith("यह वीडियो")); self.assertIn("#जानकारी", s["hashtags"])

    def test_validate(self):
        ok = md.validate(" Title ", "desc", "#One two, #one  #Three")
        self.assertEqual(ok, {"title": "Title", "description": "desc", "hashtags": ["#One", "#two", "#Three"]})
        for args in (("x" * 101, "", []), ("t", "x" * 5001, []), ("a<b", "", []), ("t", "a>b", []), ("t", "", [f"t{i}" for i in range(16)])):
            with self.subTest(args=args[0][:5]), self.assertRaises(ValueError):
                md.validate(*args)
        self.assertEqual(md.clean_hashtags(["#1234", "#ok!", "bad tag"]), ["#ok", "#bad", "#tag"])


class FrameStats(unittest.TestCase):
    def test_sharp_vs_blurred_and_dark(self):
        d = Path(tempfile.mkdtemp())
        img = Image.new("RGB", (400, 400), "white")
        for x in range(0, 400, 20):
            for y in range(0, 400, 20):
                if (x + y) // 20 % 2 == 0:
                    img.paste("black", (x, y, x + 20, y + 20))
        img.save(d / "sharp.jpg"); img.filter(ImageFilter.GaussianBlur(8)).save(d / "blur.jpg"); Image.new("RGB", (400, 400), "black").save(d / "dark.jpg")
        self.assertGreater(md.frame_stats(d / "sharp.jpg")["sharpness"], 5 * md.frame_stats(d / "blur.jpg")["sharpness"])
        self.assertLess(md.frame_stats(d / "dark.jpg")["brightness"], 12)


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class DarkFrames(unittest.TestCase):
    def test_black_frames_are_flagged_and_never_recommended(self):
        import subprocess
        d = Path(tempfile.mkdtemp()); v = d / "mixed.mp4"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-filter_complex",
                        "color=c=black:s=320x240:d=6:r=25[a];testsrc2=s=320x240:d=4:r=25[b];[a][b]concat=n=2:v=1,format=yuv420p", "-c:v", "libx264", str(v)], check=True, timeout=60)
        items = md.make_candidates(v, d / "out", 10.0, 5)
        dark = [i for i in items if i["dark"]]
        self.assertGreaterEqual(len(dark), 2); self.assertGreaterEqual(len(items) - len(dark), 1)
        rec = next(i for i in items if i["recommended"])
        self.assertFalse(rec["dark"])


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class Api(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = isolate(); cls.media = tempfile.TemporaryDirectory()
        cls.video = make_video(Path(cls.media.name) / "t.mp4", duration=70)
        from app.main import app
        cls.client = TestClient(app).__enter__()
        r = cls.client.post("/api/vanta/projects/upload", files={"file": ("t.mp4", cls.video.read_bytes(), "video/mp4"), "transcript": ("t.srt", script_srt().encode(), "text/plain")}, data={"name": "Meta talk"})
        cls.pid = r.json()["id"]
        j = cls.client.post(f"/api/vanta/projects/{cls.pid}/analyze", json={"transcribe": False, "target_duration": 15, "count": 3}).json()
        cls.wait(j["id"], {"awaiting_approval"})
        cls.cands = cls.client.get(f"/api/vanta/projects/{cls.pid}").json()["candidates"]
        cls.cid = cls.cands[0]["id"]
        cls.client.patch(f"/api/vanta/candidates/{cls.cid}", json={"status": "approved"})
        j = cls.client.post(f"/api/vanta/projects/{cls.pid}/render", json={"candidate_ids": [cls.cid], "settings": {"captions": False}}).json()
        end = cls.wait(j["id"], {"completed", "failed"}, 120)
        assert end["status"] == "completed", end
        cls.exp = cls.client.get("/api/vanta/exports").json()[0]; cls.eid = cls.exp["id"]

    @classmethod
    def wait(cls, jid, until, timeout=90):
        end = time.time() + timeout
        while time.time() < end:
            j = cls.client.get(f"/api/vanta/jobs/{jid}").json()
            if j["status"] in until:
                return j
            time.sleep(0.2)
        raise AssertionError(j)

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None); cls.media.cleanup(); cls.tmp.cleanup()

    def test_01_thumbnails_are_real_distinct_frames_of_the_export(self):
        r = self.client.post(f"/api/vanta/exports/{self.eid}/thumbnails?count=5")
        self.assertEqual(r.status_code, 200, r.text)
        items = r.json()["candidates"]
        self.assertEqual(len(items), 5); self.assertEqual(sum(1 for i in items if i["recommended"]), 1)
        hashes, w_h = set(), set()
        for i in items:
            b = self.client.get(i["url"]); self.assertEqual(b.status_code, 200); self.assertEqual(b.headers["content-type"], "image/jpeg")
            hashes.add(hashlib.md5(b.content).hexdigest())
            f = settings.EXPORT_DIR / "_thumbs" / self.eid / i["name"]
            with Image.open(f) as im:
                w_h.add(im.size); self.assertEqual(im.format, "JPEG")
            self.assertTrue(0 < i["time"] < self.exp["duration"])
        self.assertEqual(len(hashes), 5)                       # different moments, different pictures
        self.assertEqual(len(w_h), 1); self.assertEqual(w_h.pop(), (1080, 1920))   # same geometry as the 9:16 export
        best = next(i for i in items if i["recommended"])
        self.assertEqual(best["sharpness"], max(i["sharpness"] for i in items if not i["dark"]))
        self.assertEqual([i["time"] for i in items], sorted(i["time"] for i in items))

    def test_02_choose_candidate_then_custom_time_and_download(self):
        self.client.post(f"/api/vanta/exports/{self.eid}/thumbnails")
        self.assertEqual(self.client.get(f"/api/vanta/exports/{self.eid}/thumbnail").status_code, 404)    # nothing chosen yet
        r = self.client.put(f"/api/vanta/exports/{self.eid}/thumbnail", json={"name": "t2.jpg"}); self.assertEqual(r.status_code, 200, r.text)
        d = self.client.get(f"/api/vanta/exports/{self.eid}/thumbnail")
        self.assertEqual(d.content, (settings.EXPORT_DIR / "_thumbs" / self.eid / "t2.jpg").read_bytes()); self.assertIn("_thumbnail.jpg", d.headers["content-disposition"])
        r = self.client.put(f"/api/vanta/exports/{self.eid}/thumbnail", json={"time": 3.25}).json()
        self.assertTrue(r["selected"]["custom"]); self.assertEqual(r["selected"]["time"], 3.25)
        img = self.client.get(r["url"]); self.assertEqual(img.status_code, 200)
        self.assertNotEqual(img.content, d.content)
        listed = self.client.get(f"/api/vanta/exports/{self.eid}/thumbnails").json()
        self.assertEqual(listed["selected"]["name"], r["selected"]["name"])                               # persisted
        for bad in ({}, {"name": "t1.jpg", "time": 1}, {"time": 9999}, {"time": -1}, {"name": "../../etc/passwd"}, {"name": "t9.jpg"}):
            self.assertIn(self.client.put(f"/api/vanta/exports/{self.eid}/thumbnail", json=bad).status_code, {400, 404, 422}, bad)
        self.assertEqual(self.client.get(f"/api/vanta/exports/{self.eid}/thumbnails/..%2F..%2Fvanta.db").status_code, 404)
        self.assertEqual(self.client.get(f"/api/vanta/exports/{self.eid}/thumbnails/t1.png").status_code, 404)

    def test_03_metadata_suggest_edit_provenance_validation(self):
        s = self.client.post(f"/api/vanta/exports/{self.eid}/metadata/suggest").json()
        self.assertTrue(s["available"]); self.assertTrue(s["title"]); text = " ".join(t for _, _, t in SCRIPT).lower()
        self.assertTrue(set(re.sub(r"[^\w ]", "", s["title"].lower()).split()) <= set(re.sub(r"[^\w ]", "", text).split()))
        self.assertEqual(self.client.get(f"/api/vanta/exports/{self.eid}/metadata").json()["title"], "")        # suggesting saves nothing
        r = self.client.put(f"/api/vanta/exports/{self.eid}/metadata", json={"title": s["title"], "description": "My own words", "hashtags": s["hashtags"]})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()["provenance"], {"title": "transcript", "description": "user", "hashtags": "transcript"})
        got = self.client.get(f"/api/vanta/exports/{self.eid}/metadata").json()
        self.assertEqual(got["description"], "My own words")
        r = self.client.put(f"/api/vanta/exports/{self.eid}/metadata", json={"title": "x" * 150}); self.assertEqual(r.status_code, 400); self.assertIn("100", r.json()["detail"])
        self.assertEqual(self.client.get(f"/api/vanta/exports/{self.eid}/metadata").json()["description"], "My own words")   # failed save changed nothing
        cleared = self.client.put(f"/api/vanta/exports/{self.eid}/metadata", json={"title": "", "description": "", "hashtags": "#a, b"}).json()
        self.assertEqual((cleared["provenance"]["title"], cleared["hashtags"]), ("empty", ["#a", "#b"]))

    def test_04_candidate_srt_is_clip_relative_and_from_the_transcript(self):
        c = self.cands[0]
        r = self.client.get(f"/api/vanta/candidates/{c['id']}/srt"); self.assertEqual(r.status_code, 200)
        self.assertIn("attachment", r.headers["content-disposition"]); body = r.text
        self.assertTrue(body.startswith("1\n00:00:0"))                                    # re-based to 0, not source time
        words = set(re.sub(r"[^\w ]", "", " ".join(t for _, _, t in SCRIPT).lower()).split())
        for line in body.splitlines():
            if line and not line[0].isdigit():
                self.assertTrue(set(re.sub(r"[^\w ]", "", line.lower()).split()) <= words, line)
        # no transcript -> 409
        p2 = self.client.post("/api/vanta/projects/upload", files={"file": ("t.mp4", self.video.read_bytes(), "video/mp4")}, data={"name": "no tr"}).json()["id"]
        cid2 = self.client.post(f"/api/vanta/projects/{p2}/candidates", json={"start": "0:05", "end": "0:20"}).json()["id"]
        self.assertEqual(self.client.get(f"/api/vanta/candidates/{cid2}/srt").status_code, 409)

    def test_05_zz_deleting_the_export_removes_its_thumbnails(self):
        self.client.post(f"/api/vanta/exports/{self.eid}/thumbnails")
        d = settings.EXPORT_DIR / "_thumbs" / self.eid; self.assertTrue(d.is_dir())
        self.assertEqual(self.client.delete(f"/api/vanta/exports/{self.eid}").status_code, 200)
        self.assertFalse(d.exists())


if __name__ == "__main__":
    unittest.main()

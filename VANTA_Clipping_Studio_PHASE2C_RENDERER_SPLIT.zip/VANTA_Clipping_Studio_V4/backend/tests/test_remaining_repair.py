"""Tests for the final-repair code that previously had none: dataset_eval, quotes, ratings migration, retry, transcript path rebase.

Pure-logic tests use hand-computed expected values (no tautologies: the numbers below were worked out on paper).
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from app.clipstudio import db, pipeline, settings
from app.clipstudio.selection import dataset_eval as D
from app.clipstudio.selection import quotes
from app.clipstudio.transcript import Segment, Transcript
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video, script_srt


# --------------------------------------------------------------------------------------------- dataset_eval metrics
class MetricTests(unittest.TestCase):
    def test_precision_uses_rated_clips_only(self):
        # top 4 = excellent, weak, unrated, good -> rated = 3, good-or-better = 2
        self.assertEqual(D.precision_at_k(["excellent", "weak", None, "good"], 4), 0.667)

    def test_precision_none_when_nothing_rated(self):
        self.assertIsNone(D.precision_at_k([None, None], 5))

    def test_precision_respects_k(self):
        self.assertEqual(D.precision_at_k(["good", "weak", "weak"], 1), 1.0)

    def test_ndcg_perfect_and_worse_orders(self):
        pool = ["excellent", "good", "weak"]
        self.assertEqual(D.ndcg_at_k(["excellent", "good", "weak"], 3, pool), 1.0)
        # gains: excellent=7, good=3. ideal=7/1 + 3/log2(3) = 8.893 ; swapped = 3/1 + 7/log2(3)=7.417 -> 0.834
        self.assertEqual(D.ndcg_at_k(["good", "excellent", "weak"], 3, pool), 0.834)

    def test_ndcg_unrated_counts_as_zero_gain(self):
        self.assertEqual(D.ndcg_at_k([None, "excellent"], 2, ["excellent"]), round((7 / 1.5849625007211563) / 7, 3))

    def test_ndcg_none_without_any_good_label(self):
        self.assertIsNone(D.ndcg_at_k(["weak"], 1, ["weak", "incomplete"]))

    def test_recall_needs_good_moments_and_matches_by_overlap(self):
        self.assertIsNone(D.recall_at_k([(0, 10)], [], 5))
        good = [(0, 10), (50, 60)]
        self.assertEqual(D.recall_at_k([(1, 10), (20, 30)], good, 5), 0.5)
        self.assertEqual(D.recall_at_k([(1, 10), (20, 30)], good, 1), 0.5)
        self.assertEqual(D.recall_at_k([(20, 30), (1, 10)], good, 1), 0.0)     # k cuts the list

    def test_duplicate_rate(self):
        self.assertEqual(D.duplicate_rate([(0, 10)]), 0.0)
        self.assertEqual(D.duplicate_rate([(0, 10), (2, 11), (40, 50)]), round(1 / 3, 3))    # one overlapping pair of three
        self.assertEqual(D.duplicate_rate([(0, 10), (20, 30)]), 0.0)

    def test_match_label_needs_iou_and_picks_best(self):
        labels = [{"start": 0, "end": 10, "label": "good"}, {"start": 5, "end": 30, "label": "weak"}]
        self.assertEqual(D.match_label((0, 10), labels), "good")
        self.assertEqual(D.match_label((6, 29), labels), "weak")
        self.assertIsNone(D.match_label((100, 110), labels))
        self.assertIsNone(D.match_label((0, 4), [{"start": 0, "end": 10, "label": "good"}]))    # IoU 0.4 < 0.6

    def test_summarize_counts_unrated_without_assuming_quality(self):
        rows = [{"grades": ["good", None, "weak"], "p_at_k": 0.5, "ndcg": 0.4, "recall": None, "duplicate_rate": 0.0,
                 "struct": {"invalid_boundary_rate": 0.0, "within_duration_rate": 1.0}}]
        s = D.summarize(rows, 3)
        self.assertEqual((s["clips"], s["rated_clips"], s["rated_share"]), (3, 2, 0.667))
        self.assertEqual(s["human_acceptance_rate"], 0.5)         # 1 good of 2 RATED; unrated is ignored
        self.assertIsNone(s["recall@3 (only videos with exhaustive labels)"])

    def test_warnings_small_sample_unrated_tuning_and_missing_test_split(self):
        row = {"grades": ["good", None, None, None, None]}
        per = {"dev": {"baseline": [row], "multi-signal": [row]}, "test": {"baseline": [], "multi-signal": []}}
        text = " ".join(D.warnings(per, "dev"))
        self.assertIn("anecdotes", text); self.assertIn("human label", text); self.assertIn("tuned on the 'dev'", text); self.assertIn("No held-out", text)


# ----------------------------------------------------------------------------------------- dataset validation + pool
class DatasetFileTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.dir = Path(self.tmp.name)
        (self.dir / "a.srt").write_text(script_srt(), "utf-8")
        (self.dir / "b.srt").write_text(script_srt(), "utf-8")

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, **over):
        data = {"dataset": {"name": "t", "kind": "human", "annotator": "me"}, "settings": {"target": 15, "k": 3},
                "videos": [{"id": "a", "duration": 70, "transcript": "a.srt", "split": "dev", "labels": [{"start": 0.3, "end": 9.5, "label": "good"}]},
                           {"id": "b", "duration": 70, "transcript": "b.srt", "split": "test", "labels": [{"start": 12.3, "end": 21.8, "label": "excellent"}]}]}
        data.update(over)
        p = self.dir / "ds.json"; p.write_text(json.dumps(data), "utf-8"); return p

    def test_rejects_non_human_kind(self):
        with self.assertRaisesRegex(D.DatasetError, "human"):
            D.load_dataset(self.write(dataset={"name": "x", "kind": "synthetic"}))

    def test_rejects_bad_json_missing_file_and_empty_videos(self):
        with self.assertRaises(D.DatasetError): D.load_dataset(self.dir / "nope.json")
        bad = self.dir / "bad.json"; bad.write_text("{not json", "utf-8")
        with self.assertRaises(D.DatasetError): D.load_dataset(bad)
        with self.assertRaises(D.DatasetError): D.load_dataset(self.write(videos=[]))

    def test_rejects_duplicate_ids_bad_split_and_missing_keys(self):
        v = {"id": "a", "duration": 70, "transcript": "a.srt", "labels": []}
        with self.assertRaisesRegex(D.DatasetError, "Duplicate"): D.load_dataset(self.write(videos=[v, dict(v)]))
        with self.assertRaisesRegex(D.DatasetError, "split"): D.load_dataset(self.write(videos=[{**v, "split": "train"}]))
        with self.assertRaisesRegex(D.DatasetError, "missing"): D.load_dataset(self.write(videos=[{"id": "z"}]))

    def test_rejects_unlabelled_unknown_and_out_of_range_labels(self):
        v = {"id": "a", "duration": 70, "transcript": "a.srt"}
        for lab in ({"start": 1, "end": 5, "label": None}, {"start": 1, "end": 5, "label": "amazing"},
                    {"start": 5, "end": 5, "label": "good"}, {"start": 1, "end": 500, "label": "good"}):
            with self.subTest(lab=lab), self.assertRaises(D.DatasetError):
                D.load_dataset(self.write(videos=[{**v, "labels": [lab]}]))

    def test_transcript_paths_resolve_relative_to_the_dataset_file(self):
        data = D.load_dataset(self.write())
        self.assertEqual(data["videos"][0]["_transcript_path"], self.dir / "a.srt")

    def test_evaluate_reports_splits_separately_and_warns_honestly(self):
        res = D.evaluate(self.write())
        self.assertEqual(set(res["results"]), {"dev", "test"})
        for split in res["results"].values():
            self.assertEqual(set(split), {"baseline", "multi-signal"})
            self.assertGreater(split["multi-signal"]["clips"], 0)
        text = " ".join(res["warnings"])
        self.assertIn("anecdotes", text)                       # only 2 videos -> must not look like evidence
        self.assertIn("Human-labelled evaluation", D.render(res))

    def test_evaluate_flags_tuning_split(self):
        res = D.evaluate(self.write(settings={"target": 15, "k": 3, "tuned_on_split": "dev"}))
        self.assertTrue(any("tuned on the 'dev'" in w for w in res["warnings"]))

    def test_export_pool_produces_unlabelled_template_that_load_dataset_refuses(self):
        out = self.dir / "pool.json"
        vids = [{"id": "a", "duration": 70, "transcript": str(self.dir / "a.srt"), "split": "dev"}]
        data = D.export_pool(vids, 15, 3, out)
        self.assertTrue(out.is_file()); on_disk = json.loads(out.read_text("utf-8"))
        labels = on_disk["videos"][0]["labels"]
        self.assertTrue(labels)
        self.assertTrue(all(l["label"] is None and l["proposed_by"] and "text" in l for l in labels))
        self.assertTrue(all(set(l["proposed_by"]) <= set(D.RANKERS) for l in labels))
        self.assertEqual(on_disk["dataset"]["kind"], "human")
        self.assertIn("TEMPLATE", data["dataset"]["name"])
        with self.assertRaises(D.DatasetError):                # a human must label before it can be evaluated
            D.load_dataset(out)
        # once a human fills every label it loads
        for l in labels: l["label"] = "weak"
        out.write_text(json.dumps(on_disk), "utf-8")
        self.assertEqual(len(D.load_dataset(out)["videos"]), 1)

    def test_cli_dataset_error_exits_2(self):
        import subprocess, sys
        r = subprocess.run([sys.executable, "evaluate_ranking.py", "--dataset", str(self.dir / "missing.json")], capture_output=True, text=True, timeout=60)
        self.assertEqual(r.returncode, 2); self.assertIn("ERROR", r.stdout)


# --------------------------------------------------------------------------------------------------------- quotes
class QuoteTests(unittest.TestCase):
    TR = Transcript([Segment(0, 5, "I don\u2019t think that\u2019s right, honestly."), Segment(5, 10, 'He said "never give up" and left.'),
                     Segment(10, 14, "The   result\nwas   huge \u2014 really huge!")], "subtitle-file")

    def blob(self):
        return quotes.transcript_blob(self.TR)

    def test_curly_vs_straight_apostrophes_and_quotes_match(self):
        b = self.blob()
        self.assertTrue(quotes.is_quote_in("I don't think that's right", b))
        self.assertTrue(quotes.is_quote_in("\u201cnever give up\u201d", b))
        self.assertTrue(quotes.is_quote_in('He said \u201cnever give up\u201d and left', b))

    def test_case_whitespace_and_dash_insensitive(self):
        b = self.blob()
        self.assertTrue(quotes.is_quote_in("THE RESULT WAS HUGE - really huge", b))

    def test_trailing_ellipsis_and_period_tolerated(self):
        b = self.blob()
        self.assertTrue(quotes.is_quote_in("I don't think that's right\u2026", b))
        self.assertTrue(quotes.is_quote_in("I don't think that's right...", b))

    def test_fabricated_or_partial_word_text_is_not_found(self):
        b = self.blob()
        self.assertFalse(quotes.is_quote_in("I think that's absolutely right", b))
        self.assertFalse(quotes.is_quote_in("don", b))              # substring of a word must not match
        self.assertFalse(quotes.is_quote_in("", b)); self.assertFalse(quotes.is_quote_in(None, b))
        self.assertFalse(quotes.is_quote_in("anything", ""))

    def test_blob_empty_without_transcript(self):
        self.assertEqual(quotes.transcript_blob(None), "")
        self.assertEqual(quotes.transcript_blob(Transcript([], "none")), "")

    def test_verify_analysis_drops_fabricated_quote_and_keeps_real_one(self):
        analysis = {"hook": "never give up", "payoff": "this payoff was invented by a model", "needs_setup": True,
                    "suggested_setup": {"setup": "completely made up setup line", "start": 1}}
        out, excerpt, rep = quotes.verify_analysis(analysis, "the result was huge", self.blob())
        self.assertEqual(out["hook"], "never give up")
        self.assertIsNone(out["payoff"])
        self.assertIsNone(out["suggested_setup"]); self.assertFalse(out["needs_setup"])
        self.assertEqual(excerpt, "the result was huge")
        self.assertEqual(sorted(rep["verified"]), ["excerpt", "hook"]); self.assertEqual(sorted(rep["dropped"]), ["payoff", "suggested_setup"])
        self.assertEqual(out["quote_check"], rep)

    def test_verify_analysis_blanks_fabricated_excerpt(self):
        _, excerpt, rep = quotes.verify_analysis({"hook": None, "payoff": None}, "invented excerpt text", self.blob())
        self.assertEqual(excerpt, ""); self.assertIn("excerpt", rep["dropped"])

    def test_verify_analysis_without_transcript_changes_nothing(self):
        a = {"hook": "x", "payoff": "y"}
        out, excerpt, rep = quotes.verify_analysis(a, "ex", "")
        self.assertEqual((out["hook"], excerpt, rep), ("x", "ex", {"verified": [], "dropped": []}))


# ---------------------------------------------------------------------------------------------- ratings migration
class RatingsMigrationTests(unittest.TestCase):
    def test_old_clip_feedback_table_is_migrated_and_old_rows_survive(self):
        keep = settings.BASE
        with tempfile.TemporaryDirectory() as d:
            try:
                settings.configure(Path(d))
                con = sqlite3.connect(settings.DB_PATH)
                con.executescript("CREATE TABLE clip_feedback(candidate_id TEXT PRIMARY KEY, project_id TEXT NOT NULL, label TEXT NOT NULL, note TEXT,"
                                  " engine TEXT, score REAL, start REAL, end REAL, features TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);"
                                  "INSERT INTO clip_feedback VALUES('old','p','good','kept note','multi-signal-rules',0.7,1,9,'{}','t','t');")
                con.commit(); con.close()
                db.init(); db.init()                                  # idempotent
                con = sqlite3.connect(settings.DB_PATH); con.row_factory = sqlite3.Row
                cols = {r[1] for r in con.execute("PRAGMA table_info(clip_feedback)")}
                row = dict(con.execute("SELECT * FROM clip_feedback WHERE candidate_id='old'").fetchone()); con.close()
                self.assertTrue({"engine_version", "ranker_kind"} <= cols)
                self.assertEqual((row["label"], row["note"], row["score"]), ("good", "kept note", 0.7))
                self.assertIsNone(row["engine_version"]); self.assertIsNone(row["ranker_kind"])      # unknown stays unknown, never invented
            finally:
                settings.configure(keep); db.init()

    def test_new_ratings_store_ranker_version_and_kind(self):
        tmp = isolate()
        try:
            p = db.create_project("p", "upload")
            plain = db.add_candidate(p["id"], 1, 9, 0.5, "heuristic", [], "x")
            ruled = db.add_candidate(p["id"], 10, 19, 0.6, "multi-signal-rules", [], "y")
            llm = db.add_candidate(p["id"], 20, 29, 0.6, "multi-signal-rules", [], "z")
            db.update_candidate(ruled["id"], analysis={"engine": "multi-signal-rules", "engine_version": "4.1", "features": {"hook": {"value": 0.8}}})
            db.update_candidate(llm["id"], analysis={"engine": "multi-signal-rules", "engine_version": "4.1", "llm": {"status": "evaluated"}})
            self.assertEqual(db.set_feedback(plain["id"], "weak")["ranker_kind"], "heuristic")
            r = db.set_feedback(ruled["id"], "good"); self.assertEqual((r["ranker_kind"], r["engine_version"]), ("rules", "4.1"))
            self.assertEqual(json.loads(r["features"]), {"hook": 0.8})
            self.assertEqual(db.set_feedback(llm["id"], "excellent")["ranker_kind"], "rules+local-llm")
            self.assertEqual(db.set_feedback(llm["id"], "weak")["label"], "weak")            # re-rating updates, does not duplicate
            self.assertEqual(len([f for f in db.list_feedback(p["id"]) if f["candidate_id"] == llm["id"]]), 1)
            with self.assertRaises(ValueError): db.set_feedback(llm["id"], "amazing")
        finally:
            tmp.cleanup()


# ------------------------------------------------------------------------------- transcript path rebase / has_transcript
class TranscriptPathTests(unittest.TestCase):
    def setUp(self):
        self.tmp = isolate()
        self.tr = Transcript([Segment(0, 4, "hello there")], "subtitle-file")
        self.p = db.create_project("p", "upload")
        self.saved = pipeline.save_transcript(self.p["id"], self.tr)

    def tearDown(self):
        self.tmp.cleanup()

    def project(self, **over):
        return {**db.get_project(self.p["id"]), **over}

    def test_normal_path_loads(self):
        self.assertTrue(pipeline.transcript_available(self.project()))

    def test_stale_absolute_path_falls_back_to_canonical_file(self):
        stale = self.project(transcript_path=r"C:\old install\data\transcripts\whatever.json")
        self.assertEqual(pipeline.load_project_transcript(stale).segments[0].text, "hello there")

    def test_path_outside_data_dir_is_not_trusted(self):
        outside = Path(tempfile.gettempdir()) / "evil_transcript.json"
        outside.write_text(json.dumps(Transcript([Segment(0, 1, "SECRET")], "x").to_dict()), "utf-8")
        try:
            got = pipeline.load_project_transcript(self.project(transcript_path=str(outside)))
            self.assertEqual(got.segments[0].text, "hello there")      # canonical file wins; outside file never read
        finally:
            outside.unlink(missing_ok=True)

    def test_renamed_file_is_found_by_basename_in_current_dir(self):
        moved = settings.TRANSCRIPT_DIR / "renamed.json"; self.saved.rename(moved)
        self.assertTrue(pipeline.transcript_available(self.project(id="other-id", transcript_path="/gone/dir/renamed.json")))

    def test_has_transcript_is_false_when_file_missing_or_corrupt(self):
        self.saved.write_text("{broken", "utf-8")
        self.assertFalse(pipeline.transcript_available(self.project()))
        self.saved.unlink()
        self.assertFalse(pipeline.transcript_available(self.project()))
        self.assertFalse(pipeline.transcript_available({"id": "none", "transcript_path": None}))


# ------------------------------------------------------------------------------------------- retry includes failed
@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg not installed")
class RetryIncludesFailedTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        cls.tmp = isolate(); cls.media = tempfile.TemporaryDirectory()
        cls.video = make_video(Path(cls.media.name) / "t.mp4", duration=20)
        from app.main import app
        cls.client = TestClient(app).__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None); cls.media.cleanup(); cls.tmp.cleanup()

    def setUp(self):
        p = db.create_project("retry", "upload", source_path=str(self.video))
        self.pid = p["id"]
        self.cands = {s: db.add_candidate(self.pid, 1 + i * 6, 5 + i * 6, 0.5, "heuristic", [], s) for i, s in enumerate(("failed", "approved", "suggested", "rejected"))}
        for s, c in self.cands.items():
            db.update_candidate(c["id"], status=s)

    def post(self, body):
        with mock.patch.object(pipeline, "submit_render", return_value={"id": "job-x", "status": "queued"}) as m:
            r = self.client.post(f"/api/vanta/projects/{self.pid}/render", json=body)
        return r, m

    def test_default_retry_includes_approved_and_failed_only(self):
        r, m = self.post({})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(sorted(m.call_args[0][1]), sorted([self.cands["failed"]["id"], self.cands["approved"]["id"]]))

    def test_explicit_failed_id_is_accepted(self):
        r, m = self.post({"candidate_ids": [self.cands["failed"]["id"]]})
        self.assertEqual(r.status_code, 200, r.text); m.assert_called_once()

    def test_suggested_and_rejected_clips_are_still_refused(self):
        for s in ("suggested", "rejected"):
            r, m = self.post({"candidate_ids": [self.cands[s]["id"]]})
            self.assertEqual(r.status_code, 409, s); m.assert_not_called()

    def test_foreign_clip_id_is_404(self):
        r, m = self.post({"candidate_ids": ["nope"]}); self.assertEqual(r.status_code, 404); m.assert_not_called()

    def test_nothing_approved_or_failed_is_409(self):
        for c in self.cands.values(): db.update_candidate(c["id"], status="suggested")
        r, m = self.post({}); self.assertEqual(r.status_code, 409); m.assert_not_called()


if __name__ == "__main__":
    unittest.main()

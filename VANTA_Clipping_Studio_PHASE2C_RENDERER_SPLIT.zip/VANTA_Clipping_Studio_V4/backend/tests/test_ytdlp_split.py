"""Guard for the ytdlp.py split (Phase 2c): the old module surface must be unchanged and patches on ``ytdlp`` must still reach the code.

``tests/data/ytdlp_surface_snapshot.json`` was taken from the ORIGINAL single-file ytdlp.py (names, kinds, normalised signatures).
"""
from __future__ import annotations

import inspect
import json
import re
import unittest
from pathlib import Path
from unittest import mock

from app.clipstudio import settings, ytdlp, ytdlp_errors, ytdlp_probe, ytdlp_proc, ytdlp_urls

SNAP = Path(__file__).parent / "data" / "ytdlp_surface_snapshot.json"


def surface() -> dict:
    out = {}
    for name, value in sorted(vars(ytdlp).items()):
        if name.startswith("__"):
            continue
        if inspect.ismodule(value):
            out[name] = "module:" + value.__name__
        elif inspect.isclass(value):
            out[name] = "class"
        elif inspect.isfunction(value):
            out[name] = "function" + re.sub(r"0x[0-9a-f]+", "0x0", str(inspect.signature(value)))
        else:
            out[name] = "value:" + type(value).__name__
    return out


class SplitGuard(unittest.TestCase):
    def test_every_old_name_is_still_importable_with_the_same_kind_and_signature(self):
        old, new = json.loads(SNAP.read_text(encoding="utf-8")), surface()
        self.assertEqual(sorted(set(old) - set(new)), [], "names lost from ytdlp")
        self.assertEqual({k: new[k] for k in old if new[k] != old[k]}, {})

    def test_reexports_are_the_same_objects_as_in_the_submodules(self):
        pairs = [(ytdlp_errors, ["classify_error", "scrub", "split_output", "_RULES"]),
                 (ytdlp_urls, ["parse_youtube_url", "is_youtube_host", "YouTubeRef", "YOUTUBE_HOSTS"]),
                 (ytdlp_proc, ["build_command", "run_process", "_collect", "DownloadResult", "_child_env"]),
                 (ytdlp_probe, ["js_runtime_info", "ffmpeg_info", "reset_caches", "_CACHE", "_writable"])]
        for module, names in pairs:
            for name in names:
                self.assertIs(getattr(ytdlp, name), getattr(module, name), f"{name} was copied instead of re-exported")

    def test_functions_that_tests_patch_still_live_in_the_facade(self):
        for name in ("installed", "version", "base_command", "diagnostics", "download", "update", "enabled", "check_disk"):
            self.assertEqual(getattr(ytdlp, name).__module__, "app.clipstudio.ytdlp", name)

    def test_patching_installed_reaches_base_command_and_diagnostics(self):
        with mock.patch.object(ytdlp, "installed", return_value=False):
            self.assertIsNone(ytdlp.base_command())
            self.assertFalse(ytdlp.diagnostics()["yt_dlp"]["installed"])
        with mock.patch.object(ytdlp, "installed", return_value=True):
            self.assertEqual(ytdlp.base_command()[1:], ["-m", "yt_dlp"])

    def test_patching_ffmpeg_info_and_version_reaches_diagnostics(self):
        fake = {"ffmpeg": None, "ffprobe": None, "version": None, "available": False, "dir": None}
        with mock.patch.object(ytdlp, "ffmpeg_info", return_value=fake), mock.patch.object(ytdlp, "version", return_value="2026.10.21"):
            d = ytdlp.diagnostics()
        self.assertFalse(d["ffmpeg"]["available"])
        self.assertEqual(d["yt_dlp"]["version"], "2026.10.21")
        self.assertFalse(d["ready"])

    def test_patching_disk_usage_through_the_facade_reaches_check_disk(self):
        with mock.patch("app.clipstudio.ytdlp.shutil.disk_usage", return_value=mock.Mock(free=1024)):
            with self.assertRaises(ytdlp.LinkError) as ctx:
                ytdlp.check_disk(settings.SOURCE_DIR)
        self.assertEqual(ctx.exception.code, "disk_full")

    def test_reset_caches_clears_the_cache_that_the_facade_exposes(self):
        ytdlp._CACHE["x"] = (0.0, 1)
        ytdlp.reset_caches()
        self.assertEqual(ytdlp._CACHE, {})

    def test_no_module_is_oversized_and_the_facade_is_small(self):
        base = Path(ytdlp.__file__).parent
        for name in ("ytdlp", "ytdlp_const", "ytdlp_urls", "ytdlp_errors", "ytdlp_probe", "ytdlp_proc"):
            self.assertLess((base / f"{name}.py").stat().st_size, 20_000, name)

    def test_standing_rules_survive_the_split(self):
        base = Path(ytdlp.__file__).parent
        text = "".join((base / f"{n}.py").read_text(encoding="utf-8") for n in ("ytdlp", "ytdlp_probe", "ytdlp_proc", "ytdlp_errors"))
        self.assertIn('"-m", "yt_dlp"', text)                      # yt-dlp runs only as <backend python> -m yt_dlp
        self.assertNotIn('shutil.which("yt-dlp")', text)           # never from PATH
        for flag in ("--cookies", "--username", "--geo-bypass", "--age-limit"):
            self.assertNotIn(flag, ytdlp.build_command(["py"], "https://youtu.be/dQw4w9WgXcQ", Path("/tmp"), max_filesize=1))


if __name__ == "__main__":
    unittest.main()

"""Session-3 audit of YouTube ingestion: URL variants must collapse to one video id (duplicate detection) and
real-world yt-dlp error texts must map to the right user-facing class."""
import unittest

from app.clipstudio import links, ytdlp
from app.clipstudio.linkerrors import LinkError

VID = "dQw4w9WgXcQ"
CANON = f"https://www.youtube.com/watch?v={VID}"
SAME_VIDEO = [
    f"https://www.youtube.com/watch?v={VID}&list=PLabc&index=2",
    f"https://youtu.be/{VID}?t=30&si=abc",
    f"https://www.youtube.com/shorts/{VID}?feature=share",
    f"https://m.youtube.com/watch?v={VID}",
    f"HTTPS://WWW.YOUTUBE.COM/watch?v={VID}",
    f"https://www.youtube.com./watch?v={VID}",          # trailing-dot host (was classified as an unknown page)
    f"https://youtu.be./{VID}",
    f"https://youtube.com/watch/?v={VID}",
    f"https://www.youtube.com/live/{VID}",
    f"https://www.youtube.com/embed/{VID}",
    f"https://www.youtube.com/watch?v={VID}#t=10",
    f"https://music.youtube.com/watch?v={VID}",
]
REJECTED = [
    ("https://www.youtube.com/watch?v=dQw4w9WgXc", "invalid_url"),
    ("https://youtu.be/", "invalid_url"),
    ("https://www.youtube.com/playlist?list=PLabc", "unsupported_platform"),
    ("https://www.youtube.com/@somechannel", "unsupported_platform"),
    ("https://www.youtube.com/embed/videoseries?list=PLx", "unsupported_platform"),
]


class UrlVariants(unittest.TestCase):
    def test_every_variant_collapses_to_one_canonical_ref(self):
        for url in SAME_VIDEO:
            with self.subTest(url=url):
                n = links.normalise_url(url)
                self.assertEqual(links.classify(n), "youtube")
                self.assertEqual(links.canonical_ref(n), (CANON, VID))

    def test_bad_youtube_links_are_rejected_with_a_precise_code(self):
        for url, code in REJECTED:
            with self.subTest(url=url):
                with self.assertRaises(LinkError) as cm:
                    links.canonical_ref(links.normalise_url(url))
                self.assertEqual(cm.exception.code, code)

    def test_lookalike_hosts_are_not_youtube(self):
        for url in ["https://youtube.com.evil.example/watch?v=" + VID, "https://notyoutube.com/watch?v=" + VID,
                    "https://youtu.be.evil.example/" + VID]:
            with self.subTest(url=url):
                self.assertNotEqual(links.classify(links.normalise_url(url)), "youtube")


class RealErrorTexts(unittest.TestCase):
    CASES = [
        ("ERROR: [youtube] dQw4w9WgXcQ: Private video. Sign in if you've been granted access to this video", "login_required", False),
        ("ERROR: [youtube] dQw4w9WgXcQ: Video unavailable. This video has been removed by the uploader", "unavailable", False),
        ("ERROR: [youtube] dQw4w9WgXcQ: Sign in to confirm your age. This video may be inappropriate for some users.", "login_required", False),
        ("ERROR: [youtube] dQw4w9WgXcQ: The uploader has not made this video available in your country", "geo_blocked", False),
        ("ERROR: [youtube] dQw4w9WgXcQ: Sign in to confirm you're not a bot", "bot_check", True),
        ("ERROR: [youtube] dQw4w9WgXcQ: Requested format is not available. Use --list-formats for a list of available formats", "format_unavailable", True),
        ("ERROR: [youtube] dQw4w9WgXcQ: Unable to download webpage: <urlopen error [Errno -3] Temporary failure in name resolution>", "network_error", True),
        ("ERROR: [youtube] dQw4w9WgXcQ: This live event will begin in 2 hours.", "live_unavailable", True),
        ("ERROR: unable to download video data: HTTP Error 403: Forbidden", "access_denied", True),
        ("ERROR: unable to download video data: HTTP Error 429: Too Many Requests", "rate_limited", True),
    ]

    def test_classification(self):
        for text, code, retry in self.CASES:
            with self.subTest(code=code):
                err = ytdlp.classify_error(text)
                self.assertEqual((err.code, err.retryable), (code, retry), text)

    def test_warning_never_decides(self):
        err = ytdlp.classify_error("Deprecated Feature: Support for Python version 3.10 has been deprecated. Please update to Python 3.11\n"
                                   "ERROR: [youtube] dQw4w9WgXcQ: Video unavailable")
        self.assertEqual(err.code, "unavailable")


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import os
from pathlib import Path
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

import httpx
from fastapi import HTTPException

from app import main
from app.planner import build_plan
from app.schemas import ProduceJobRequest
from app.video_providers import (
    ReplicateVideoProvider,
    _provider_error,
    _safe_output_url,
    get_video_provider,
    provider_status,
)


class VideoProviderTests(unittest.TestCase):
    def test_detailed_topic_is_planned_as_story_not_replaced_by_template(self):
        topic = "An orange-and-white cat cooks an omelette at a busy street-food stall, preparing ingredients, cooking on a hot griddle, folding the omelette, and serving a customer."
        plan = build_plan(
            topic=topic,
            script=None,
            source_text=None,
            duration=15,
            style="cinematic",
            input_type="topic",
        )
        self.assertEqual(plan["planner"], "prompt_segmentation")
        self.assertEqual(plan["script"], topic)
        self.assertIn("serving a customer", " ".join(scene["narration"] for scene in plan["scenes"]))

    def test_online_provider_is_not_configured_without_backend_token(self):
        with patch.dict(os.environ, {"REPLICATE_API_TOKEN": "", "STUDIO_ONLINE_PROVIDER": "replicate"}):
            online = provider_status()["online"]
            self.assertFalse(online["configured"])
            self.assertFalse(online["paid_requests_enabled_by_default"])
            self.assertIsNone(online["estimated_cost_usd"])

    def test_missing_token_fails_before_any_provider_request(self):
        with patch.dict(os.environ, {"REPLICATE_API_TOKEN": ""}):
            provider = ReplicateVideoProvider()
            with tempfile.TemporaryDirectory() as directory:
                with patch.object(httpx.Client, "post") as post:
                    with self.assertRaisesRegex(RuntimeError, "REPLICATE_API_TOKEN"):
                        provider.generate_clip(
                            "cat cooking",
                            1,
                            Path(directory) / "clip.mp4",
                            lambda _progress, _message: None,
                            lambda: False,
                        )
                    post.assert_not_called()

    def test_online_job_requires_approval_before_provider_lookup(self):
        job = {
            "id": "job",
            "status": "draft",
            "settings": {"generation_mode": "online_ai"},
        }
        with patch.object(main, "_not_found", return_value=job), patch.object(main, "get_video_provider") as provider:
            with self.assertRaises(HTTPException) as error:
                main.produce("job", ProduceJobRequest())
        self.assertEqual(error.exception.status_code, 428)
        provider.assert_not_called()

    def test_scene_regeneration_preserves_other_generated_clips(self):
        job = {
            "id": "job",
            "status": "completed",
            "settings": {
                "generation_mode": "local_ai",
                "generated_clips": [{"index": 1}],
                "scenes": [{"id": 2}],
            },
        }
        provider = SimpleNamespace(identifier="animatediff_local", name="AnimateDiff local")
        with (
            patch.object(main, "_not_found", return_value=job),
            patch.object(main, "get_video_provider", return_value=provider),
            patch.object(main, "update_settings") as update_settings,
            patch.object(main, "_enqueue", return_value=True) as enqueue,
        ):
            result = main.regenerate_scene("job", 2, ProduceJobRequest())
        self.assertTrue(result["accepted"])
        update_settings.assert_called_once_with(
            "job",
            selected_video_provider="animatediff_local",
            online_approval_granted=False,
            regenerate_scene_id=2,
        )
        enqueue.assert_called_once_with("job", preserve_generated_clips=True)

    def test_scene_regeneration_requires_prior_successful_ai_render(self):
        job = {
            "id": "job",
            "status": "completed",
            "settings": {
                "generation_mode": "local_ai",
                "scenes": [{"id": 2}],
            },
        }
        with patch.object(main, "_not_found", return_value=job):
            with self.assertRaises(HTTPException) as error:
                main.regenerate_scene("job", 2, ProduceJobRequest())
        self.assertEqual(error.exception.status_code, 409)

    def test_online_mode_does_not_fall_back_to_motion_graphics(self):
        with patch.dict(os.environ, {"REPLICATE_API_TOKEN": ""}):
            with self.assertRaisesRegex(RuntimeError, "Online AI is not configured"):
                get_video_provider("online_ai")

    def test_provider_output_download_rejects_untrusted_hosts(self):
        self.assertEqual(
            _safe_output_url("https://replicate.delivery/output/video.mp4"),
            "https://replicate.delivery/output/video.mp4",
        )
        for url in (
            "http://replicate.delivery/video.mp4",
            "https://attacker.example/video.mp4",
            "https://replicate.delivery.attacker.example/video.mp4",
        ):
            with self.subTest(url=url), self.assertRaisesRegex(RuntimeError, "unexpected video URL"):
                _safe_output_url(url)

    def test_provider_errors_redact_credentials(self):
        token = "secret-provider-token"
        response = httpx.Response(
            400,
            json={"detail": f"invalid {token}"},
            request=httpx.Request("POST", "https://api.replicate.com/v1/predictions"),
        )
        message = str(_provider_error(response, token))
        self.assertNotIn(token, message)
        self.assertIn("[redacted]", message)


if __name__ == "__main__":
    unittest.main()

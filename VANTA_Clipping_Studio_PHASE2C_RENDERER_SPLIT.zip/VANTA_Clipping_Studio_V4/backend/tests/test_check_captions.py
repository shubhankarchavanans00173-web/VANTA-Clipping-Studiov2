"""Multi-moment caption verification, the validation-failure fix, and the check_captions.py self-check (real FFmpeg)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import check_captions
from app.clipstudio import capfx, render
from app.clipstudio.errors import CaptionError, RenderError
from app.clipstudio.media import probe
from app.clipstudio.render import RenderSettings, render_clip
from app.clipstudio.transcript import Transcript, parse_subtitles
from tests.vanta_fixtures import HAVE_FFMPEG, make_video

BACKEND = Path(__file__).resolve().parent.parent


class PickTimesTests(unittest.TestCase):
    def test_single_event_gives_one_point_and_no_events_none(self):
        self.assertEqual(capfx.pick_probe_times([(2.0, 4.0)]), [3.0])
        self.assertEqual(capfx.pick_probe_times([]), [])

    def test_few_events_are_all_sampled(self):
        self.assertEqual(capfx.pick_probe_times([(0, 2), (3, 5), (6, 8)]), [1.0, 4.0, 7.0])

    def test_many_events_sample_first_last_and_spread(self):
        ev = [(i * 3.0, i * 3.0 + 2.0) for i in range(20)]
        pts = capfx.pick_probe_times(ev)
        self.assertEqual(len(pts), capfx.MAX_PROBE_POINTS)
        self.assertEqual(pts[0], 1.0); self.assertEqual(pts[-1], 58.0)
        self.assertEqual(pts, sorted(set(pts)))

    def test_every_point_lies_inside_its_event(self):
        ev = [(1.0, 1.5), (3.0, 3.1), (5.0, 9.0), (12.0, 12.8), (20.0, 26.0), (30.0, 30.4)]
        for t in capfx.pick_probe_times(ev):
            self.assertTrue(any(a < t < b for a, b in ev), t)

    def test_very_short_events_are_skipped_when_longer_ones_exist(self):
        self.assertEqual(capfx.pick_probe_times([(0, 0.1), (5, 7)]), [6.0])
        self.assertEqual(capfx.pick_probe_times([(0, 0.1)]), [0.05])        # only short ones exist -> still checks something

    def test_summary_requires_every_point_and_reports_the_worst(self):
        ok = {"glyph_pixels": 900, "matched_pixels": 900, "match_ratio": 1.0, "visible": True, "at_seconds": 1.0}
        bad = {"glyph_pixels": 800, "matched_pixels": 100, "match_ratio": 0.125, "visible": False, "at_seconds": 6.0}
        s = capfx.summarize_points([ok, bad])
        self.assertFalse(s["visible"]); self.assertEqual(s["match_ratio"], 0.125); self.assertEqual((s["points_checked"], s["points_passed"]), (2, 1))
        self.assertTrue(capfx.summarize_points([ok, dict(ok, at_seconds=2.0)])["visible"])
        self.assertFalse(capfx.summarize_points([])["visible"])


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class RenderVerificationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.TemporaryDirectory(prefix="vanta multi "); cls.root = Path(cls.dir.name)
        cls.src = make_video(cls.root / "src.mp4", duration=20, size="1280x720"); cls.info = probe(cls.src)
        srt = "\n".join(f"{i + 1}\n00:00:{a:06.3f} --> 00:00:{a + 3.0:06.3f}\nCaption number {i + 1} is shown here.\n".replace(".", ",", 2) for i, a in enumerate((1.0, 5.0, 9.0, 13.0)))
        cls.tr = Transcript(parse_subtitles(srt), "subtitle-file")

    @classmethod
    def tearDownClass(cls):
        cls.dir.cleanup()

    def render(self, name, **kw):
        return render_clip(self.src, self.root / f"{name}.mp4", self.root / f"tmp_{name}", 0.0, 17.0, self.info, RenderSettings.from_dict({"captions": True}), self.tr, **kw)

    def test_export_is_verified_at_several_moments_across_the_clip(self):
        res = self.render("multi")
        v = res["caption_verification"]
        self.assertTrue(v["visible"]); self.assertGreaterEqual(v["points_checked"], 3)
        times = [p["at_seconds"] for p in v["points"]]
        self.assertEqual(times, sorted(times)); self.assertGreater(times[-1] - times[0], 8)       # spread over the clip, not one spot
        self.assertTrue(all(p["visible"] and p["match_ratio"] >= capfx.MIN_MATCH_RATIO for p in v["points"]))

    def test_a_failure_at_a_later_moment_fails_the_export(self):
        real = capfx.compare_frame_to_probe
        calls = []

        def flaky(frame, probe_png):
            out = real(frame, probe_png); calls.append(1)
            return dict(out, match_ratio=0.2, visible=False) if len(calls) == 3 else out        # third checked moment is "missing"
        with mock.patch.object(capfx, "compare_frame_to_probe", side_effect=flaky):
            with self.assertRaises(CaptionError) as ctx:
                self.render("flaky")
        self.assertEqual(ctx.exception.code, "captions_not_visible"); self.assertIn("1 of", str(ctx.exception))
        self.assertFalse((self.root / "flaky.mp4").exists())                                # nothing exported
        self.assertTrue((self.root / "tmp_flaky" / "FAILED_render.mp4").is_file())          # kept for diagnostics

    def test_output_validation_failure_raises_render_error_and_keeps_the_file(self):
        """Regression: the temp file used to be unlinked before being moved, so this raised FileNotFoundError."""
        bad = {"valid": False, "problems": ["size is wrong"], "probe": {}}
        with mock.patch.object(render, "validate_export", return_value=bad):
            with self.assertRaises(RenderError) as ctx:
                self.render("invalid")
        self.assertIn("size is wrong", str(ctx.exception))
        self.assertTrue((self.root / "tmp_invalid" / "FAILED_render.mp4").is_file())
        self.assertFalse((self.root / "invalid.mp4").exists())

    def test_probe_at_a_late_time_is_correct_and_fast(self):
        """The probe seeks on the input side; it must still show the caption that is on screen at that time."""
        import time
        res = self.render("late")
        work = self.root / "tmp_late"
        late = max(res["caption_verification"]["points"], key=lambda p: p["at_seconds"])
        self.assertGreater(late["at_seconds"], 10); self.assertTrue(late["visible"])
        plan = capfx.FontPlan("DejaVu Sans", "fonts")
        t0 = time.time(); capfx.probe_glyphs("ffmpeg", work, "captions.ass", plan, 1080, 1920, late["at_seconds"], name="again"); self.assertLess(time.time() - t0, 15)


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class CheckScriptTests(unittest.TestCase):
    def run_cli(self, out, env_extra=None, *args):
        env = {**os.environ, **(env_extra or {})}
        return subprocess.run([sys.executable, str(BACKEND / "check_captions.py"), "--out", str(out), *args], capture_output=True, text=True, timeout=240, env=env, cwd=str(BACKEND))

    def test_pass_exits_0_with_multiple_points_and_files(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.run_cli(Path(d) / "out")
            self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
            self.assertIn("RESULT: PASS", r.stdout)
            rep = json.loads((Path(d) / "out" / "report.json").read_text("utf-8"))
            self.assertEqual(rep["result"], "PASS"); self.assertGreaterEqual(len(rep["points"]), 3)
            self.assertTrue((Path(d) / "out" / "sample_captioned.mp4").is_file()); self.assertTrue((Path(d) / "out" / "frame_0.png").is_file())
            self.assertEqual(probe(Path(d) / "out" / "sample_captioned.mp4")["width"], 1080)

    def test_hindi_rendered_as_boxes_is_a_fail(self):
        """No system fonts at all (empty fontconfig): English still renders (bundled DejaVu) but Devanagari becomes boxes -> FAIL, exit 1."""
        with tempfile.TemporaryDirectory() as d:
            conf = Path(d) / "fonts.conf"
            conf.write_text('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig></fontconfig>')
            r = self.run_cli(Path(d) / "out", {"FONTCONFIG_FILE": str(conf), "VANTA_FONTS_DIR": str(Path(d) / "nothing")})
            self.assertEqual(r.returncode, 1, r.stdout + r.stderr)
            self.assertIn("RESULT: FAIL", r.stdout); self.assertIn("missing-glyph boxes", r.stdout)
            rep = json.loads((Path(d) / "out" / "report.json").read_text("utf-8"))
            self.assertGreaterEqual(rep["hindi"]["similarity_to_boxes"], check_captions.TOFU_SIMILARITY)
            self.assertTrue(all(p["visible"] for p in rep["points"]))        # the plain pixel check alone would have said PASS

    def test_no_hindi_flag_skips_the_shape_check(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.run_cli(Path(d) / "out", None, "--no-hindi")
            self.assertEqual(r.returncode, 0, r.stdout); self.assertNotIn("Devanagari at", r.stdout)

    def test_missing_ffmpeg_is_exit_2_not_a_traceback(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.run_cli(Path(d) / "out", {"PATH": d})                  # no ffmpeg on PATH
            self.assertEqual(r.returncode, 2, r.stdout + r.stderr); self.assertIn("NOT FOUND", r.stdout); self.assertNotIn("Traceback", r.stderr)

    def test_failed_caption_verification_exits_1(self):
        with tempfile.TemporaryDirectory() as d:
            err = CaptionError("captions were not visible", "captions_not_visible")
            with mock.patch.object(check_captions, "render_clip", side_effect=err):
                rep = check_captions.run_check(Path(d) / "o")
            self.assertEqual(rep["result"], "FAIL"); self.assertIn("not visible", rep["notes"][0])

    def test_mask_similarity_distinguishes_identical_and_different_masks(self):
        from PIL import Image, ImageDraw
        with tempfile.TemporaryDirectory() as d:
            def canvas(path, box, grey):
                for suffix, bg in (("", 128), ("_b", 0)):
                    im = Image.new("L", (200, 100), bg); ImageDraw.Draw(im).rectangle(box, fill=255) if box else None
                    im.save(Path(d) / f"{path}{suffix}.png")
            canvas("a", (10, 10, 90, 40), 0); canvas("b", (10, 10, 90, 40), 0); canvas("c", (110, 50, 190, 90), 0)
            self.assertEqual(check_captions.mask_similarity(Path(d) / "a.png", Path(d) / "b.png"), 1.0)
            self.assertEqual(check_captions.mask_similarity(Path(d) / "a.png", Path(d) / "c.png"), 0.0)


if __name__ == "__main__":
    unittest.main()

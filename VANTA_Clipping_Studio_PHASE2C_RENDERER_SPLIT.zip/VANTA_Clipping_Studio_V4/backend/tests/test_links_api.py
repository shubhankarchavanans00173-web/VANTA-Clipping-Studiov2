"""Integration tests for the link -> download -> analyze -> render -> export workflow through the real HTTP API.

The platform downloader is replaced by a stub *process* (so the real runner, staging, validation, job queue and routes are all
exercised); only the network is simulated. No real YouTube request is made here - see docs/YOUTUBE_SETUP.md for the live check.
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import textwrap
import time
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest import mock

from fastapi.testclient import TestClient

from app.clipstudio import db, pipeline, settings, ytdlp
from tests.test_ytdlp import PY310_WARNING, VID
from tests.vanta_fixtures import HAVE_FFMPEG, isolate, make_video

API = "/api/vanta"
_COUNTER = iter(range(1, 10_000))


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class LinkWorkflowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}); cls._env.start()
        for k in ("VANTA_CLOUD_AI_ENABLED", "ANTHROPIC_API_KEY"):
            os.environ.pop(k, None)
        cls.tmp = isolate()
        cls.work = Path(tempfile.mkdtemp(prefix="linkapi-"))
        cls.source_video = make_video(cls.work / "remote.mp4", duration=70)
        cls.mode_file, cls.calls_file = cls.work / "mode", cls.work / "calls"
        stub = cls.work / "stub_ytdlp.py"
        stub.write_text(textwrap.dedent(f"""
            import shutil, sys, time
            from pathlib import Path
            args = sys.argv[1:]; out = args[args.index('-o') + 1]
            open({str(cls.calls_file)!r}, 'a').write('x\\n')
            open({str(cls.work / 'last_url')!r}, 'w').write(args[-1])
            mode = Path({str(cls.mode_file)!r}).read_text().strip()
            if mode == 'unavailable':
                sys.stderr.write({PY310_WARNING!r} + '\\n')
                sys.stderr.write('ERROR: [youtube] {VID}: Video unavailable. This video is unavailable\\n'); sys.exit(1)
            if mode == 'network':
                sys.stderr.write('ERROR: [youtube] x: Unable to download API page: Failed to resolve (Name or service not known)\\n'); sys.exit(1)
            if mode == 'slow':
                print('[download] Destination: x', flush=True)
                time.sleep(25)
            dest = out.replace('%(ext)s', 'mp4')
            shutil.copy({str(cls.source_video)!r}, dest)
            print(dest); print('VANTA_TITLE=Public domain test talk')
        """), encoding="utf-8")
        cls.patch_cmd = mock.patch.object(ytdlp, "base_command", return_value=[sys.executable, str(stub)]); cls.patch_cmd.start()
        ytdlp.reset_caches()
        from app.main import app
        cls.client = TestClient(app).__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None)
        cls.patch_cmd.stop(); cls.tmp.cleanup(); cls._env.stop()

    def setUp(self):
        self.set_mode("ok"); self.calls_file.write_text("")
        self.vid = f"T{next(_COUNTER):010d}"             # every test gets its own video id (duplicates are detected by design)

    def tearDown(self):
        for j in db.list_jobs(100):                       # never leave a job holding the single worker
            if j["status"] in db.ACTIVE:
                try:
                    pipeline.cancel_job(j["id"])
                except Exception:
                    pass
        self._wait_idle()

    # ---- helpers
    def set_mode(self, mode: str):
        self.mode_file.write_text(mode)

    def calls(self) -> int:
        return len(self.calls_file.read_text().split())

    def _wait_idle(self, timeout=40):
        end = time.time() + timeout
        while time.time() < end and any(j["status"] in db.ACTIVE for j in db.list_jobs(100)):
            time.sleep(0.2)

    def add(self, url=None, **kw):
        url = url or f"https://www.youtube.com/watch?v={self.vid}"
        return self.client.post(f"{API}/projects/link", json={"url": url, "rights_confirmed": True, **kw})

    def wait(self, jid, until, timeout=120):
        end = time.time() + timeout
        while time.time() < end:
            j = self.client.get(f"{API}/jobs/{jid}").json()
            if j["status"] in until:
                return j
            time.sleep(0.25)
        self.fail(f"job {jid} never reached {until}: {j}")

    def project(self, pid):
        return self.client.get(f"{API}/projects/{pid}").json()

    # ---- tests
    def test_01_successful_download_registers_a_valid_source(self):
        r = self.add(); self.assertEqual(r.status_code, 200, r.text)
        body = r.json(); self.assertFalse(body["duplicate"]); self.assertEqual(body["job"]["kind"], "download")
        job = self.wait(body["job"]["id"], {"completed", "failed"})
        self.assertEqual(job["status"], "completed", job); self.assertEqual(job["result"]["how"], "downloaded")
        p = self.project(body["id"])
        self.assertTrue(p["has_source"]); self.assertEqual(p["name"], "Public domain test talk"); self.assertIsNone(p["error"]); self.assertIsNone(p["download_error"])
        self.assertEqual(p["source_ref"], f"https://www.youtube.com/watch?v={self.vid}")
        row = db.get_project(body["id"]); path = Path(row["source_path"])
        self.assertTrue(path.is_file() and path.stat().st_size > 0 and settings.is_inside(path, settings.SOURCE_DIR))
        self.assertEqual(row["probe"]["duration"], 70.0)
        self.assertEqual(self.client.get(f"{API}/projects/{body['id']}/source").status_code, 200)    # playable through the app
        self.assertEqual([x.name for x in path.parent.iterdir() if x.name.startswith(".dl-")], [])
        self.assertEqual(self.calls(), 1)

    def test_02_the_downloader_receives_the_canonical_url(self):
        pid = self.add(url=f"https://youtu.be/{self.vid}?si=junk&t=30").json()
        self.wait(pid["job"]["id"], {"completed"})
        self.assertEqual((self.work / "last_url").read_text(), f"https://www.youtube.com/watch?v={self.vid}")

    def test_03_failed_download_gives_a_precise_actionable_error_not_outdated(self):
        self.set_mode("unavailable")
        body = self.add(url=f"https://www.youtube.com/shorts/{self.vid}").json()
        job = self.wait(body["job"]["id"], {"failed"})
        self.assertEqual(job["result"]["error"]["code"], "unavailable")
        self.assertNotIn("outdated", job["error"].lower()); self.assertNotIn("update yt-dlp", job["error"].lower())
        p = self.project(body["id"])
        self.assertEqual(p["status"], "failed"); self.assertFalse(p["has_source"])
        self.assertEqual(p["download_error"]["code"], "unavailable"); self.assertFalse(p["download_error"]["retryable"])
        self.assertTrue(p["download_error"]["hint"]); self.assertTrue(p["download_error"]["details"])
        self.assertEqual([x for x in (settings.SOURCE_DIR / body["id"]).glob("*")], [])               # nothing registered, nothing left over

    def test_04_retry_after_failure_succeeds_and_clears_the_stale_error(self):
        self.set_mode("network")
        body = self.add().json()
        job = self.wait(body["job"]["id"], {"failed"})
        self.assertEqual(job["result"]["error"]["code"], "network_error"); self.assertTrue(job["result"]["error"]["retryable"])
        self.assertEqual(self.calls(), 2)                                                                 # bounded automatic retries (VANTA_YTDLP_ATTEMPTS=2)
        self.assertEqual(self.project(body["id"])["download_error"]["code"], "network_error")
        self.set_mode("ok")
        r = self.client.post(f"{API}/projects/{body['id']}/download"); self.assertEqual(r.status_code, 200, r.text)
        self.assertFalse(r.json()["already_downloaded"])
        self.wait(r.json()["job"]["id"], {"completed"})
        p = self.project(body["id"])
        self.assertTrue(p["has_source"]); self.assertIsNone(p["error"]); self.assertIsNone(p["download_error"]); self.assertEqual(p["status"], "new")

    def test_05_valid_local_copy_is_never_downloaded_again(self):
        body = self.add().json(); self.wait(body["job"]["id"], {"completed"})
        before = self.calls()
        r = self.client.post(f"{API}/projects/{body['id']}/download"); self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()["already_downloaded"]); self.assertIsNone(r.json()["job"])
        self.assertEqual(self.calls(), before)
        self.assertEqual(self.client.post(f"{API}/projects/{body['id']}/analyze", json={"transcribe": False, "target_duration": 15, "count": 3}).status_code, 200)
        self.wait(self.client.get(f"{API}/jobs").json()[0]["id"], {"awaiting_approval", "failed"})
        self.assertEqual(self.calls(), before, "analysis must reuse the downloaded file")

    def test_06_duplicate_submissions_reuse_the_project(self):
        first = self.add().json(); self.wait(first["job"]["id"], {"completed"})
        for url in (f"https://youtu.be/{self.vid}", f"https://www.youtube.com/embed/{self.vid}", f"https://www.youtube.com/watch?v={self.vid}&list=PLx&index=4"):
            again = self.add(url=url).json()
            self.assertTrue(again["duplicate"], url); self.assertEqual(again["id"], first["id"]); self.assertIsNone(again["job"])
        self.assertEqual(sum(1 for p in db.list_projects() if p["source_ref"] == first["source_ref"]), 1)
        self.assertEqual(self.calls(), 1)

    def test_07_double_click_cannot_start_two_downloads(self):
        self.set_mode("slow")
        pid = self.add(start_download=False).json()["id"]
        with ThreadPoolExecutor(2) as pool:
            codes = sorted(f.result().status_code for f in [pool.submit(lambda: self.client.post(f"{API}/projects/{pid}/download")) for _ in range(2)])
        self.assertEqual(codes, [200, 409])
        self.assertEqual(self.client.post(f"{API}/projects/{pid}/analyze", json={}).status_code, 409)     # analyze is refused while downloading
        self.assertEqual(sum(1 for j in db.list_jobs(50, pid) if j["kind"] == "download"), 1)

    def test_08_cancel_stops_the_download_and_cleans_up(self):
        self.set_mode("slow")
        body = self.add().json(); jid = body["job"]["id"]
        end = time.time() + 30
        while time.time() < end and self.client.get(f"{API}/jobs/{jid}").json()["status"] != "downloading":
            time.sleep(0.1)
        self.assertEqual(self.client.post(f"{API}/jobs/{jid}/cancel").status_code, 200)
        t0 = time.time(); job = self.wait(jid, {"cancelled"}, timeout=30)
        self.assertLess(time.time() - t0, 20)
        p = self.project(body["id"])
        self.assertEqual(p["status"], "new"); self.assertFalse(p["has_source"]); self.assertIsNone(p["download_error"])
        self.assertEqual(list((settings.SOURCE_DIR / body["id"]).glob(".dl-*")), [])

    def test_09_download_then_analyze_then_render_then_export_is_a_real_mp4(self):
        body = self.add().json(); self.wait(body["job"]["id"], {"completed"})
        pid = body["id"]
        r = self.client.post(f"{API}/projects/{pid}/analyze", json={"transcribe": False, "target_duration": 15, "count": 3}); self.assertEqual(r.status_code, 200)
        self.wait(r.json()["id"], {"awaiting_approval"})
        cands = self.project(pid)["candidates"]; self.assertGreaterEqual(len(cands), 1)
        c = cands[0]; self.assertTrue(c["reasons"]); self.assertLess(c["start"], c["end"])
        self.assertEqual(self.client.patch(f"{API}/candidates/{c['id']}", json={"status": "approved"}).status_code, 200)
        r = self.client.post(f"{API}/projects/{pid}/render", json={"candidate_ids": [c["id"]], "settings": {"aspect": "9:16", "captions": False}}); self.assertEqual(r.status_code, 200, r.text)
        job = self.wait(r.json()["id"], {"completed", "failed"}, timeout=240); self.assertEqual(job["status"], "completed", job)
        exp = self.project(pid)["exports"]; self.assertEqual(len(exp), 1)
        out = Path(exp[0]["path"]); self.assertTrue(out.is_file() and out.stat().st_size > 1000 and settings.is_inside(out, settings.EXPORT_DIR))
        probe = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,codec_name", "-of", "csv=p=0", str(out)],
                               capture_output=True, text=True, check=True).stdout.strip()
        self.assertEqual(probe, "h264,1080,1920")
        dl = self.client.get(f"{API}/exports/{exp[0]['id']}/download"); self.assertEqual(dl.status_code, 200)
        self.assertEqual(dl.content[4:8], b"ftyp"); self.assertEqual(len(dl.content), out.stat().st_size)

    def test_10_analysis_failure_after_download_is_labelled_and_keeps_the_video(self):
        body = self.add().json(); self.wait(body["job"]["id"], {"completed"})
        pid = body["id"]
        with mock.patch.object(pipeline.analysis, "suggest_clips", side_effect=RuntimeError("scoring exploded")), \
                mock.patch("app.clipstudio.selection.engine.rank", side_effect=RuntimeError("engine exploded")):   # both rankers fail
            r = self.client.post(f"{API}/projects/{pid}/analyze", json={"transcribe": False}); job = self.wait(r.json()["id"], {"failed"})
        self.assertIn("saved on disk", job["error"]); self.assertIn("analysis failed", job["error"])
        self.assertTrue(self.project(pid)["has_source"]); self.assertEqual(self.calls(), 1)
        r = self.client.post(f"{API}/projects/{pid}/analyze", json={"transcribe": False, "target_duration": 15, "count": 3}); self.wait(r.json()["id"], {"awaiting_approval"})
        self.assertEqual(self.calls(), 1, "re-analysis must not download again")

    def test_11_analyze_downloads_when_no_copy_exists_and_reuses_an_orphaned_file(self):
        pid = self.add(start_download=False).json()["id"]
        r = self.client.post(f"{API}/projects/{pid}/analyze", json={"transcribe": False, "target_duration": 15, "count": 3}); self.wait(r.json()["id"], {"awaiting_approval"})
        self.assertEqual(self.calls(), 1); self.assertTrue(self.project(pid)["has_source"])
        # simulate a crash between download and registration: file on disk, project has no source_path
        pid2 = self.add(url=f"https://www.youtube.com/watch?v=O{self.vid[1:]}", start_download=False).json()["id"]
        folder = settings.SOURCE_DIR / pid2; folder.mkdir(parents=True, exist_ok=True)
        (folder / "source.mp4").write_bytes(self.source_video.read_bytes())
        j = self.client.post(f"{API}/projects/{pid2}/download").json()["job"]; done = self.wait(j["id"], {"completed"})
        self.assertEqual(done["result"]["how"], "reused"); self.assertEqual(self.calls(), 1)

    def test_12_invalid_links_are_rejected_with_codes(self):
        cases = {"https://www.youtube.com/playlist?list=PL1": "unsupported_platform", "https://www.youtube.com/watch?v=short": "invalid_url",
                 "https://www.youtube.com/@channel": "unsupported_platform", "file:///etc/passwd": "invalid_url", "https://www.netflix.com/title/1": "unsupported_platform"}
        for url, code in cases.items():
            r = self.add(url=url); self.assertEqual(r.status_code, 400, url); self.assertEqual(r.json()["detail"]["code"], code, url)
            self.assertIn("hint", r.json()["detail"])
        self.assertEqual(self.client.post(f"{API}/projects/link", json={"url": f"https://youtu.be/{self.vid}"}).status_code, 428)      # rights not confirmed
        self.assertEqual(self.calls(), 0)

    def test_13_uploaded_projects_have_nothing_to_download(self):
        r = self.client.post(f"{API}/projects/upload", files={"file": ("a.mp4", self.source_video.read_bytes(), "video/mp4")}); self.assertEqual(r.status_code, 200)
        self.assertEqual(self.client.post(f"{API}/projects/{r.json()['id']}/download").status_code, 409)

    def test_14_interrupted_download_job_is_failed_on_restart_and_staging_is_removed(self):
        pid = self.add(start_download=False).json()["id"]
        job = db.create_job(pid, "download", {}); db.transition(job["id"], "downloading", message="x")
        leftover = settings.SOURCE_DIR / pid / ".dl-deadbeef"; leftover.mkdir(parents=True); (leftover / "x.part").write_bytes(b"partial")
        self.assertGreaterEqual(db.fail_interrupted(), 1); self.assertEqual(db.get_job(job["id"])["status"], "failed")
        self.assertGreaterEqual(pipeline.cleanup_download_staging(), 1); self.assertFalse(leftover.exists())


@unittest.skipUnless(HAVE_FFMPEG, "ffmpeg/ffprobe not installed")
class DiagnosticsAndUpdateApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._env = mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "1"}); cls._env.start()
        cls.tmp = isolate()
        from app.main import app
        cls.client = TestClient(app).__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.client.__exit__(None, None, None); cls.tmp.cleanup(); cls._env.stop()

    def test_health_and_diagnostics(self):
        h = self.client.get(f"{API}/health").json()
        self.assertEqual(h["version"], "4.0.0"); self.assertIn("version", h["yt_dlp"]); self.assertTrue(h["yt_dlp"]["enabled"])
        d = self.client.get(f"{API}/diagnostics?refresh=true").json()
        self.assertEqual(d["python"]["executable"], sys.executable); self.assertEqual(d["yt_dlp"]["version"], ytdlp.version())
        for key in ("ffmpeg", "js_runtime", "problems", "warnings", "ready", "env_file", "app", "transcription_engines"):
            self.assertIn(key, d)

    def test_update_endpoint_maps_results_and_errors(self):
        ok = {"ok": True, "executable": sys.executable, "version": "2026.11.1", "previous_version": "2026.10.21", "changed": True, "message": "updated"}
        with mock.patch.object(ytdlp, "update", return_value=ok):
            r = self.client.post(f"{API}/links/update-ytdlp"); self.assertEqual(r.status_code, 200); self.assertEqual(r.json()["executable"], sys.executable)
        with mock.patch.object(ytdlp, "update", side_effect=ytdlp.UpdateError(502, "pip could not resolve yt-dlp[default]; nothing was changed.")):
            r = self.client.post(f"{API}/links/update-ytdlp"); self.assertEqual(r.status_code, 502)
            self.assertIn("nothing was changed", r.json()["detail"]["message"]); self.assertEqual(r.json()["detail"]["code"], "update_failed")

    def test_update_is_refused_while_a_download_is_running(self):
        pid = db.create_project("x", "link", f"https://www.youtube.com/watch?v={VID}", None, None, {})["id"]
        job = db.create_job(pid, "download", {}); db.transition(job["id"], "downloading")
        with mock.patch.object(ytdlp, "update", side_effect=AssertionError("must not run")):
            r = self.client.post(f"{API}/links/update-ytdlp")
        self.assertEqual(r.status_code, 409); self.assertEqual(r.json()["detail"]["code"], "busy")
        db.transition(job["id"], "failed", error="test")

    def test_platform_links_refused_with_actionable_message_when_disabled(self):
        with mock.patch.dict(os.environ, {"VANTA_ENABLE_YTDLP": "0"}):
            r = self.client.post(f"{API}/projects/link", json={"url": f"https://youtu.be/{VID}", "rights_confirmed": True})
        self.assertEqual(r.status_code, 400); self.assertEqual(r.json()["detail"]["code"], "adapter_disabled"); self.assertIn("upload", r.json()["detail"]["message"].lower())


if __name__ == "__main__":
    unittest.main()

import os

import uvicorn


if __name__=="__main__":
    # Reload is opt-in because the Windows reloader adds a second process and
    # can fail in restricted shells. Set STUDIO_RELOAD=1 during development.
    uvicorn.run("app.main:app",host="127.0.0.1",port=int(os.getenv("STUDIO_PORT","8000")),reload=os.getenv("STUDIO_RELOAD")=="1")

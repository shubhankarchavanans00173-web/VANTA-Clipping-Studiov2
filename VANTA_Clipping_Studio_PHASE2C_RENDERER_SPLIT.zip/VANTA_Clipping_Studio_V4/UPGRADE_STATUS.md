# VANTA Clipping Studio - Upgrade Status

## Session 6 progress (2026-11-03)

| Step | Status |
|---|---|
| Phase 1 `verify_all.bat` | Done, Linux-verified; the `.bat` itself NOT run on Windows. User still owes `verify_report.txt`. |
| Phase 2a resumable render/download jobs | Done, Linux-verified; real Windows restart NOT verified. |
| Phase 2b settings API | Done, Linux-verified. |
| Phase 2b-UI settings form (`SettingsFields.tsx`) | Done: tsc, build, 32-check headless-browser click-through, 3 UI mutations caught. Windows restart check NOT verified. |
| Phase 2c step 1: `router.py` split into `clipstudio/routes/*.py` | Done, Linux-verified (see below). |
| Phase 2c step 2: `ytdlp.py` split into 5 leaf modules + facade | Done, Linux-verified (see below). |
| Phase 2c step 3: legacy `renderer.py` split into 6 leaf modules + facade | Done, Linux-verified (see below). |
| NEXT | 2c remaining splits, one file per step: `CreateView.tsx`, `legacy/page.tsx`; then 2d queue "continued automatically" link; then Phase 3. |

## Final2 current status (2026-10-30)

| Mission item | Status |
|---|---|
| TODO 7 local scheduler | Implemented and focused-test verified. Disabled by default; persistent queue, timezone, per-run limit, retry, pause/resume, restart reconciliation, lock and log are present. |
| TODO 8 VANTA YouTube upload | Implemented with mocks. Official backend-only OAuth, review panel, fresh confirmation, Private default, resumable API helper, error handling and success-only ID recording are present. Live OAuth/upload is unverified. |
| TODO 9 Windows setup | Launcher and static Windows audit complete; scripts detect prerequisites and propagate failure. Task registration is supplied but not executed. |
| TODO 10 evaluation | Export-pool and human dataset evaluator are present and documented. No human-labelled results are bundled; no quality improvement is claimed. |
| TODO 11 documentation | Updated for Final2, including configuration and feature status. |
| TODO 12 end-to-end | Automated synthetic-media coverage exercises the local flow. Real authorised media/browser/Windows checks remain manual. |
| TODO 13 release | Final ZIP is built only after suite, build, manifest and clean-extraction verification. |

See docs/FINAL_TEST_REPORT.md for the verified/partial/unverified boundary.

_Last updated: 2026-10-23 (session in progress)_

## 1. Audit of the existing project (Phase A)
Source archive: `Universal_AI_Shorts_Studio_V3.zip` (root folder inside is named `Universal_AI_Shorts_Studio_V2`).
The original archive/folder is untouched; all work happens in a copy (`VANTA_Clipping_Studio/`).

| Item | Finding |
|---|---|
| Backend | FastAPI (`backend/app/main.py`, run via `backend/run.py`, port 8000), SQLite `data/jobs.db` via `store.py` |
| Frontend | Next.js 14 / React 18 single page (`frontend/app/page.tsx`, ~210 dense lines + `globals.css`) |
| What it was | A **text-to-video generator** (topic/script -> stock footage + TTS + captions) with a thin "Video-to-Clips" mode |
| Existing FFmpeg | Used throughout `renderer.py` / `pro_render.py` (subprocess arg lists, good) |
| Existing clipping | `_render_video_clips`: picks evenly-spaced windows via scene-change score; **no transcript, no ranking explanation, no user trimming, no approval step** |
| Existing URL fetch | `_download_authorized_video`: direct HTTPS media only, SSRF checks, no redirects |
| Transcription | None for source video (roadmap item 3) |
| AI integrations | Ollama / Anthropic script writer (`llm.py`), Replicate (paid) provider, YouTube OAuth upload - all optional |
| Tests | 44 unittest tests in `backend/tests` |
| Baseline result | `python -m unittest discover -s backend/tests` -> **44 tests OK** (this sandbox, Python 3.13) |
| Env | `.env.example`, Windows `.bat` launchers |

### Known issues in the original (not all fixed)
- Clip mode has no review/approval step and cannot trim.
- `/api/youtube/analyze` only validates the host; downloads nothing (honest, kept).
- Legacy page mixes ten workflows in one screen.

## 2. Plan / architecture
New package `backend/app/clipstudio/` mounted in the existing FastAPI app under `/api/vanta/*`; the legacy
text-to-video studio is preserved (frontend moved to `/legacy`). Reuses `captions.py` (ASS writer),
`config.py`, `store.py` DB file, existing FFmpeg conventions.

Modules: `media` (ffprobe), `timeutil`, `transcript` (SRT/VTT/JSON parse + pluggable engines), `analysis`
(candidate ranking), `captions` (trim-aware caption build), `render` (FFmpeg + ffprobe validation),
`links` (URL validation/SSRF + optional adapters), `cost` (paid AI gate), `db` (projects/jobs/candidates/exports),
`pipeline` (job state machine), `router`.

## 3. Progress
See sections below, updated as work lands.


## 3. Final state (this session)

### Completed
- [x] Backend clipping engine `backend/app/clipstudio/` mounted under `/api/vanta` (see CHANGELOG_UPGRADE.md).
- [x] New 8-section UI; legacy studio preserved at `/legacy`.
- [x] Docs: README, `.env.example`, CHANGELOG_UPGRADE, CONTINUATION_PROMPT.

### Verified (exact commands and results, Linux sandbox, Python 3.13, Node 22, FFmpeg 6.1.1)
| Check | Command | Result |
|---|---|---|
| Baseline before changes | `PYTHONPATH=backend python -m unittest discover -s backend/tests` | PASS - 44 tests |
| VANTA unit tests | `python -m unittest tests.test_vanta_unit` (from `backend/`, `-W error::ResourceWarning`) | PASS - 58 tests |
| VANTA end-to-end (HTTP API, synthetic video) | `python -m unittest tests.test_vanta_e2e` | PASS - 12 tests |
| Full suite after changes | `PYTHONPATH=backend python -m unittest discover -s backend/tests` | PASS - 114 tests |
| Frontend typecheck + build | `npx tsc --noEmit`; `npm run build` | PASS (routes `/`, `/legacy`) |
| Browser flow (Playwright/Chromium against real servers) | upload -> attach transcript -> analyze -> preview -> approve -> render -> export card; visited all 8 sections | PASS, 0 console errors |
| Rendered frames inspected by eye | 9:16 blur background, word highlight, caption box | PASS |

Covered by automated tests: timestamp parsing/validation, clip duration limits, overlap handling, media inspection, invalid uploads, missing transcripts, caption timing after trim and after silence removal, render failure handling, output existence + ffprobe validation, job state transitions, paid API disabled by default, cost confirmation requirements, SSRF/URL validation, path traversal helper.

### NOT verified / skipped (be aware)
- **In-browser video playback**: headless Chromium here has no H.264 decoder, so the preview/export `<video>` panes were blank in screenshots. Files themselves were verified with ffprobe and extracted frames.
- **faster-whisper** transcription: adapter written, not installed or run (needs model download).
- **yt-dlp platform downloads**: tested only with a stub executable; never against a real site.
- **Cloud AI adapter**: tested only with a mock transport; never called the live API (no paid calls were made).
- **Windows batch launchers**: unchanged from the original, not run here (Linux sandbox).
- Subject tracking: not implemented (no detector).

## Remaining work / ideas
- [ ] Try faster-whisper on a real machine and confirm word-synced captions on real speech.
- [ ] Verify yt-dlp path against a real public video on the user's machine.
- [ ] Thumbnails and AI-written titles/descriptions/hashtags (optional features, not started).
- [ ] Batch export presets; scheduling; YouTube upload from VANTA (legacy studio already has OAuth upload code).
- [ ] Subject-aware reframing (face/person detector) as an optional adapter.
- [ ] Resume interrupted jobs instead of marking them failed.

## Known bugs / caveats
- None open from testing. Silence removal is limited to 60 cuts per clip (clear error otherwise).


## V2 YouTube link enablement update (2026-10-25)

### Changes made
- Added Windows helper `enable_youtube_links.bat` to install `yt-dlp` into the same Python environment used by VANTA and set `VANTA_ENABLE_YTDLP=1` in `.env`. Existing `.env` settings are preserved.
- Added classification for `youtube-nocookie.com` and `www.youtube-nocookie.com` embed URLs.
- Updated README with setup and use steps.
- Added unit cases for YouTube Shorts and no-cookie embed URL classification.

### Verification status
- Source ZIP was extracted into a separate working copy; original V1 archive was not modified.
- No paid API calls were made.
- Live public YouTube download is not claimed as verified; this environment may not have platform network access and a real download was not attempted. Run `enable_youtube_links.bat`, restart VANTA, and test a video you own or are authorized to repurpose.

### Checks run for this packaged update
- `PYTHONPATH=backend python -m unittest tests.test_vanta_unit -v` (run from `backend/` with `PYTHONPATH=.`): **PASS — 58 tests**.
- `python -m compileall -q backend`: **PASS**.
- Full `python -m unittest discover -s backend/tests`: **TIMED OUT in this execution environment** after partial output; do not treat as a pass.
- Frontend production build: **SKIPPED** because `frontend/node_modules` is not present; no dependency installation was attempted.
- Real public YouTube download: **NOT RUN**; requires network access and a specific authorized public video. Existing yt-dlp adapter was covered by its local stub test only.

## V2.1 Auto Clip update (2026-10-25)
- Implemented an Auto Clip UI action that runs analysis and then queues rendering of the ranked candidates automatically.
- Backend analyze request now accepts `auto_render` and `render_settings`; automatic candidates are marked approved and submitted to the render worker after analysis completes.
- Existing manual review/render flow remains unchanged.
- Focused unit tests: 58 passed in 2.765 seconds before this update; Python compileall passed after this update.
- Full test discovery was attempted again but timed out in this environment; it is not reported as passing.
- Frontend production build remains unverified because `frontend/node_modules` is not installed. Live YouTube download and full Auto Clip render still need testing on Windows with an authorized video.


## V2.2 — YouTube-link diagnostics and updater (item 1, 2026-10-25)

### Changes made
- `links.py` now finds `yt-dlp` through PATH, the active interpreter's Scripts directory, or `python -m yt_dlp`; platform downloads use the active Python module when no executable is on PATH. This addresses the Windows case where `yt-dlp` is installed but VANTA reports it missing.
- `yt-dlp` failures now return clearer machine-readable categories and actionable user messages for bot checks, login/age gates, region blocks, outdated `yt-dlp`, network/DNS/TLS failures, and existing unsupported/unavailable/rate-limit cases. Restrictions are not bypassed.
- Added `POST /api/vanta/links/update-ytdlp` to upgrade the package in the currently running backend's Python environment, with timeout/error handling and post-update version verification.
- `GET /api/vanta/health` reports `yt_dlp.installed` and `yt_dlp.version`; Video Links displays the version and an **Update yt-dlp** button.
- Added unit tests for error categories and a mocked updater endpoint. No paid AI calls added.

### Verification
- Before changes: `cd backend && PYTHONPATH=. python -m unittest discover -s tests` **PASS — 114 tests in 50.066s**.
- After changes: `PYTHONPATH=. python -m unittest tests.test_vanta_unit` **PASS — 59 tests**; `PYTHONPATH=. python -m unittest tests.test_core tests.test_pro tests.test_video_providers` **PASS — 44 tests**; `PYTHONPATH=. python -m unittest tests.test_vanta_e2e` **PASS — 12 tests**. These split groups total 115 tests; full discovery was attempted after changes but timed out, so it is not claimed as a pass.
- Python `py_compile` on the changed backend files **PASS**.
- Frontend `npm install --no-audit --no-fund` timed out in the build environment. `npx tsc --noEmit` failed because the interrupted/partial install lacked `@types/node`, React and related type definitions. `npm run build` **NOT RUN**. Frontend/browser behavior remains unverified.
- Real YouTube download: **NOT RUN**. Live package update: **NOT RUN**. The update endpoint is tested with a stubbed subprocess only. Windows `.bat` launchers were not run in this Linux build environment.

### Remaining in the requested sequence
- [ ] Item 2: automatic analyze → render end-to-end test and explicit UI error when render cannot start.
- [ ] Item 3: robust faster-whisper model configuration/download progress and transcribe-only action.
- [ ] Item 4: frontend typecheck/build and Playwright click-through of all sections.
- [ ] Item 5: editable per-clip metadata and ZIP metadata file.
- [ ] Item 6: resumable renders and durable job-state recovery.
- Later ideas remain unstarted and require asking before implementation.


## V3.0 — Reliable video-link downloads (2026-10-27)

### Root cause of the original UI error (conclusively reproduced)
`links.classify_ytdlp_error` matched regexes against the **entire** yt-dlp stderr, warnings included. On Python 3.10 yt-dlp prints
`Deprecated Feature: Support for Python version 3.10 has been deprecated. Please update to Python 3.11 or above`; the pattern `please update`
matched that, so *any* failure (e.g. `Video unavailable`, `live stream recording is not available`) was reported as "yt-dlp may be outdated".
Reproduced before the fix (`unavailable + py3.10 warning -> yt_dlp_outdated`); a regression test now pins the correct result. The Python 3.10 warning is
therefore not the cause of failed downloads — it was the cause of the *misleading label*. Whether *your* specific videos are unavailable or
failing in extraction (missing Node/JS runtime, old yt-dlp) can now be read from the precise code + Diagnostics. Contributing issues also fixed: PATH-vs-`sys.executable`
mismatch, no JS runtime passed to yt-dlp, `.env` parsing (inline comments / UTF-16), download only inside Analyze (no retry), non-atomic job submission.

### Verified (Linux sandbox: Python 3.12.3, Node 22.22.2, FFmpeg 6.1.1, yt-dlp 2026.10.21)
| Check | Command | Result |
|---|---|---|
| Baseline before changes | `unittest discover -s tests` | 115 passed |
| Full backend suite after changes | `cd backend && PYTHONPATH=. python -m unittest discover -s tests -t .` | **182 tests, OK, 0 failed, 0 skipped, 0 errors** (130 s) |
| New adapter tests | `tests/test_ytdlp.py` | 51 passed (URL parsing, classification incl. regression, command building, real subprocess runner: progress/timeout/cancel/retry/bounds/cleanup/no-file/oversize, validation, updater, `.env`) |
| New route integration tests | `tests/test_links_api.py` | 18 passed (download→source record, canonical URL, failure→actionable error, retry clears stale error, no re-download, duplicates, double-click atomicity, cancel+cleanup, analyze, **render→real 1080×1920 H.264 MP4→download**, analysis-failure labelling, orphan reuse, invalid links, restart cleanup, diagnostics, updater errors) |
| Frontend type-check | `cd frontend && npx tsc --noEmit` | passed |
| Frontend production build | `npm run build` | **passed** |
| Real servers | backend (`run.py`) + `next start`; `/health`, `/` | both HTTP 200 |
| Live HTTP workflow | upload → attach SRT → analyze → edit/approve (invalid range rejected 400) → custom clip → render 9:16, 1:1, 16:9 with captions → download → Auto Clip | all passed; ffprobe: h264+aac at 1080×1920, 1080×1080, 1920×1080; download bytes == file, `ftyp` header |
| Real yt-dlp via real backend | link `youtu.be/jNQXAC9IVRw` | job `failed` with `network_error` (DNS: sandbox cannot resolve youtube.com), retryable, scrubbed details — **not** "outdated" |

### NOT verified (be aware)
* **Real YouTube download: NOT verified.** The sandbox has no DNS/route to youtube.com, so no media was fetched. Manual check: `diagnose_youtube.bat https://www.youtube.com/watch?v=jNQXAC9IVRw` (exit 0 = real download validated).
* **Live `pip` upgrade of yt-dlp**: only tested with a stubbed pip (arguments, dry-run-first, failure handling, version verification). Manual check: Video Links → Update yt-dlp.
* **Browser click-through of the UI**: no browser binary available. The UI compiles, builds and every route it uses was exercised over HTTP.
* **Windows**: `.bat` scripts, `taskkill` process-tree kill, `C:\ai-video-env`, GTX 1650 — not executable here. Process-tree kill is tested on POSIX (`killpg`).
* `faster-whisper` transcription and GPU/CPU fallback were not exercised (not installed); the code path falls back to attached transcripts / audio-visual signals as before.
* Python 3.11 not run; 3.12 passes. Python 3.10 not run in V3 (only simulated through the exact deprecation text).

### Dependency / Python compatibility finding
All backend requirements support Python 3.11 and 3.12 and the suite passes on 3.12. Migration is optional (not needed to fix the error). `migrate_python_env.bat` builds `C:\ai-video-env-py312` side by side, runs the tests, switches nothing; switch with `python_env.txt`.

### Controls audited (backend route + UI wiring)
Create Shorts, Upload video, Attach transcript, Use a video link, Video Links, Update yt-dlp, Retry download (new), Diagnostics (new), Analyze, Auto Clip, suggested-clip approve/reject/edit (timestamp validation), custom clip, duration/count, aspect ratios, captions, Processing Queue (incl. cancel), My Projects, Exports/download, Settings (+diagnostics). Route behaviour verified over HTTP/tests; visual state transitions not browser-verified.

### Remaining / ideas
Item list in `CONTINUATION_PROMPT.md`. Notably: real-browser verification, faster-whisper path, resumable renders.


## V4 session (clip selection engine) - results
Environment: Linux sandbox, Python 3.12, Node 22, FFmpeg 6.1.1, yt-dlp 2026.10.26 (installed for tests).
| Check | Result |
|---|---|
| Baseline before changes | 170 passed, 12 failed because yt-dlp was not installed in the sandbox; with yt-dlp installed the link tests pass |
| Per-module runs after changes (each run separately; a single full-suite run exceeded the sandbox's 5-minute limit and a background run was killed, so no single combined run is recorded) | core 17, pro 18, providers 9, ytdlp 51, links_api 18, vanta_unit 57, vanta_e2e 12, selection 45 = **227 passed, 0 failed, 0 skipped** |
| `tsc --noEmit`, `npm run build` | pass |
| `python backend/evaluate_ranking.py` | see docs/EVALUATION.md: engine beat baseline on the synthetic fixtures (tuned on those fixtures, so optimistic) |
**Not verified:** quality against human ratings (none exist yet); local LLM against a real model; browser click-through of the new panel; Windows launchers; faster-whisper; live YouTube download.
**Not implemented from the repair/automation prompt:** daily scheduler, Windows startup/background service, YouTube upload (OAuth), title/description/thumbnail generation, editable settings UI, resumable jobs. Existing behaviour of these items was not changed.

## Session 2 status
Done: TODO 1, TODO 2 (Linux-verified only). Not started: TODO 3-13. See CONTINUATION_PROMPT.md.

## Session 3
* TODO 3 (YouTube ingestion): audited; trailing-dot host bug fixed; `tests/test_ingestion_audit.py` added (74 ingestion tests pass on Linux). Real download unverified (no network in sandbox). See `docs/YOUTUBE_INGESTION.md`.
* TODO 2b still needs the user's `scripts\check_captions.bat` output. TODO 4-13 not started.


## STATE AFTER SESSION 4
DONE (Linux-verified with a stub model; real model run NOT verified): TODO 4 local transcription - see `docs/LOCAL_TRANSCRIPTION.md`.
New: `whisper_local.py`, `_auto_transcribe` in pipeline, `/transcription/*` endpoints, AI Models transcription card, `check_transcription.py` + `scripts\check_transcription.bat`,
`enable_local_transcription.bat`, `tests/test_transcription.py` (43 tests). Default model changed base -> small.
STILL OPEN: TODO 2b (needs user's Windows output), 5-13.

## STATE AFTER SESSION 5 (PARTIAL)
DONE, Linux-verified: TODO 5 (job-state audit: stale-progress guard, cancel resting status, failed-render result + diagnostics path shown in Queue, stale-refresh guard, double-click guards, reasons on disabled controls; `tests/test_job_states.py` 12 tests, mutations caught; scripted browser click-through of all 8 sections, no console errors).
DONE, Linux-verified: TODO 6 (real-frame thumbnails from the export, selectable/custom time/download; transcript-only title/description/hashtags with provenance + validation; clip SRT; Exports UI panel; `tests/test_metadata.py` 11 tests). Fixed a Hindi word/hashtag splitting bug found by the tests. New UI panel (PublishPanel) typechecks but was NOT clicked through in a browser.
NOT STARTED: TODO 7 scheduler, 8 YouTube upload, 9 launchers audit, 10 evaluation doc, 11 docs, 12 end-to-end, 13 FINAL2 zip. Full suite NOT re-run after sessions 5 changes.

## STATE AFTER SESSION 6 - PHASE 1 (verification tooling)
DONE, Linux-verified: `verify_all.bat` -> `backend/verify_all.py` -> one scrubbed `verify_report.txt` with PASS / FAIL / SKIPPED per check (system, live YouTube, transcription status, captions, each backend test module run separately with its own timeout). Unit tests: `backend/tests/test_verify_all.py` (26 tests; two deliberate mutations - skip-counted-as-pass and redaction disabled - were caught). Ran end to end in Python mode on the Linux sandbox for a subset (captions check PASS; test_core 17, test_selection 45, test_verify_all 26 OK; system check FAILED there only because that sandbox had no `.env`/links disabled - an honest report line).
NOT VERIFIED: `verify_all.bat` itself and the Windows `cmd /d /s /c` command-line builder have never been executed on Windows (only string-tested). The full backend suite was not run in one go this session. Live YouTube, real Whisper model, browser playback: still the user's to run.
Also: the four CONTINUATION_PROMPT*.md files were merged into one `CONTINUATION_PROMPT.md`, which now carries the Phase 2-5 plan.
NEXT: user runs `verify_all.bat` and returns `verify_report.txt`; then Phase 2 (resumable renders, editable settings, file splits).

## STATE AFTER SESSION 6 - PHASE 2a (resumable jobs)
DONE, Linux-verified: `db.recover_interrupted()` + `pipeline.startup()` continue interrupted render/download jobs as a NEW queued job (old job stays visible as Failed with "continued automatically as job X"). Renders redo only clips without an intact export (file present, size equals the validated size); all-clips-done becomes Completed; crash loops are capped (`VANTA_MAX_RESUMES`, default 2); analyze/transcribe jobs and scheduler-owned jobs are failed as before; no upload job kind exists. `VANTA_RESUME_JOBS=0` restores the old behaviour. `db.fail_interrupted()` is unchanged.
Tests: `tests/test_resume.py` (14 tests incl. one real FFmpeg render resumed through `pipeline.startup()`); mutations caught: intact-exports-ignored (2 tests failed), cap removed (1), scheduler ownership ignored (1). Regression modules re-run OK: test_job_states 12, test_vanta_unit 57, test_scheduler_upload 7, test_links_api 18.
NOT VERIFIED: a real restart of the uvicorn process on Windows; the Queue UI wording for the old/new job pair was not clicked through in a browser; full suite not re-run in one go.

## STATE AFTER SESSION 6 - PHASE 2b (editable settings: backend only)
DONE, Linux-verified: `clipstudio/envsettings.py` + `GET/PUT /api/vanta/settings/fields`. Whitelist of 17 normal keys + 3 write-only secrets (ANTHROPIC_API_KEY, PEXELS_API_KEY, REPLICATE_API_TOKEN); per-field validation (bool/int range/choice/local-only Ollama URL/text); all-or-nothing writes; atomic `.env` rewrite that keeps comments, other lines, CRLF/LF, UTF-8(BOM)/UTF-16/ANSI encoding, drops duplicate active lines (the loader lets the last duplicate win), keeps one `.env.bak`; secrets are never returned (only "is set"); every field is labelled restart-required and compared against the value the running process actually uses. Paths, data folders, Python and yt-dlp runtime settings are deliberately NOT editable.
Tests: `tests/test_envsettings.py` (24 tests); mutations caught: secret leak (2 failures), duplicate lines kept (1), save despite errors (1), any Ollama host allowed (1). test_vanta_e2e 12 OK (the read-only `GET /settings` is unchanged).
NOT DONE: the Settings form in the UI (frontend/app/vanta SettingsView). NOT VERIFIED: writing a real Windows `.env` locked by an editor; a real restart picking the values up.


## STATE AFTER SESSION 7 - PHASE 2c step 1 (router.py split)
DONE, Linux-verified: the 42 KB `clipstudio/router.py` is now a thin assembler (about 35 lines) plus ten route modules in `clipstudio/routes/` (`system`, `scheduling`, `projects`, `transcription`, `candidates`, `render_jobs`, `exports`, `publishing`, `templates`, `cloud_ai`) and `routes/common.py` (shared helpers, `VERSION`). Handler code was moved by line range, not retyped; the only edit inside a handler is one relative import (`from .captions` -> `from ..captions` in `candidate_srt`). `router.py` still exports every name the old module had (including private helpers), so `from app.clipstudio import router`, `router.upload_export_to_youtube` and `mock.patch("app.clipstudio.router.youtube_upload.status")` keep working. `app/main.py` is unchanged.
Evidence: the OpenAPI document of the whole app was captured before and after: all 94 operations (64 under `/api/vanta`) identical in method, path, operationId and tags; the only difference is a cosmetic schema component name (`YouTubeUploadRequest` is now qualified with its new module name; nothing in the frontend reads it). New `tests/test_router_split.py` (6 tests) + `tests/data/vanta_routes_snapshot.json` (taken from the ORIGINAL file) guard route set, tags/prefix, duplicate routes, mounted modules, old names and the patch path. Mutations caught: module dropped from the mount loop (2 failures), a route path renamed (1), a re-export removed (1).
Regression: test_vanta_unit 57, test_scheduler_upload 7, test_envsettings 24, test_resume 14, test_job_states 12, test_core 17, test_metadata 11, test_selection 45, test_links_api 18, test_vanta_e2e 12 (real HTTP + FFmpeg), test_pro 18, test_video_providers 9, test_transcription 43, test_verify_all 26, test_remaining_repair 40, test_ingestion_audit 5, ytdlp 51 - all OK, each module run separately. `compileall -q backend` OK; pyflakes clean on the new modules.
NOT RE-RUN: the frontend (no frontend file changed, so tsc/build were not repeated); the full suite in one go; Windows.
Found and fixed (pre-existing, NOT caused by the split): `tests/test_final2_e2e_light.py` was already failing on the original code (confirmed against the untouched backup). It sent `target_duration: 9` although the analyze API requires >= 10, then asserted `GET /projects/{id}` `exports == 1` although that endpoint returns the list (only the project LIST endpoint returns a count; the frontend uses them that way). Both assertions in the test were corrected (10, `len(...) == 1`); the test now passes (real upload -> analyze -> approve -> render -> export, ffprobe 1080x1920 h264, upload state `not_started`). Also run OK: `test_check_captions` 16. NOT run this session: `test_captions_render` (slowest module).

## STATE AFTER SESSION 7 - PHASE 2c step 2 (ytdlp.py split)
DONE, Linux-verified: the 37.7 KB `clipstudio/ytdlp.py` (670 lines) is now a 281-line facade plus `ytdlp_const.py`, `ytdlp_urls.py`, `ytdlp_errors.py`, `ytdlp_probe.py`, `ytdlp_proc.py` (all copied by line range, not retyped). Design decision: everything the tests patch (`installed`, `version`, `base_command`, `diagnostics`, `download`, `update`, `check_disk`, plus the `subprocess`, `shutil`, `time` module references) stays in `ytdlp.py`, because a patch on `ytdlp.X` only reaches callers that look `X` up in that module. Only pure/leaf code moved; every old name, including private ones (`_CACHE`, `_RULES`, `_collect`, `_UPDATE_LOCK`), is still importable from `ytdlp`.
Evidence: `tests/data/ytdlp_surface_snapshot.json` was taken from the ORIGINAL file (75 names: kind and normalised signature) and is identical after the split. `tests/test_ytdlp_split.py` (9 tests) guards it; 5 mutations caught (re-export dropped, diagnostics bypassing the facade's `ffmpeg_info`, `base_command` bypassing `installed`, a `--cookies` flag added, a function copied instead of re-exported). pyflakes found 2 real missing imports during the work (`Path` in ytdlp_errors, `LinkError` in ytdlp_urls); both fixed before the first test run.
Regression (each module run separately, after the split): core 17, envsettings 24, final2_e2e_light 1, ingestion_audit 5, job_states 12, links_api 18, metadata 11, pro 18, remaining_repair 40, resume 14, router_split 6, scheduler_upload 7, selection 45, transcription 43, vanta_e2e 12, vanta_unit 57, verify_all 26, video_providers 9, ytdlp 51 (same as before the split), ytdlp_split 9, check_captions 16 - all OK; `python -m compileall -q backend` clean.
NOT RE-RUN: `test_captions_render` (slowest module); the frontend (untouched); Windows; live YouTube (the split touches no network code, but a real download was not run).

## STATE AFTER SESSION 7 - PHASE 2c step 3 (legacy renderer.py split)
DONE, Linux-verified: the 51.6 KB / 1002-line `app/renderer.py` is now a 347-line facade (19.7 KB) plus `renderer_common.py`, `renderer_scenes.py`, `renderer_audio.py`, `renderer_validate.py`, `renderer_download.py`, `renderer_clips.py` (copied by line range; a script confirmed no non-blank original line was left uncovered). The facade keeps `render_video`, `_render_ai_video`, `_temporal_motion_score`, `_existing_ai_clip_motion_score` (the helper `tests/test_core.py` patches as `app.renderer._temporal_motion_score`, so its caller must look it up in the facade) and the `subprocess`/`httpx`/`socket`/`shutil`/`Image` references, and re-exports every old name incl. private ones used by `pro_render.py` and the tests. `pro_render.py` untouched.
Evidence: `tests/data/renderer_surface_snapshot.json` (58 names, taken from the ORIGINAL) identical after the split; `tests/test_renderer_split.py` (8 tests: surface, re-export identity, facade-resident functions, patch reaches caller, pinned behaviour of dims/wrap/_timestamp/_parse_srt_time/_palette taken from the original code, size limits, `main`/`pro_render` imports). 5 mutations caught (re-export line dropped, function copied, `dims` behaviour changed, `subprocess` import removed from facade, motion-score patch bypassed). pyflakes: only intentional re-export "unused" lines.
Regression (each module separately): all 22 backend modules OK incl. core 17, pro 18, vanta_e2e 12, final2_e2e_light 1, job_states 12, ytdlp 51, renderer_split 8, check_captions 16; `compileall -q backend` clean.
NOT RE-RUN: `test_captions_render`; the frontend (untouched); Windows; a real legacy text-to-video render with an AI video provider (only the FFmpeg-based pro and source-clip paths exercised by tests).

@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON (
    echo Python 3.10+ backend environment not found. Run setup_backend.bat first.
    if not "%VANTA_NO_PAUSE%"=="1" pause
    exit /b 1
)
where ffmpeg >nul 2>nul || ( echo FFmpeg was not found. Run check_system.bat for setup help. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where ffprobe >nul 2>nul || ( echo FFprobe was not found. Run check_system.bat for setup help. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
echo Using Python: %STUDIO_PYTHON%
"%STUDIO_PYTHON%" --version
cd /d "%~dp0backend"
"%STUDIO_PYTHON%" run.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Backend stopped with an error. Check the Python traceback above.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

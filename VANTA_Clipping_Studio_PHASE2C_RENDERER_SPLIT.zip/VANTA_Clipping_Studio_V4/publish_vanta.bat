@echo off
setlocal
cd /d "%~dp0"
where git >nul 2>nul
if errorlevel 1 (
  echo Git is not installed. Install Git for Windows from https://git-scm.com/download/win
  pause
  exit /b 1
)
if not exist .git git init
 git add .
 git commit -m "Initial commit: VANTA Clipping Studio"
if errorlevel 1 (
  echo Commit did not complete. If Git says identity is unknown, run:
  echo   git config --global user.name "Your Name"
  echo   git config --global user.email "your-email@example.com"
  pause
  exit /b 1
)
git branch -M main
git remote get-url origin >nul 2>nul
if errorlevel 1 git remote add origin https://github.com/shubhankarchavanans00173-web/VANTA-Clipping-Studio.git
git push -u origin main
if errorlevel 1 (
  echo Push failed. Check that you created the GitHub repository and signed in.
  pause
  exit /b 1
)
echo VANTA was pushed to GitHub successfully.
pause

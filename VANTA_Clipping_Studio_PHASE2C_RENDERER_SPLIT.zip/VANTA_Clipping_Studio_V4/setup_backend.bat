@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON (
    where py >nul 2>nul || ( echo Python Launcher was not found. Install Python 3.11 or newer from python.org. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
    echo No backend environment found - creating .venv in this folder...
    py -3.10 -m venv .venv >nul 2>nul
    if errorlevel 1 py -3.11 -m venv .venv >nul 2>nul
    if errorlevel 1 py -3.12 -m venv .venv
    if errorlevel 1 ( echo Could not create a Python 3.10+ virtual environment. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
    set "STUDIO_PYTHON=%~dp0.venv\Scripts\python.exe"
)
echo Installing into: %STUDIO_PYTHON%
"%STUDIO_PYTHON%" -m pip install --upgrade pip
if errorlevel 1 ( echo Could not upgrade pip. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
"%STUDIO_PYTHON%" -m pip install -r backend\requirements.txt
if errorlevel 1 ( echo Installing the backend requirements failed. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
echo.
echo Done. Optional: run enable_youtube_links.bat to add public-video link downloads.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b 0

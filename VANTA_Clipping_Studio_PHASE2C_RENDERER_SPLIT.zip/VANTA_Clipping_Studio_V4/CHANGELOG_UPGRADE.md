# Final2 - scheduler, VANTA upload review and Windows setup

## Added

* Persistent opt-in scheduler tables and service: timezone/daily time,
  videos-per-run, retries, pause/resume, crash reconciliation, a local
  single-instance lock and scheduler log.
* Scheduler queue actions in Create Shorts and Settings. Only explicitly
  approved local clips can be queued. The scheduler cannot upload or publish.
* Per-export VANTA YouTube review panel and official backend-only OAuth upload
  route. Private is the default, a fresh confirmation is required for each
  export, resumable uploads use the official API and confirmed video IDs are
  saved only after a successful response.
* Windows Task Scheduler helper scripts: install_scheduler_task.bat and
  uninstall_scheduler_task.bat. The installed backend-start task does not
  enable the scheduler.
* Focused scheduler/upload test coverage and setup/evaluation documentation.

## Changed

* Batch launchers now use an interpreter selection helper, work from their own
  folder, check required programs and return non-zero failures. Automation may
  set VANTA_NO_PAUSE=1.
* Existing original clip ranker and legacy studio remain available unchanged.

## Not claimed

* No live OAuth, YouTube upload, public publishing, human-ranked quality
  result, real Whisper model run, live platform ingestion, or Windows Task
  Scheduler registration was performed during Final2 verification.

# V4.0 - Intelligent clip selection engine

Added `backend/app/clipstudio/selection/` (audio, lexicon, features, candidates, scoring, explain, engine, llm_eval, evaluation), `backend/evaluation/`,
`backend/evaluate_ranking.py`, `docs/INTELLIGENT_CLIPS.md`, `docs/EVALUATION.md`, `frontend/app/vanta/WhyPanel.tsx`, `backend/tests/test_selection.py` (45 tests).
Changed: `pipeline.py` (engine + labelled fallback + loudness envelope in the signals file), `db.py` (candidates.analysis column with automatic migration, clip_feedback table),
`router.py` (engine_mode/local_llm options, feedback + evaluation + llm-status routes, health.clip_engine), UI (Ranking selector, Why-selected panel, ratings, Models view).
Tests updated: three e2e assertions for the new default method labels; link test 10 now fails both rankers. `analysis.py` (old ranker) untouched.
No new Python dependencies. Not done in V4: daily automation, YouTube upload, Whisper verification (see UPGRADE_STATUS.md).

# Changelog — upgrade to VANTA Clipping Studio

## Added
- `backend/app/clipstudio/` — new clipping engine: `timeutil`, `media` (ffprobe/silence/scene), `transcript` (SRT/VTT/JSON + pluggable engines, faster-whisper adapter), `analysis` (ranking, explanations, overlap control, labelled fallback), `captions` (trim-aware, word/sentence level, ASS/SRT), `render` (FFmpeg, real progress, ffprobe validation), `links` (SSRF-safe direct download, optional yt-dlp adapter), `cost` (paid-AI gate), `db` (SQLite + job state machine), `pipeline` (single-worker jobs, cancel, cleanup), `router` (`/api/vanta/*`).
- New UI (`frontend/app/page.tsx`, `frontend/app/vanta/*`): Create Shorts, Video Links, My Projects, Processing Queue, Exports, Templates, AI Models, Settings.
- Tests: `test_vanta_unit.py` (58), `test_vanta_e2e.py` (12), `vanta_fixtures.py`.
- Docs: new `README.md`, `UPGRADE_STATUS.md`, `CONTINUATION_PROMPT.md`, `docs/LEGACY_README.md`, `backend/requirements-optional.txt`, VANTA section in `.env.example`.

## Changed
- `backend/app/main.py`: mounts the VANTA router, runs VANTA startup (schema, interrupted-job recovery, stale scratch cleanup); title/version bumped.
- Legacy page moved from `/` to `/legacy` (unchanged).

## Fixed
- `backend/app/store.py`: SQLite connections were never closed (sqlite3's context manager only commits). Now closed deterministically; behaviour otherwise identical.

## Not changed
- Legacy text-to-video renderer, providers, YouTube upload module, their tests and launch scripts.


## V2 YouTube-link enablement (2026-10-25)
- Added `enable_youtube_links.bat` for Windows. It locates the existing VANTA Python environment, installs the free `yt-dlp` package, and enables `VANTA_ENABLE_YTDLP=1` in `.env` without replacing other settings.
- Added YouTube no-cookie embed host classification for supported public embed URLs.
- Added tests for YouTube Shorts URLs and YouTube no-cookie embed URLs.
- Documented the exact setup → link → analyze → approve → render workflow.
- No paid API calls were made. Live YouTube downloads were not attempted in this build environment; the existing adapter remains best-effort and access restrictions are not bypassed.

## V2.1 — Automatic Auto Clip workflow
- Added an `Auto Clip · Find & Render` action in the Create Shorts view.
- The auto mode runs the existing local candidate-ranking pipeline, approves the top ranked suggestions, then queues rendering with the selected caption/aspect settings without manual timestamp selection.
- Existing manual Analyze → approve → Render workflow remains available.
- Auto Clip uses heuristic transcript/audio/scene signals. It does not claim to predict virality, and it does not auto-publish to YouTube.
- This change does not add paid API calls. Live YouTube download/render testing is still required on the user's machine.


## V2.2 — YouTube-link diagnostics and updater (item 1)
- Fixed downloader discovery when `yt-dlp` is installed in the active backend Python environment but its Scripts directory is not on `PATH`: VANTA can invoke `python -m yt_dlp` and also detects the environment's sibling executable.
- Added clearer `yt-dlp` error categories/messages for bot checks, login/age gates, regional restrictions, outdated extractors, network/DNS/TLS errors, rate limits and unavailable videos. VANTA does not bypass access controls.
- Added `POST /api/vanta/links/update-ytdlp`, which runs `pip install --upgrade yt-dlp` using the current backend's `sys.executable`; no paid APIs are involved.
- Added installed/version fields to `GET /api/vanta/health` and the Video Links status panel, plus an **Update yt-dlp** button.
- Added stubbed unit coverage for each new error category and the updater endpoint.
- Verification: VANTA unit tests **59 passed**; legacy/core/pro-provider suite **44 passed**; VANTA e2e suite **12 passed**. Full test discovery was attempted but timed out in this environment, so no full-suite pass is claimed. Python syntax compilation passed. Frontend dependency installation timed out; `npx tsc --noEmit` then failed because the partial `node_modules` lacked type packages, and the production build was not run. No live YouTube download or live `yt-dlp` update was performed.

## V3.0 — Reliable video-link downloads (2026-10-27)
### Fixed (root cause of "yt-dlp may be outdated for this site")
* `classify_ytdlp_error` regex-scanned the *whole* stderr, including `Deprecated Feature:` / `WARNING:` lines. yt-dlp on Python 3.10 prints "…Please update to Python 3.11 or above", which matched the `please update` pattern, so real errors (*This video is unavailable*, *live stream recording is not available*, …) were all shown as "yt-dlp outdated". Now only `ERROR:` lines decide; warnings are context only. Other over-broad patterns fixed (`rate` matched "generated"; `login`/`cookies` matched yt-dlp's standard hint).
* yt-dlp was located via `PATH` while the updater used `sys.executable` (possibly different Pythons). Everything now runs `<backend python> -m yt_dlp`.
* No JavaScript runtime was ever passed to yt-dlp → YouTube challenge failures. Node/Deno/Bun/QuickJS is detected (version-checked) and passed via `--js-runtimes`; `yt-dlp[default]` supplies the local solver scripts.
* Windows output decoding (`text=True` used the ANSI code page) could crash on non-ASCII titles; output is now UTF-8.
* `.env` loader: UTF-16 files (PowerShell `>>`) crashed startup; inline `# comments` silently disabled `VANTA_ENABLE_YTDLP=1`. Both handled.
* Two clicks could start two jobs on one project (check-then-create race); submission is now atomic.
### Added
* `ytdlp.py` adapter: canonical YouTube URL parsing (watch, youtu.be, Shorts, embed, nocookie, live), 20+ precise error codes with hints and scrubbed details, streaming runner with real % progress, timeout, bounded retries for transient errors only, cancellation that kills the whole process tree, staging folder + ffprobe validation before registration, free-disk check, secrets stripped from the child environment.
* **Download job** (`downloading` state), `POST /projects/{id}/download` (Retry; never re-downloads a valid local copy), duplicate detection by canonical id, orphaned-download adoption, structured errors on jobs/projects (`download_error`), startup cleanup of leftover staging folders, "video saved but analysis failed" labelling.
* `GET /api/vanta/diagnostics`, Diagnostics panel (Video Links + Settings, Copy report), `backend/diagnose.py` (+ `--test-url` real download test), `diagnose_youtube.bat`.
* Update yt-dlp: dry-run first, `--upgrade-strategy only-if-needed`, verifies the new version, reports executable/previous/new version and any other packages changed, refused during downloads.
* UI: structured error box (code, what to do, diagnostic details, Retry, local-upload fallback), Download state in queue/projects.
* Scripts: `_find_python.bat` (single source of the backend interpreter), `stop_all.bat`, `migrate_python_env.bat` (new Python 3.12 env, old one untouched), `backend/requirements-links.txt`.
* Docs: `docs/YOUTUBE_LINKS.md`.
### Changed
* Linking a video now starts the download immediately (`start_download=false` keeps the old behaviour). Analyze still downloads first if no file exists. `unknown` failures are `unknown_error` (not "download_failed"). The `yt_dlp_outdated` code no longer exists; extractor failures are `extraction_failed`.
### Not changed
* Existing projects, exports, settings, DB schema (no migration), design, other routes.

## Session 2 (partial)
- Caption verification at up to 4 moments per clip; probe uses input-side seek (-copyts).
- Fix: output-validation failure no longer raises FileNotFoundError; FAILED_render.mp4 kept.
- New: backend/check_captions.py + scripts/check_captions.bat (Hindi box detection).
- New tests: test_remaining_repair.py, test_check_captions.py.


## Session 4 - local transcription
* New `clipstudio/whisper_local.py`: model discovery (never downloads implicitly), confirmed + cancellable model download in a child process, CPU/int8 default with CUDA only when safe and automatic CPU retry, word-timing validation, real progress, cancel, content-hash transcript cache.
* `pipeline._auto_transcribe` replaces the inline transcription block; engine errors become job notes; cancel during transcription ends the job as cancelled.
* API: `/transcription/status`, `/transcription/models/download(+/cancel)`, `DELETE /transcription/cache`; analyze accepts `whisper_model`.
* UI: AI Models -> Transcription card (status, device, model picker, confirmed download with progress/cancel); Create Shorts badge says "model needed" instead of "available".
* Tools: `enable_local_transcription.bat`, `scripts/check_transcription.bat`, `backend/check_transcription.py`. Default `VANTA_WHISPER_MODEL` is now `small` (was `base`).

## Session 5 (partial)
* Jobs: late progress can no longer overwrite settled jobs; cancelling a queued/running re-analysis returns the project to review; all-failed renders keep `result.failed` with diagnostics paths; Queue shows them; UI ignores stale refresh responses and double clicks.
* New `metadata.py` + endpoints: `/exports/{id}/thumbnails`, `/thumbnail`, `/metadata(/suggest)`, `/candidates/{id}/srt`.

# Universal AI Shorts Studio - V3 (YouTube-ready)

Local-first video studio for YouTube **Shorts and long-form**. Type a topic (or paste a script) and get a finished,
narrated, captioned **1080p** MP4 + thumbnail + title/description/hashtags, then upload straight to your channel.

## What's new in V3
| Area | Before (V2) | Now (V3) |
|---|---|---|
| Visuals | flat text slides with a slow zoom | **real HD stock footage per scene** (free Pexels key) or vivid animated backgrounds, shade overlays, scene title chips, cross-fade transitions |
| Voice | robotic Windows voice (often unavailable) | **free neural voices** (edge-tts, 400+ voices incl. Hindi/Marathi/Indian English) with automatic offline fallback |
| Captions | static sentence box baked into slides | **word-synced karaoke captions** burned in + accurate SRT |
| Timing | fixed even split | scene length follows the **actual narration length** |
| Quality | CRF 23 / veryfast / 720p default | **1080p, 30fps, CRF 17, H.264 High, AAC 192k, bt709, -14 LUFS loudness**, music auto-ducks under voice |
| Scripts | generic template for topic-only | optional **LLM script writer** (free local Ollama, or Claude API) with hook, scenes, titles, hashtags |
| Length | 15-90 s | **15 s - 10 min**, 9:16 / 16:9 / 1:1, up to 60 fps |
| Thumbnail | raw video frame | designed **1280x720 YouTube thumbnail** with bold title |
| Publishing | none | **YouTube upload** (official OAuth): private/unlisted/public/scheduled, thumbnail, Shorts tagging, AI-disclosure flag, chapters, footage credits |
| Extras | | progress bar, watermark, delete projects, `.env` config, one-click `start_all.bat` |

Still included from V2: Video-to-Clips (your footage), script editing, scene storyboard, job history, optional local AnimateDiff and paid Replicate providers (both unchanged).

## Quick start (Windows 10/11)
1. Install **Python 3.10+**, **Node.js 20+**, **FFmpeg** (`winget install Gyan.FFmpeg`, then reopen the terminal). Double-click `check_system.bat` to verify.
2. Double-click **`setup_all.bat`** (installs backend + frontend packages once).
3. Copy `.env.example` to `.env`, paste your **free Pexels key** (https://www.pexels.com/api/ - instant, no card).
4. Double-click **`start_all.bat`** - opens http://localhost:3000.

First video: pick **AI Video / Script to Video**, type a topic, leave *Studio Pro* defaults, press *Create video project* then *Produce*.

## Getting great results
* **Use your own script** for the best quality - paste it under *Script to Video*. Narration, scene timing and captions all follow it.
* **Topic-only** prompts need a script writer. Free option: install [Ollama](https://ollama.com), run `ollama pull llama3.1`, put `OLLAMA_MODEL=llama3.1` in `.env`. Or set `ANTHROPIC_API_KEY`. Without either you get a clearly-labelled template - edit it in the Storyboard panel.
* Edit each scene's **search phrase** idea: the planner derives stock-footage keywords from your text (shown as `search_query` in the storyboard JSON; edit scene text to steer it).
* Shorts: 9:16, up to 180 s. Long-form: 16:9, any length up to 10 min per job.
* Pick *Karaoke* captions for Shorts, *Classic* for long-form.
* Add your own music (royalty-free/licensed) under Advanced - it ducks automatically under the voice.

## Configuration (`.env`)
| Key | Purpose |
|---|---|
| `PEXELS_API_KEY` | free HD stock footage |
| `OLLAMA_MODEL` / `OLLAMA_URL` | free local script writer |
| `ANTHROPIC_API_KEY` / `STUDIO_LLM_MODEL` | Claude script writer (paid API) |
| `YOUTUBE_CLIENT_SECRET_FILE` | path to Google OAuth client JSON (default `data/secrets/client_secret.json`) |
| `REPLICATE_API_TOKEN`, `STUDIO_ONLINE_PROVIDER`, ... | optional paid AI video, unchanged from V2 |
| `STUDIO_LEGACY_RENDERER=1` | use the old slide renderer (not recommended) |

## YouTube upload
See `docs/YOUTUBE_SETUP.md`. Uploads default to **Private**. Google keeps API uploads from un-audited projects private until you complete their audit - you can publish from YouTube Studio meanwhile. A single upload costs 1,600 of the default 10,000 daily API quota units (~6 uploads/day).

## Honest notes and limits
* **Stock footage** is what gives the "professional" look. Pexels licence allows free commercial use; credits are appended to the description automatically. Search is keyword-based, so clip relevance depends on your script's wording - review the preview.
* **Neural voices need internet** (Microsoft's free edge service, via the `edge-tts` package; unofficial, could change). If it fails, the studio falls back to the offline Windows voice, then to captions-only, and tells you in the job notice.
* **YouTube policy**: videos made mostly from stock footage + synthetic voice with no original value can be flagged as "reused/inauthentic content" and demonetised. Add real commentary/insight, your own edits, and keep the AI-disclosure box ticked for realistic synthetic content.
* **Local AnimateDiff** remains very low resolution on small GPUs; use Studio Pro for publishable output.
* Rendering is CPU bound: expect roughly 0.3-1x real-time at 1080p on a typical laptop (a 60 s Short in 1-3 minutes). Use the *Balanced* preset for quicker drafts.
* The YouTube upload, Pexels, edge-tts and LLM calls require internet/credentials and could not be exercised end-to-end in the build environment; they are covered by unit tests with mocks and written against the official API contracts. Please test with a **private** upload first.

## Development
```
python -m compileall -q backend
set PYTHONPATH=backend
python -m unittest discover -s backend/tests -v
cd frontend && npm install && npm run build
```
Do not expose the dev servers to the public internet. Secrets live in `.env` and `data/secrets/` (git-ignored).

# Caption rendering (burned-in captions)

## Pipeline
transcript (SRT/VTT/JSON/Whisper) -> `captions.build_track` (absolute -> clip-relative times, silence-removal remap)
-> `capfx.prepare_fonts` (per-render `fonts/` folder: bundled DejaVu Sans + requested font if found + script fallbacks)
-> `write_ass` -> **probe** (render the ASS alone on a grey and a black canvas; opaque glyph pixels = identical on both)
-> FFmpeg `ass=captions.ass:fontsdir=fonts` (relative names, cwd = work dir, so no Windows drive-letter escaping)
-> output validated with ffprobe -> **frame check**: the exported frame at EACH of up to 4 probe times (first, last and evenly spread caption events) must contain >= 85% of that probe's glyph pixels. Probes seek on the input side with `-copyts` (frame-identical to output-side seeking, ~15x faster).

## Rules
* Captions requested + no transcript / no speech in range / libass unusable / pixels not found => the job FAILS with an actionable message. No uncaptioned MP4 is ever exported as success.
* Failed renders keep `ass`, probe PNGs, ffmpeg command/stderr and `FAILED_render.mp4` in `<data>/diagnostics/<job>/<clip>` (newest 20 jobs kept).
* Long sentence-level lines only partly inside a clip are split proportionally by character position and labelled "estimated" in the track note. Word highlighting only happens with real word timings.

## Troubleshooting
* "libass drew only 0 pixels": set `VANTA_FONTS_DIR` to a folder with a .ttf (e.g. `C:\Windows\Fonts`) or use an FFmpeg "full" build (gyan.dev).
* "ass filter unavailable": your FFmpeg lacks libass; install a full build. Check with `ffmpeg -filters | findstr " ass "`.
* Non-Latin text: install a font covering the script (Windows: Nirmala UI for Devanagari). Missing coverage is reported in the caption note.

## Verification limits
The frame check samples up to 4 moments, not every frame. It proves captions are in the file, not that every caption is correct, and it cannot tell shaped Devanagari from missing-glyph boxes (boxes are pixels too). Verified on Linux/FFmpeg 6.1 only; Windows behaviour is covered by escaping unit tests and a no-fonts emulation, not by a real Windows run.

## check_captions (real-machine self-test)
`scripts\check_captions.bat` (or `python backend/check_captions.py`) renders a 5 s 9:16 sample with an English, a Hindi and an English caption through the production render path and prints PASS/FAIL (exit 0/1/2). For the Hindi line it renders the same caption with every Devanagari character replaced by a missing-glyph code point and compares the masks: >= 80% identical => boxes => FAIL. Verified on Linux (real font: 23% similarity, PASS; empty fontconfig: 100%, FAIL). **Not yet run on Windows.** Always open `check_captions_output\frame_1.png` and look at the Hindi line yourself.

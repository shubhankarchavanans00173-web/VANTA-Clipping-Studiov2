# VANTA YouTube upload setup

Status: **implemented and mock-tested; live OAuth/upload unverified.**

VANTA uploads only through the official YouTube Data API and a local OAuth
Desktop client. No credential, refresh token, or API key is sent to the
browser, placed in .env.example, or included in a release ZIP.

## Before starting

1. In Google Cloud Console, create or select a project and enable YouTube
   Data API v3.
2. Configure the OAuth consent screen and add yourself as a test user if the
   app is in testing.
3. Create an OAuth Desktop app client and download its JSON file.
4. Save the JSON as data/secrets/client_secret.json, or set
   YOUTUBE_CLIENT_SECRET_FILE to a local path in .env.
5. Run setup_backend.bat, start VANTA, open Exports, and expand YouTube upload
   for a verified local export.

The JSON client secret and the later data/secrets/youtube_token.json are local
machine files. Keep both private. Do not commit them or put them in a ZIP.

## Per-export review and confirmation

1. Inspect the exported MP4 in VANTA and confirm its ffprobe verified badge.
2. Use Thumbnail and details to review/edit title, description, hashtags and
   an optional frame from that same exported video.
3. Expand YouTube upload. Connect the local account when prompted.
4. Keep Private unless you intentionally choose Unlisted or Public.
5. Tick the one-export confirmation checkbox and press Explicitly confirm
   upload.

Every upload requires a fresh confirmation. The scheduler cannot import the
upload service and never uploads, publishes, schedules publication, downloads
source media, or calls a paid service. An export already carrying a confirmed
YouTube video ID is blocked from being uploaded again.

## Behaviour and recovery

* Uploads use the official resumable MediaFileUpload API with 8 MiB chunks.
  Transient 5xx/network failures are retried up to three times within the
  active request.
* VANTA records video ID, public URL and Studio URL only after YouTube returns
  an API-confirmed ID. A quota/token/error state records no video ID.
* Quota, daily upload limit, rate-limit, invalid/revoked token and 403
  responses are presented as actionable errors. Reconnect if the token is
  expired or revoked.
* If VANTA restarts during an upload, it records the attempt as interrupted.
  Review the video in YouTube Studio before you explicitly retry: API-level
  resumable state cannot safely be assumed after the local process dies.
* YouTube may enforce private uploads for unaudited API projects. VANTA does
  not circumvent that policy.

## Verification limits

The automated suite uses mocks for successful upload, quota failure, explicit
confirmation, and the save-ID-only-on-success rule. No real Google
credentials, OAuth consent flow, channel, network upload, quota consumption,
or publication was used in this release. Perform a manual Private test before
relying on live uploads.

# Intelligent clip selection (V4)

VANTA now ranks clips with a modular, rule-based, multi-signal engine (`backend/app/clipstudio/selection/`). The original simple
heuristic ranker (`analysis.py`) is unchanged and still selectable (**Ranking → Simple heuristic**) and is used automatically,
with a visible note, if the new engine ever raises an error.

**The score is a relative ranking inside one video. It is not a probability, and it does not predict views or virality.**

## How a clip is chosen
1. **Sentence units** come from the transcript (SRT/VTT sentence timings, or word timings from JSON/faster-whisper).
2. **Candidates** are generated around promising sentences (questions, promises, specific claims, reveals, conclusions) and after
   natural pauses. For each anchor the engine tries starting one or two sentences earlier when the opening needs setup, and several
   end points (sentence ends nearest the target, ends before a pause). Windows always start/end on sentence edges; near-duplicates
   (start and end both within 1 s) are dropped, while different boundaries are kept as alternatives.
3. **Features** (each 0–1 with the evidence it came from): hook, payoff (question→answer / turn / conclusion), standalone clarity,
   story completeness, information value, opening quality, ending quality, caption readability, duration fit, emotional wording,
   and, when measured, speech activity, loudness variation, pause before the payoff and scene cuts.
   **Penalties:** context dependency (dangling openers, back-references, talk about the conversation itself), repetition,
   intro/outro/filler talk.
4. **Score** = weighted mean of the features that were actually measurable (weights renormalised; missing signals are excluded, not
   scored as zero) minus penalties, clamped to 0–100. Weights live in `selection/scoring.py`; override with `VANTA_RANK_WEIGHTS`
   (JSON, unknown keys ignored).
5. **Selection** keeps the best clips with ≤15 % overlap and skips clips about the same topic (word-overlap similarity), so the list
   is diverse. Each pick lists up to two alternative cut points for the same moment.
6. **Explanation** (“Why selected”) is assembled from the measured features and quotes real transcript sentences. Nothing is free-written.

## What was and was not analysed
| Signal | Status |
|---|---|
| Transcript semantics | Rule-based language cues (not a language model). English patterns only. |
| Audio loudness / pauses / loudness variation | Measured with FFmpeg → RMS envelope (stdlib). Loud ≠ interesting, so weights are small. |
| Scene cuts | Counted with FFmpeg scene detection. |
| Laughter / applause / sound events | **Not analysed** (no classifier bundled). |
| Faces, gestures, emotion, on-screen text, vertical-crop suitability | **Not analysed.** |
Each suggestion shows “Signals used” and “Not analysed”. Without a transcript the method is labelled *Audio/scene cues only*,
confidence is **low**, and meaning was not assessed.

**Confidence** = how much of the rubric could be measured plus how clean the start/end are (high / medium / low). It says nothing about popularity.

## Optional local language model (off by default)
Uses a local **Ollama** server only (loopback address enforced). Nothing is downloaded by VANTA.
1. Install Ollama (free) from ollama.com, then yourself run e.g. `ollama pull qwen2.5:3b-instruct`.
2. In `.env`: `VANTA_LOCAL_LLM=ollama` and `VANTA_LOCAL_LLM_MODEL=qwen2.5:3b-instruct` (optional: `VANTA_LLM_TOP_N=8`, `VANTA_LLM_TIMEOUT=120`, `VANTA_OLLAMA_URL`).
3. Restart the backend; **AI Models** shows “local AI ready”.

Sizing (approximate; check `ollama list`): a 3B model at 4-bit quantisation is roughly 2 GB on disk and fits in 4 GB VRAM or runs on CPU
with ~4 GB RAM; 7–8B models are ~4.5–5 GB and would be partly offloaded to CPU on a GTX 1650, which is slow. Expect seconds per clip on GPU,
tens of seconds on CPU; only the top N suggestions are evaluated and results are cached in `data/vanta/cache/llm`.
Safety: transcript text is fenced as untrusted data; the reply must match a strict JSON schema or it is discarded; the model can only
shift a score by ±15 points and cannot change boundaries or invent clips. A suggestion shows “Local AI evaluated” **only** if a valid reply was received.
**This path is covered by tests using a fake transport; it has NOT been run against a real model in the build environment.**

## Rating clips and evaluating rankings
Open **Why selected** and click Excellent / Good / Weak / Incomplete / Repetitive / Missing context (click again to clear). Ratings are stored
locally (with engine, score, boundaries and feature snapshot). `GET /api/vanta/evaluation/summary` reports counts and whether the sample is large
enough (≥30 rated clips before differences mean anything). Nothing is trained from ratings and no weights change automatically; use
`VANTA_RANK_WEIGHTS` if your own ratings convince you a different weighting is better.

Compare baseline and engine on the bundled fixtures: `python backend/evaluate_ranking.py` (`--write` refreshes `docs/EVALUATION.md`;
`--labels file.json` adds human-rated metrics). The fixtures are synthetic and developer-authored: see `docs/EVALUATION.md` for results and their limits.

## Limits
* English language cues; other languages get structural features (duration, boundaries, audio) but weak semantic scoring.
* Rules cannot judge humour, tone of voice, or visual payoffs. A transcript that is auto-generated without punctuation reduces boundary quality.
* The engine was tuned while looking at the bundled synthetic fixtures; its scores there are therefore optimistic.

# YouTube / link ingestion (audit, session 3)

## Final2 status

The Final2 scheduler is intentionally separate from link ingestion: it only
renders explicitly queued, local approved clips and cannot download a link.
Live platform download remains unverified in this environment; it is never an
automatic path to YouTube upload.

Scope: public videos you are authorised to use. VANTA never bypasses private, login/age, DRM or region restrictions, reads no cookies,
and the file upload is always the dependable fallback.

## How it works
`links.normalise_url` -> `links.classify` -> `links.canonical_ref` -> `ytdlp.download` (staging dir) -> `media.probe` (ffprobe) -> move into place.
* URL forms collapsing to one canonical `watch?v=ID` (and one dedupe key): watch (+ list/index/t/si/#fragment), youtu.be, /shorts/, /embed/, /live/, m. and music. hosts, upper-case host, trailing-dot host.
* Rejected with a precise code: playlists, channels, @handles, search pages, embedded playlists, ids that are not 11 characters, lookalike hosts.
* Duplicate submissions return the existing project (`duplicate: true`) instead of downloading again (`router.py`, `db.find_link_project`).
* Errors are classified from yt-dlp `ERROR:` lines only (private/login/age, deleted, region, bot check, live, DRM, rate limit, 5xx, network, timeout,
  missing FFmpeg, missing JS runtime / outdated extractor, disk full, permission, too large). Warnings never decide.
* Bounded retries: only network_error / timeout / server_error, max `VANTA_YTDLP_ATTEMPTS` (default 2), backoff 2 s x attempt, cancellable.
* Cancellation kills yt-dlp and its FFmpeg children (taskkill /T on Windows, process group elsewhere); staging is always removed.
* Downloads are ffprobe-validated and duration-checked before becoming a source; invalid files are discarded.
* Job states: queued -> downloading -> validating -> ...; on failure the job is `failed` with the error. After a backend restart `fail_interrupted()`
  marks active jobs failed and leftover `.dl-*` staging folders are deleted, so nothing stays stuck in downloading/validating.
* yt-dlp version, JS runtime, FFmpeg, free disk are shown by Diagnostics (`ytdlp.diagnostics()`).

## Found and fixed this session
* A host written with a trailing dot (`https://www.youtube.com./watch?v=ID`) was not recognised as YouTube: it was routed to the direct-media
  downloader (confusing "not a video" error) and skipped duplicate detection. Fixed in `links.classify`, `ytdlp.is_youtube_host`, `ytdlp.parse_youtube_url`.

## Verification
| Item | Status |
|---|---|
| `tests/test_ytdlp.py`, `tests/test_links_api.py`, new `tests/test_ingestion_audit.py` | VERIFIED on Linux: 74 passed (mutation-checked: reverting the fix fails 2 sub-tests) |
| Error classification against yt-dlp-style messages | VERIFIED with text fixtures; real yt-dlp wording can change between versions |
| Real download of a public YouTube video | UNVERIFIED: the sandbox has no outbound network (curl to youtube.com fails) |
| Windows (taskkill tree-kill, Node runtime detection, WinGet FFmpeg) | UNVERIFIED: never run on Windows |

## Known limits
* Duplicate check is find-then-create, not atomic: two simultaneous identical submissions could create two projects (no unique index on the reference).
* No cookies / login support by design, so age-restricted and members-only videos fail with `login_required`.

## Please run on your machine
1. `enable_youtube_links.bat`, then open Video Links -> Diagnostics: send me the output.
2. Import one short public video you own or may use; tell me the result and any error code shown.

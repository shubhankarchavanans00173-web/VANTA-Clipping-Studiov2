# VANTA Final Repair Plan

Baseline (before any edit, 2026-10-28, Linux sandbox, Python 3.12, FFmpeg 6.1.1 with libass/x264):
`pytest backend/tests` -> **227 passed, 72 subtests, 154 s**. Backup of the V4 tree taken before editing.

Every defect lists: root cause (reproduced, not assumed) -> fix -> proving test.

## D1. Captions missing from exported MP4 (highest priority)

The captions pipeline itself is correct *when it has a transcript and libass has fonts*: a reproduction render
(`clip 4.2-12.0 s of a 12 s speech video, sentence SRT`) produced 41,841 changed pixels in the caption band versus a
captions-off render. The bug is that **four other paths ship an uncaptioned MP4 and still report success**:

| Path | Reproduced result | Root cause |
|---|---|---|
| A. captions on, no transcript | job SUCCESS, no captions | `build_track` returns an empty track; `render_clip` just records a note. |
| B. libass cannot load any font (empty fontconfig, as on many Windows FFmpeg builds) | FFmpeg exit 0, valid MP4, **0 caption pixels** | Success was defined as "exit 0 + ffprobe OK". Nothing ever looked at pixels. `-loglevel error` also hides libass font warnings. |
| C. long Whisper-style segment partly inside the clip | job SUCCESS, no `.ass` written | Sentence-level lines were dropped unless >=50% inside the clip. |
| G. transcript file moved / data dir changed | UI says "has transcript", render skips captions | `has_transcript = bool(transcript_path)` but loading silently returns `None` if the stored absolute path is outside the current data dir. |

Fix: captions requested => the render must *prove* them or fail. Fonts are prepared per job (bundled DejaVu +
requested font when found) and passed with a relative `fontsdir`; the ASS is probed on a neutral canvas (proves libass
draws glyphs) and then the finished MP4's frame is compared with that probe (proves glyph pixels are in the file).
Failures raise `CaptionError` with an actionable message and diagnostics are kept.

Tests: `tests/test_captions_render.py` (real FFmpeg; frame-pixel assertions), see docs/CAPTION_RENDERING.md.

(Remaining defects are appended below as they are fixed and verified.)

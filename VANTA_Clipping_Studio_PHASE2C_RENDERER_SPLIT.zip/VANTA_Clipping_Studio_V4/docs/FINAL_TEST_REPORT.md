# Final2 test report (2026-10-30)

# Session 6 update (2026-11-03) - Phase 1: verification tooling

| Item | Status | Evidence / limit |
|---|---|---|
| `verify_all.py` classification (PASS/FAIL/SKIPPED, timeouts, exit codes) | VERIFIED (Linux) | `python -m unittest tests.test_verify_all` -> 26 tests OK |
| Secret/home-folder scrubbing in the report | VERIFIED (Linux, unit-level) | redaction tests; mutation "redaction disabled" made 3 tests fail |
| Skips never counted as passes | VERIFIED (Linux) | mutation "skip code -> PASS" made 2 tests fail |
| Scheduled task never touched | VERIFIED (unit-level) | test scans every built command in both modes |
| End-to-end run in Python mode | PARTIAL | subset only (--skip-network, 3 test modules); report written and readable |
| `verify_all.bat` and Windows command-line quoting | NOT VERIFIED | not executable in the Linux sandbox; run it on your PC |
| Live YouTube download, real Whisper, browser playback, live upload | NOT VERIFIED | unchanged; `verify_all.bat` is how you check the first two |
| Full backend suite in one run | NOT VERIFIED | `verify_all.bat` runs it module by module on your PC |

Manual step for you: run `verify_all.bat` (or `verify_all.bat --skip-tests` for a quick pass) and send back `verify_report.txt`.

## Phase 2c step 1 - router.py split (2026-11-03, session 7)

Files: `backend/app/clipstudio/router.py` (now an assembler), `backend/app/clipstudio/routes/*.py` (new), `backend/tests/test_router_split.py` and `backend/tests/data/vanta_routes_snapshot.json` (new). No behaviour change intended or made.

| Item | Status | Evidence / limit |
|---|---|---|
| Same API surface | VERIFIED (Linux) | whole-app OpenAPI captured before/after: 94 operations equal (method, path, operationId, tags); only a cosmetic schema component name differs (`YouTubeUploadRequest` now module-qualified) |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_router_split` -> 6 tests OK; snapshot taken from the original single file |
| Mutation checks | VERIFIED (Linux) | module dropped from mount loop -> 2 tests fail; route path renamed -> 1 fails; re-export removed -> 1 fails; files restored, 6/6 OK |
| Old import and patch paths | VERIFIED (Linux) | `tests.test_scheduler_upload` (7) patches `app.clipstudio.router.youtube_upload.*` and calls `router.upload_export_to_youtube` unchanged, OK |
| Regression modules (each run separately) | VERIFIED (Linux) | vanta_unit 57, envsettings 24, resume 14, job_states 12, core 17, metadata 11, selection 45, links_api 18, vanta_e2e 12, pro 18, video_providers 9, transcription 43, verify_all 26, remaining_repair 40, ingestion_audit 5, ytdlp 51 - all OK |
| `compileall -q backend`, pyflakes on new modules | VERIFIED (Linux) | clean |
| Pre-existing failing test fixed | VERIFIED (Linux) | `tests.test_final2_e2e_light` failed on the ORIGINAL code too (stale: `target_duration` 9 < API minimum 10; project detail `exports` is a list, not a count). Test corrected, now passes; `test_check_captions` 16 OK. `test_captions_render` not run this session |
| Frontend | NOT RE-RUN | no frontend file changed |
| Full suite in one run, Windows | NOT VERIFIED | unchanged limits |

## Phase 2b-UI - settings form (2026-11-03)

Files: `frontend/app/vanta/SettingsFields.tsx` (new), `SettingsView.tsx` (mounts it), `api.ts` (`ApiError.errors` keeps per-field 422 messages), `docs/ui_checks/settings_clickthrough.py` + `reseed_test_env.sh` (the click-through).

| Item | Status | Evidence / limit |
|---|---|---|
| Type check and production build | VERIFIED (Linux) | `cd frontend && npx tsc --noEmit` -> exit 0; `npm run build` -> exit 0 (routes `/`, `/_not-found`, `/legacy`) |
| Scripted browser click-through against the real backend and a temp `.env` (CRLF, comment, one secret) | VERIFIED (Linux, headless Chromium) | 32 checks, 0 failed: grouped fields; saved vs running; restart banner and per-field badge; password inputs; secret shows only "is set" and never appears in the page; invalid value -> per-field 422 error, nothing written (all-or-nothing, typed edits kept); valid save keeps CRLF and comments and writes `.env.bak`; bool/choice save; "Remove my override" deletes the line; secret replace and Clear; malformed secret rejected without echoing it; Discard edits; scheduler panel still renders; no console errors other than the 2 deliberate 422 responses |
| UI mutation checks | VERIFIED (Linux) | banner removed -> 1 check fails; "remove override" sends "" instead of null -> 4 fail; `errors` dropped from `ApiError` -> run fails at the per-field error assertion (caught by a 8 s timeout, not a clean assertion failure). Restored build -> 32/32. An earlier mutation run was INVALID (a stale `next-server` kept serving the old build) and was discarded and redone. |
| Backend regression | VERIFIED (Linux) | `compileall -q backend`; `tests.test_envsettings` 24, `tests.test_resume` 14, `tests.test_job_states` 12, `tests.test_vanta_unit` 57 - all OK |
| Real restart: saved value becomes the running value | NOT VERIFIED | the click-through never restarts the backend; do the Windows check below |
| Windows browser, other browsers, narrow/mobile layout | NOT VERIFIED | only desktop-width headless Chromium was used |
| The form is not covered by a unit-test runner (no Jest/Vitest in the project) | PARTIAL | coverage is the Playwright script, run by hand |

Windows check for you: open Settings, change "Download attempts" to 3 and Save; confirm the yellow "Restart required" banner appears and `.env` (and `.env.bak`) changed; run `stop_all.bat`, `start_all.bat`; reopen Settings and confirm the banner is gone and Running shows 3. Then set a test API key, Save, confirm the field only says "is set", click Clear, and confirm the line is gone from `.env`. Close Notepad on `.env` first (an open editor can block the write; the app then shows a clear error).

## Phase 2a - resumable renders and downloads (2026-11-03)

| Item | Status | Evidence / limit |
|---|---|---|
| Interrupted render/download continued as a new job; intact exports kept | VERIFIED (Linux) | `python -m unittest tests.test_resume` -> 14 tests OK (includes a real 160x90 FFmpeg render resumed via `pipeline.startup()` and ffprobe-valid export) |
| Truncated/missing export files are redone, not trusted | VERIFIED (Linux) | dedicated tests; mutation "ignore intact exports" -> 2 failures |
| Crash-loop cap | VERIFIED (Linux) | mutation "cap removed" -> 1 failure |
| Scheduler-owned jobs left to the scheduler retry path | VERIFIED (Linux) | mutation -> 1 failure; test_scheduler_upload 7 OK |
| Existing behaviour unchanged (`fail_interrupted`, job-state audit, links API) | VERIFIED (Linux) | test_job_states 12, test_vanta_unit 57, test_links_api 18 OK |
| Restarting the real backend process on Windows | NOT VERIFIED | start a render, close `start_backend.bat` window, start it again, open Queue |
| Queue wording for the failed-old / queued-new pair in a browser | NOT VERIFIED | no browser click-through |

## Phase 2b - editable settings API (2026-11-03)

| Item | Status | Evidence / limit |
|---|---|---|
| Validation, whitelist, local-only Ollama URL, all-or-nothing save | VERIFIED (Linux) | `python -m unittest tests.test_envsettings` -> 24 tests OK; 4 mutations caught |
| `.env` keeps comments, line endings, UTF-8 BOM / UTF-16, backup, atomic replace | VERIFIED (Linux, temp files) | dedicated tests incl. a simulated failed `os.replace` |
| Secrets never returned or echoed | VERIFIED (Linux, API + describe) | secret-leak mutation fails 2 tests |
| Settings form in the UI | VERIFIED (Linux, headless Chromium) - see Phase 2b-UI below | |
| Changes taking effect after a real restart; a `.env` open in Notepad | NOT VERIFIED | needs your PC |


This Final2 section is the current release record. Older session notes remain
below for traceability and are not the final feature/status statement.

## Verified in this release

* Frontend production build completed with Next.js 14.2.35.
* The dedicated Final2 scheduler/upload suite passed: 7 tests in 1.638 seconds.
  It covered disabled-by-default configuration, timezone
  validation, persistent queue uniqueness, retry/backoff, restart
  reconciliation, single-instance lock, pause/no-upload boundary, explicit
  upload confirmation, mocked quota failure and save-ID-only-after-success.
* check_system.bat ran through cmd.exe with VANTA_NO_PAUSE=1 and a selected
  Python 3.14 interpreter; it found FFmpeg, FFprobe and Node.js. Optional
  yt-dlp was honestly reported unavailable/disabled.
* The archive process verifies the ZIP manifest and extracts it into a new
  folder before release.

## Partially verified

* The complete backend command was attempted with workspace-local temporary
  state, but this execution environment terminates each command after 30
  seconds during the real-FFmpeg caption tests. It must be rerun on the target
  machine before it can be called a Final2 full-suite pass.
* VANTA import, attached-transcript analysis, explanation, approval, vertical
  captioned MP4 render, FFprobe validation, download and persistence have
  existing automated end-to-end coverage from prior sessions. A Final2 light
  real-media end-to-end check is included but was not completed here because
  of that same command limit.
* Windows launcher syntax and prerequisite detection were audited on Windows,
  but Task Scheduler creation was not executed because it changes a user's
  scheduled-task state.

## Unverified/manual requirements

* Live Google OAuth consent, refresh, quota handling against a real channel,
  resumable network upload and all public/unlisted/public visibility outcomes.
  No credentials or uploads were used. Test a private upload first.
* A real human-labelled clip-quality comparison. No labels are bundled and no
  ranker-quality improvement is claimed.
* A real faster-whisper model download/transcription, live authorised
  platform download, and physical browser click-through/video playback.
* The end-to-end workflow with a user-owned spoken-dialogue source video on
  the target Windows machine, including manual failure/retry observation.

# Historical repair reports

Environment: Linux sandbox, Python 3.12, FFmpeg 6.1.1 (libass, x264), yt-dlp 2026.10.26, faster-whisper installed. NOT Windows.

| Suite | Result |
|---|---|
| Baseline before edits (`pytest backend/tests`) | 227 passed |
| Final code, full backend suite | **248 passed**, 75 subtests, 518 s |
| New `tests/test_captions_render.py` (real FFmpeg, frame-pixel assertions) | 21 passed (included above) |
| Frontend `tsc --noEmit` | passed |
| Frontend `next build` | NOT RUN |

Existing tests changed: `test_vanta_e2e::test_03` (it asserted the buggy "captions on + no transcript = silent success" behaviour; now asserts failure, then success with captions off).

## Verified
Captions visible in exported MP4 (independent pixel diff vs captions-off render), absent when disabled; fail loudly with no transcript / no speech / unusable libass; works with an empty fontconfig; spaces/apostrophes/Unicode paths; 9:16, 1:1, 16:9; boxed, coloured and top-positioned styles; quote guard on 12 fixture clips; ratings migration preserves old rows.

## Not verified / not done
Real Windows run; `next build`; tests for `dataset_eval.py`, `quotes.py`, retry-includes-failed; YouTube ingestion changes; Whisper model run; thumbnails/metadata; scheduler; upload; job-state/UI audit; launcher audit; real human-labelled ranking evaluation (no claim of ranking improvement is made).

## Known limits
Frame check samples one time point per clip. Long sentence-level lines partly inside a clip are estimated splits. Synthetic (flite) speech used for test video.

# Update (session 2, 2026-10-29) - PARTIAL

| Item | Result |
|---|---|
| New `tests/test_remaining_repair.py` (dataset_eval, quotes, ratings migration, retry-includes-failed, transcript rebase) | 40 tests; 5 mutation checks each caught |
| `tsc --noEmit`, `next build` | passed |
| `tests/test_captions_render.py` after multi-point + fast-probe change | 21 passed, but took 447 s (partly contention; runtime not isolated) |
| `tests/test_check_captions.py` | see result line appended below |
| Windows `scripts\check_captions.bat` | NOT RUN on Windows |
| Full backend suite after this session | NOT RE-RUN |

Fixed: failed output validation raised FileNotFoundError (temp file unlinked before move). Changed: caption verification samples up to 4 moments.
Still not done: TODO 3-13 of docs/REMAINING_WORK_PROMPT.md.

Result line: `tests/test_check_captions.py` + `tests/test_remaining_repair.py` -> **56 passed** (388 s, Linux, FFmpeg 6.1.1).

## Phase 2c step 2 - ytdlp.py split (2026-11-04, session 7)

Files: `backend/app/clipstudio/ytdlp.py` (facade, 281 lines), `ytdlp_const.py`, `ytdlp_urls.py`, `ytdlp_errors.py`, `ytdlp_probe.py`, `ytdlp_proc.py` (new), `backend/tests/test_ytdlp_split.py`, `backend/tests/data/ytdlp_surface_snapshot.json` (new).

| Item | Status | Evidence / limit |
|---|---|---|
| Same module surface | VERIFIED (Linux) | 75 names (kind + normalised signature) compared with a snapshot taken from the original file: identical |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_ytdlp_split` -> 9 tests OK |
| Mutation checks | VERIFIED (Linux) | 5 mutations each failed >=1 test: re-export dropped, diagnostics bypassing facade `ffmpeg_info`, `base_command` bypassing `installed`, `--cookies` added, function copied not re-exported; code restored and re-verified |
| Existing patch targets still work | VERIFIED (Linux) | `test_ytdlp` 51 OK (same count as before the split), `test_links_api` 18 OK, `test_ingestion_audit` 5 OK |
| Whole backend, module by module | VERIFIED (Linux) | 21 modules OK (list in UPGRADE_STATUS.md); `test_captions_render` NOT run |
| `compileall -q backend`, pyflakes | VERIFIED (Linux) | compileall clean; pyflakes found 2 missing imports during the work, both fixed; the remaining "imported but unused" lines are intentional re-exports |
| Live YouTube download | NOT VERIFIED | sandbox cannot reach youtube.com; the split moved no network code but this was not run |
| Windows | NOT VERIFIED | not executed |

## Phase 2c step 3 - legacy renderer.py split (2026-11-04, session 7)

Files: `backend/app/renderer.py` (facade, 347 lines), `renderer_common/scenes/audio/validate/download/clips.py` (new), `backend/tests/test_renderer_split.py`, `backend/tests/data/renderer_surface_snapshot.json` (new). `pro_render.py` unchanged.

| Item | Status | Evidence / limit |
|---|---|---|
| Same module surface | VERIFIED (Linux) | 58 names (kind + normalised signature) identical to a snapshot of the original file |
| Guard test | VERIFIED (Linux) | `cd backend && PYTHONPATH=. python -m unittest tests.test_renderer_split` -> 8 tests OK |
| Mutation checks | VERIFIED (Linux) | 5 mutations each failed >=1 test; code restored and re-verified |
| Existing tests and patch targets | VERIFIED (Linux) | `test_core` 17 (patches `app.renderer.subprocess.run`, `_temporal_motion_score`), `test_pro` 18, `test_vanta_e2e` 12 OK |
| Whole backend, module by module | VERIFIED (Linux) | 22 modules OK; `test_captions_render` NOT run |
| Real AI-video-provider render | NOT VERIFIED | needs a provider and network |
| Windows | NOT VERIFIED | not executed |

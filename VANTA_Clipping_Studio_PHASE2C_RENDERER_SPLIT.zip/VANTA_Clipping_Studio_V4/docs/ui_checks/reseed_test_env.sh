printf '# my notes\r\nVANTA_YTDLP_ATTEMPTS=3\r\nVANTA_WHISPER_THREADS=4\r\nPEXELS_API_KEY=abcdefgh12345678\r\n' > /tmp/vd/test.env; rm -f /tmp/vd/test.env.bak

import re, sys, pathlib
from playwright.sync_api import sync_playwright
ENV = pathlib.Path("/tmp/vd/test.env")
results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (" :: " + str(extra) if extra else ""))
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1300, "height": 1800})
    errs = []
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("http://127.0.0.1:3000/")
    pg.locator("button, a, li, div", has_text=re.compile(r"^\W*Settings$")).last.click()
    pg.wait_for_selector("[data-testid=settings-fields]", timeout=15000)
    check("form loads", True)
    check("restart banner shown (saved != running)", pg.locator("[data-testid=restart-banner]").count() == 1)
    groups = [t.inner_text() for t in pg.locator("[data-testid=settings-fields] legend").all()]
    check("grouped by group", groups[:3] == ["Links", "Transcription", "Limits"] and "Secrets" in groups, groups)
    check("secret input is a password field", pg.locator("#f-PEXELS_API_KEY").get_attribute("type") == "password")
    check("secret value never in the page", "abcdefgh12345678" not in pg.content() and pg.locator("#f-PEXELS_API_KEY").input_value() == "")
    check("secret shows 'is set'", "is set" in pg.locator("[data-field=PEXELS_API_KEY]").inner_text())
    f = pg.locator("[data-field=VANTA_YTDLP_ATTEMPTS]").inner_text()
    check("saved vs running shown", "Saved: 3" in f and "Running: 2" in f, f.replace("\n", " | "))
    check("restart badge on the pending field", pg.locator("[data-field=VANTA_YTDLP_ATTEMPTS] [data-badge=restart]").count() == 1)
    check("no badge on an untouched field", pg.locator("[data-field=VANTA_YTDLP_TIMEOUT] [data-badge=restart]").count() == 0)
    # --- invalid value -> per-field 422, nothing written
    before = ENV.read_bytes()
    pg.fill("#f-VANTA_YTDLP_ATTEMPTS", "99")
    pg.fill("#f-VANTA_WHISPER_THREADS", "8")      # valid one in the same request: must NOT be saved (all-or-nothing)
    pg.click("[data-testid=save-settings]")
    pg.wait_for_selector("[data-error=VANTA_YTDLP_ATTEMPTS]", timeout=8000)
    check("per-field 422 error shown on the bad field", "between" in pg.locator("[data-error=VANTA_YTDLP_ATTEMPTS]").inner_text(), pg.locator("[data-error=VANTA_YTDLP_ATTEMPTS]").inner_text())
    check("no error on the valid field", pg.locator("[data-error=VANTA_WHISPER_THREADS]").count() == 0)
    check("nothing written after a 422", ENV.read_bytes() == before)
    check("typed edits kept after a 422", pg.input_value("#f-VANTA_WHISPER_THREADS") == "8")
    pg.screenshot(path="/tmp/shots/01_error.png", full_page=True)
    # --- valid save
    pg.fill("#f-VANTA_YTDLP_ATTEMPTS", "4")
    pg.click("[data-testid=save-settings]")
    pg.wait_for_function("() => !document.querySelector('[data-error]')", timeout=8000)
    pg.wait_for_timeout(600)
    txt = ENV.read_bytes().decode()
    check("valid save written, CRLF + comment kept", "VANTA_YTDLP_ATTEMPTS=4\r\n" in txt and "VANTA_WHISPER_THREADS=8\r\n" in txt and txt.startswith("# my notes\r\n"), repr(txt))
    check("backup file created", pathlib.Path("/tmp/vd/test.env.bak").is_file())
    check("saved value now shown", "Saved: 4" in pg.locator("[data-field=VANTA_YTDLP_ATTEMPTS]").inner_text())
    check("running value unchanged (honest)", "Running: 2" in pg.locator("[data-field=VANTA_YTDLP_ATTEMPTS]").inner_text())
    # --- toggle a bool + choice
    pg.check("#f-VANTA_ENABLE_YTDLP")
    pg.select_option("#f-VANTA_WHISPER_DEVICE", "cpu")
    check("save button counts changes", "Save 2 changes" in pg.locator("[data-testid=save-settings]").inner_text())
    pg.click("[data-testid=save-settings]"); pg.wait_for_timeout(800)
    txt = ENV.read_bytes().decode()
    check("bool + choice saved", "VANTA_ENABLE_YTDLP=1" in txt and "VANTA_WHISPER_DEVICE=cpu" in txt)
    # --- remove my override
    pg.click("[data-field=VANTA_WHISPER_THREADS] button:has-text('Remove my override')"); pg.wait_for_timeout(800)
    txt = ENV.read_bytes().decode()
    check("override removed from the file", "VANTA_WHISPER_THREADS" not in txt, repr(txt))
    check("field falls back to the default text", "default: 0" in pg.locator("[data-field=VANTA_WHISPER_THREADS]").inner_text())
    check("no remove button when no override", pg.locator("[data-field=VANTA_WHISPER_THREADS] button:has-text('Remove my override')").count() == 0)
    # --- secret: replace, then clear
    pg.fill("#f-ANTHROPIC_API_KEY", "sk-test-1234567890abcdef")
    pg.click("[data-testid=save-settings]"); pg.wait_for_timeout(800)
    check("secret written to file", "ANTHROPIC_API_KEY=sk-test-1234567890abcdef" in ENV.read_text())
    check("secret never echoed back into the page", "sk-test-1234567890abcdef" not in pg.content() and pg.locator("#f-ANTHROPIC_API_KEY").input_value() == "")
    pg.click("[data-field=PEXELS_API_KEY] button:has-text('Clear')"); pg.wait_for_timeout(800)
    check("Clear removes the secret line", "PEXELS_API_KEY" not in ENV.read_text())
    check("Clear button gone once cleared", pg.locator("[data-field=PEXELS_API_KEY] button:has-text('Clear')").count() == 0)
    # bad secret -> per-field error
    pg.fill("#f-REPLICATE_API_TOKEN", "bad key with spaces")
    pg.click("[data-testid=save-settings]"); pg.wait_for_selector("[data-error=REPLICATE_API_TOKEN]", timeout=8000)
    check("malformed secret rejected per field", True)
    check("rejected secret text not leaked into the error", "bad key with spaces" not in pg.locator("[data-error=REPLICATE_API_TOKEN]").inner_text())
    pg.click("button:has-text('Discard edits')")
    check("discard clears edits and errors", pg.locator("[data-error]").count() == 0 and pg.input_value("#f-REPLICATE_API_TOKEN") == "")
    pg.screenshot(path="/tmp/shots/02_final.png", full_page=True)
    # scheduler panel still present
    check("scheduler panel still rendered", pg.get_by_text("Local scheduler").count() >= 1)
    expected = [e for e in errs if "status of 422" in e]
    other = [e for e in errs if "status of 422" not in e]
    check("no unexpected console/page errors", not other, other[:3])
    check("only the 2 deliberate 422 responses were logged", len(expected) == 2, len(expected))
    b.close()
bad = [n for n, ok in results if not ok]
print("\n%d checks, %d failed" % (len(results), len(bad)))
sys.exit(1 if bad else 0)

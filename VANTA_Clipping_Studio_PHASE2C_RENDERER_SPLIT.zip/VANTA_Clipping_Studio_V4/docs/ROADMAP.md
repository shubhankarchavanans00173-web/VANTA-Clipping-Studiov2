# Status and what is left

## Done in V3
Studio Pro renderer (stock/animated visuals, neural voice, word-synced captions, transitions, ducking, loudness, thumbnails),
LLM script writer (Ollama/Claude, optional), long-form up to 10 min, YouTube OAuth + resumable upload, chapters, credits, `.env` config, tests.

## Not done / ideas (in priority order)
1. **Live verification of network features** (Pexels, edge-tts, YouTube upload, Ollama/Claude) with real credentials - written to the official contracts and mock-tested only.
2. Per-scene visual editing UI: pick a different stock clip, paste your own clip/image per scene, edit the search phrase in the form (the field exists in the data).
3. Speech-to-text for Video-to-Clips (auto captions on uploaded footage), e.g. `faster-whisper`.
4. Hook-first "cold open" template and branded intro/outro slots.
5. Batch queue / daily scheduler (create N videos from a topic list).
6. Pixabay/own-library footage sources, AI image generation per scene (Replicate/Flux) as an optional paid visual source.
7. Analytics pull-back from YouTube (views, retention) to tune titles.

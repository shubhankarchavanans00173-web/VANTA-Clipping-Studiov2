@echo off
setlocal
rem VANTA caption self-check. Renders a 5 s vertical sample (English + Hindi) through the REAL export code and reports
rem PASS/FAIL from a pixel comparison at several moments of the clip.
rem Exit code: 0 = PASS, 1 = FAIL, 2 = could not run.   Set VANTA_NO_PAUSE=1 to skip the final "pause" (for automation).
set "ROOT=%~dp0.."
cd /d "%ROOT%"
call "%ROOT%\_find_python.bat"
if not defined STUDIO_PYTHON goto :nopython
echo Using Python: %STUDIO_PYTHON%
where ffmpeg >nul 2>nul
if errorlevel 1 goto :noffmpeg
where ffprobe >nul 2>nul
if errorlevel 1 goto :noffprobe
"%STUDIO_PYTHON%" "%ROOT%\backend\check_captions.py" --out "%ROOT%\check_captions_output" %*
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" echo ==== PASS ====
if "%RC%"=="1" echo ==== FAIL - read the lines above. Sample files are in check_captions_output ====
if not "%RC%"=="0" if not "%RC%"=="1" echo ==== COULD NOT RUN - see the lines above ====
goto :done

:nopython
echo [!!] Backend Python environment not found. Run setup_backend.bat first, or set VANTA_PYTHON.
set "RC=2"
goto :done

:noffmpeg
echo [!!] ffmpeg not found on PATH. Install it with: winget install Gyan.FFmpeg   then reopen this window.
set "RC=2"
goto :done

:noffprobe
echo [!!] ffprobe not found on PATH. It ships with ffmpeg.
set "RC=2"
goto :done

:done
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

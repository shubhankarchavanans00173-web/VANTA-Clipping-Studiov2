@echo off
setlocal
rem VANTA local transcription self-check. Examples:
rem   scripts\check_transcription.bat                         status only (no network)
rem   scripts\check_transcription.bat --download tiny         asks before downloading about 75 MB
rem   scripts\check_transcription.bat --file "D:\talk.mp4"    transcribes the first 60 s and prints real timings
rem Exit code: 0 = OK, 1 = a step failed, 2 = cannot run.   Set VANTA_NO_PAUSE=1 to skip the final "pause".
set "ROOT=%~dp0.."
cd /d "%ROOT%"
call "%ROOT%\_find_python.bat"
if not defined STUDIO_PYTHON goto :nopython
echo Using Python: %STUDIO_PYTHON%
where ffmpeg >nul 2>nul
if errorlevel 1 goto :noffmpeg
"%STUDIO_PYTHON%" "%ROOT%\backend\check_transcription.py" %*
set "RC=%ERRORLEVEL%"
goto :done

:nopython
echo [!!] Backend Python environment not found. Run setup_backend.bat first, or set VANTA_PYTHON.
set "RC=2"
goto :done

:noffmpeg
echo [!!] ffmpeg not found on PATH. Install it with: winget install Gyan.FFmpeg   then reopen this window.
set "RC=2"
goto :done

:done
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

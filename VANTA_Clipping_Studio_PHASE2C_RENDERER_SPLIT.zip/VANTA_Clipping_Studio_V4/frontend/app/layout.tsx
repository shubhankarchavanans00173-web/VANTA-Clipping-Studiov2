import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {title:"Vanta — Universal AI Video Studio",description:"A local-first workspace for generating, editing, and exporting AI video."};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}

"use client";
import {WhyPanel} from "./WhyPanel";
import {useCallback, useEffect, useMemo, useRef, useState} from "react";
import {ACTIVE, KIND_LABEL, METHOD_LABEL, STATUS_LABEL, V, call, clock, del, patch, post, upload, type Candidate, type Job} from "./api";
import {FailureDetails} from "./FailureDetails";
import {LinkErrorBox} from "./LinkErrorBox";
import type {Ctx} from "./ctx";
import {ExportCard} from "./ExportCard";

const DEFAULT_RS = {aspect: "9:16", reframe: "blur", captions: true, template_id: "builtin-highlight", mode: "word_highlight", font_size_pct: 4.6, position: "bottom", margin_pct: 16,
  color: "#FFFFFF", highlight_color: "#FFC83C", max_words_per_line: 3, uppercase: true, background: false, keep_original_audio: true, volume: 1, music_id: "", music_name: "",
  music_volume: 0.15, ducking: true, remove_silence: false, silence_min_seconds: 0.7};
type RS = typeof DEFAULT_RS;

function loadRS(): RS {
  try { const raw = localStorage.getItem("vanta.rs"); if (raw) return {...DEFAULT_RS, ...JSON.parse(raw), music_id: "", music_name: ""}; } catch {}
  return DEFAULT_RS;
}

export function JobStrip({job, ctx}: {job?: Job; ctx: Ctx}) {
  if (!job) return null;
  const active = ACTIVE.has(job.status);
  if (!active && job.status !== "failed") return null;
  return (
    <div className="v-card" style={{borderColor: job.status === "failed" ? "#ff7d9466" : undefined}}>
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <div><span className={`v-badge ${job.status === "failed" ? "bad" : "pur"}`}>{STATUS_LABEL[job.status]}</span> <span className="v-muted">{KIND_LABEL[job.kind] || job.kind}</span></div>
        {active && <button className="v-btn sm" onClick={async () => { try { await post(`/jobs/${job.id}/cancel`); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { ctx.refresh(); } }}>Cancel</button>}
      </div>
      {job.status === "failed" ? (job.result?.error ? <LinkErrorBox err={job.result.error} /> : <><p className="v-err">{job.error}</p><FailureDetails job={job} /></>) : (
        <>
          <p className="v-muted v-small" style={{margin: "8px 0 6px"}}>{job.message}{job.progress != null ? ` · ${Math.round(job.progress * 100)}%` : ""}</p>
          <div className={`v-bar ${job.progress == null ? "ind" : ""}`}><i style={job.progress != null ? {width: `${Math.round(job.progress * 100)}%`} : undefined} /></div>
          {job.progress == null && <p className="v-dim v-small" style={{margin: "6px 0 0"}}>This step does not report a percentage, so none is shown.</p>}
        </>
      )}
    </div>
  );
}

function CandidateCard({c, sel, busy, onSelect, onChanged, getPlayhead, ctx}: {c: Candidate; sel: boolean; busy: boolean; onSelect: () => void; onChanged: () => void; getPlayhead: () => number; ctx: Ctx}) {
  const [s, setS] = useState(clock(c.start)), [e, setE] = useState(clock(c.end)), [open, setOpen] = useState(false);
  useEffect(() => { setS(clock(c.start)); setE(clock(c.end)); }, [c.start, c.end]);
  const [opt, setOpt] = useState<string | null>(null);   // optimistic status until the server confirms
  useEffect(() => { setOpt(null); }, [c.status]);
  const shown = opt ?? c.status;
  const approved = shown === "approved" || shown === "failed" || shown === "rendered" || shown === "queued" || shown === "rendering";
  const save = async (start: string | number, end: string | number) => {
    try { await patch(`/candidates/${c.id}`, {start, end}); onChanged(); } catch (x: any) { ctx.notify(x.message, "bad"); setS(clock(c.start)); setE(clock(c.end)); }
  };
  const setStatus = async (status: string) => { setOpt(status); try { await patch(`/candidates/${c.id}`, {status}); onChanged(); } catch (x: any) { setOpt(null); ctx.notify(x.message, "bad"); } };
  const schedule = async () => { try { await post("/scheduler/tasks", {candidate_id: c.id, settings: {}}); ctx.notify("Approved clip added to the disabled-by-default scheduler queue.", "ok"); } catch (x: any) { ctx.notify(x.message, "bad"); } };
  return (
    <div className={`v-cand ${sel ? "sel" : ""} ${c.status === "rejected" ? "rej" : ""}`}>
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <label className="v-check" style={{margin: 0}}>
          <input type="checkbox" checked={approved} disabled={busy || ["queued", "rendering"].includes(c.status)} onChange={ev => setStatus(ev.target.checked ? "approved" : "suggested")} />
          <span>{c.origin === "custom" ? "Custom clip" : `#${c.rank}`} {c.title ? `· ${c.title}` : ""}</span>
        </label>
        <div style={{textAlign: "right"}}>
          {c.score != null ? <div className="v-score" title={c.analysis?.score_meaning || "Heuristic ranking score. Not a prediction of views or virality."}>{c.score.toFixed(0)}<span className="v-dim v-small"> /100 relative rank</span></div> : <span className="v-dim v-small">no score</span>}
        </div>
      </div>
      <div className="v-row v-small" style={{margin: "6px 0"}}>
        <span className="v-badge pur">{METHOD_LABEL[c.method] || c.method}</span>
        <span className={`v-badge ${c.status === "rendered" ? "ok" : c.status === "failed" ? "bad" : c.status === "rejected" ? "" : "warn"}`}>{c.status}</span>
        {c.edited ? <span className="v-badge">edited</span> : null}
        <span className="v-dim">{(c.end - c.start).toFixed(1)}s</span>
      </div>
      {c.excerpt ? <div className="v-excerpt">“{c.excerpt.length > 220 ? c.excerpt.slice(0, 220) + "…" : c.excerpt}”</div> : null}
      {c.error ? <div className="v-err v-small">{c.error}</div> : null}
      <div className="v-row">
        <input className="v-input sm" value={s} onChange={x => setS(x.target.value)} onBlur={() => save(s, e)} onKeyDown={x => x.key === "Enter" && (x.target as HTMLInputElement).blur()} aria-label="Start time" disabled={busy} />
        <span className="v-dim">→</span>
        <input className="v-input sm" value={e} onChange={x => setE(x.target.value)} onBlur={() => save(s, e)} onKeyDown={x => x.key === "Enter" && (x.target as HTMLInputElement).blur()} aria-label="End time" disabled={busy} />
        <button className="v-btn sm" disabled={busy} title="Use the current video position as the start" onClick={() => save(getPlayhead(), c.end)}>start = playhead</button>
        <button className="v-btn sm" disabled={busy} title="Use the current video position as the end" onClick={() => save(c.start, getPlayhead())}>end = playhead</button>
      </div>
      <div className="v-row" style={{marginTop: 8}}>
        <button className="v-btn sm pri" onClick={onSelect}>▶ Preview</button>
        <button className="v-btn sm" onClick={() => setOpen(!open)}>{open ? "Hide" : "Why selected"}</button>
        {ctx.project?.has_transcript ? <a className="v-btn sm" href={`${V}/candidates/${c.id}/srt`} title="Download the transcript lines of this clip as an .srt, re-timed to start at 0:00">SRT</a>
          : <button className="v-btn sm" disabled title="No transcript is attached, so there is nothing to export">SRT</button>}
        {shown === "approved" ? <button className="v-btn sm" disabled={busy} title="Queue this approved clip for an opt-in local scheduler run. It will never upload to YouTube." onClick={schedule}>Schedule</button> : null}
        <button className="v-btn sm" disabled={busy || ["queued", "rendering"].includes(c.status)} onClick={() => setStatus(c.status === "rejected" ? "suggested" : "rejected")}>{c.status === "rejected" ? "Restore" : "Reject"}</button>
        <button className="v-btn sm bad" disabled={busy || ["queued", "rendering"].includes(c.status)} onClick={async () => { try { await del(`/candidates/${c.id}`); onChanged(); } catch (x: any) { ctx.notify(x.message, "bad"); } }}>Remove</button>
      </div>
      {open && <WhyPanel c={c} notify={ctx.notify} onChanged={onChanged} />}
    </div>
  );
}

export function CreateView({ctx}: {ctx: Ctx}) {
  const {project, health} = ctx;
  const videoRef = useRef<HTMLVideoElement>(null), rangeRef = useRef<{start: number; end: number} | null>(null);
  const [t, setT] = useState(0), [selId, setSelId] = useState<string | null>(null), [capPrev, setCapPrev] = useState<any>(null);
  const [transcript, setTranscript] = useState<any>(null);
  const [upPct, setUpPct] = useState<number | null>(null), [target, setTarget] = useState(30), [count, setCount] = useState(5), [doTranscribe, setDoTranscribe] = useState(true), [engineMode, setEngineMode] = useState<"auto" | "baseline">("auto"), [localRerank, setLocalRerank] = useState(true);
  const [rs, setRs] = useState<RS>(DEFAULT_RS), [templates, setTemplates] = useState<any[]>([]);
  const [customStart, setCustomStart] = useState(""), [customEnd, setCustomEnd] = useState("");
  useEffect(() => { setRs(loadRS()); }, []);
  useEffect(() => { try { localStorage.setItem("vanta.rs", JSON.stringify(rs)); } catch {} }, [rs]);
  useEffect(() => { call("/templates").then(setTemplates).catch(() => {}); }, []);
  const set = <K extends keyof RS>(k: K, v: RS[K]) => setRs(p => ({...p, [k]: v}));

  const pid = project?.id;
  const cands = project?.candidates || [];
  const jobs = project?.jobs || [];
  const busy = jobs.some(j => ACTIVE.has(j.status));
  const approved = cands.filter(c => c.status === "approved" || c.status === "failed");
  const sel = cands.find(c => c.id === selId) || null;
  const exportsHere = project?.exports || [];
  const needsDownload = !!project && project.source_type === "link" && !project.has_source;
  async function retryDownload() {
    if (!pid) return;
    try { const r = await post(`/projects/${pid}/download`); ctx.refresh(); ctx.notify(r.already_downloaded ? r.message : "Download started.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }

  const tKey = pid ? `${pid}:${project?.transcript_meta?.source}:${project?.transcript_meta?.segments}` : "";
  useEffect(() => {
    setTranscript(null);
    if (pid && project?.has_transcript) call(`/projects/${pid}/transcript`).then(setTranscript).catch(() => {});
  }, [tKey]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setSelId(null); setCapPrev(null); rangeRef.current = null; }, [pid]);
  useEffect(() => { if (sel) call(`/candidates/${sel.id}/captions-preview?max_words=${rs.max_words_per_line}`).then(setCapPrev).catch(() => setCapPrev(null)); else setCapPrev(null); }, [selId, sel?.start, sel?.end, project?.has_transcript, rs.max_words_per_line]); // eslint-disable-line react-hooks/exhaustive-deps

  const play = (c: Candidate) => {
    setSelId(c.id); const v = videoRef.current; if (!v) return;
    rangeRef.current = {start: c.start, end: c.end}; v.currentTime = c.start; v.play().catch(() => {});
  };
  const onTime = () => {
    const v = videoRef.current; if (!v) return; setT(v.currentTime);
    const r = rangeRef.current; if (r && v.currentTime >= r.end) { v.pause(); rangeRef.current = null; }
  };
  const getPlayhead = useCallback(() => Math.round((videoRef.current?.currentTime || 0) * 10) / 10, []);

  const caption = useMemo(() => {
    if (!sel || !capPrev?.events?.length || !rs.captions) return null;
    const ct = t - sel.start; if (ct < 0 || ct > sel.end - sel.start) return null;
    const ev = capPrev.events.find((e: any) => ct >= e.start && ct <= e.end + 0.05); if (!ev) return null;
    const up = (s: string) => rs.uppercase ? s.toUpperCase() : s;
    if (ev.words && rs.mode === "word_highlight") return <>{ev.words.map((w: any, i: number) => { const on = ct >= w.start && ct < (ev.words[i + 1]?.start ?? ev.end + 0.1); return on ? <b key={i}>{up(w.text)} </b> : <span key={i}>{up(w.text)} </span>; })}</>;
    return <>{up(ev.text)}</>;
  }, [sel, capPrev, t, rs.captions, rs.uppercase, rs.mode]);

  async function onUpload(video?: File | null) {
    if (!video) return;
    const form = new FormData(); form.append("file", video);
    setUpPct(0);
    try { const p = await upload("/projects/upload", form, f => setUpPct(f)); await ctx.refresh(); ctx.selectProject(p.id); ctx.notify(`“${p.name}” uploaded and checked with ffprobe. Press Analyze to find clips.`, "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); } finally { setUpPct(null); }
  }
  async function attachTranscript(f?: File | null) {
    if (!f || !pid) return; const form = new FormData(); form.append("file", f);
    try { const r = await upload(`/projects/${pid}/transcript`, form); ctx.notify(r.message, "ok"); ctx.refresh(); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  function renderSettingsPayload() {
    const style = {mode: rs.mode, font_size_pct: rs.font_size_pct, position: rs.position, margin_pct: rs.margin_pct, color: rs.color, highlight_color: rs.highlight_color, max_words_per_line: rs.max_words_per_line, uppercase: rs.uppercase, background: rs.background};
    return {aspect: rs.aspect, reframe: rs.reframe, captions: rs.captions && !!project?.has_transcript, caption_style: style, keep_original_audio: rs.keep_original_audio, volume: rs.volume,
      music_id: rs.music_id || undefined, music_volume: rs.music_volume, ducking: rs.ducking, remove_silence: rs.remove_silence, silence_min_seconds: rs.silence_min_seconds};
  }
  const inflight = useRef(false);   // blocks a second click while the first request is still on its way (double-click protection)
  async function once(fn: () => Promise<void>) {
    if (inflight.current) return;
    inflight.current = true;
    try { await fn(); } finally { inflight.current = false; }
  }
  async function analyze(autoRender = false) {
    if (!pid) return;
    await once(async () => {
    try {
      await post(`/projects/${pid}/analyze`, {target_duration: target, count, transcribe: doTranscribe, engine_mode: engineMode, local_llm: localRerank, auto_render: autoRender, render_settings: autoRender ? renderSettingsPayload() : {}});
      ctx.refresh();
      if (autoRender) ctx.notify("Auto Clip started: VANTA will rank moments and render the top suggestions automatically.", "ok");
    } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  async function addCustom() {
    if (!pid) return;
    await once(async () => {
      try { await post(`/projects/${pid}/candidates`, {start: customStart, end: customEnd}); setCustomStart(""); setCustomEnd(""); ctx.refresh(); ctx.notify("Custom clip added and approved.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  async function uploadMusic(f?: File | null) {
    if (!f) return; const form = new FormData(); form.append("file", f);
    try { const r = await upload("/music", form); setRs(p => ({...p, music_id: r.music_id, music_name: r.name})); ctx.notify("Music added.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  async function render() {
    if (!pid) return;
    const settings = renderSettingsPayload();
    await once(async () => {
      try { await post(`/projects/${pid}/render`, {candidate_ids: approved.map(c => c.id), settings}); ctx.refresh(); ctx.notify(`Rendering ${approved.length} approved clip(s).`, "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); }
    });
  }
  function pickTemplate(id: string) {
    const tpl = templates.find(x => x.id === id); set("template_id", id);
    if (tpl) setRs(p => ({...p, template_id: id, ...Object.fromEntries(Object.entries(tpl.style).filter(([k]) => k in DEFAULT_RS))} as RS));
  }

  const whisper = health?.transcription_engines?.find((e: any) => e.id === "faster-whisper");
  return (
    <>
      <h1 className="v-h1">Create Shorts</h1>
      <p className="v-sub">Auto Clip ranks the strongest available moments and renders the top suggestions into captioned vertical MP4s. It uses local heuristics and transcript/audio/scene signals—not a guarantee of virality. Nothing is published to YouTube automatically.</p>

      <div className="v-card" style={{marginBottom: 16}}>
        <div className="v-row" style={{justifyContent: "space-between"}}>
          <div className="v-row">
            <label className="v-btn pri">Upload video<input type="file" hidden accept="video/*,.mkv,.mov,.avi,.ts,.mpg,.mpeg" onChange={e => { onUpload(e.target.files?.[0]); e.target.value = ""; }} /></label>
            <label className={`v-btn ${pid ? "" : "disabled"}`} style={pid ? undefined : {opacity: .45, cursor: "not-allowed"}} title={pid ? "Attach or replace the transcript of the selected project, then re-analyze" : "Select or upload a project first"}>{project?.has_transcript ? "Replace transcript" : "Attach transcript"} (.srt .vtt .json)<input type="file" hidden disabled={!pid || busy} accept=".srt,.vtt,.json" onChange={e => { attachTranscript(e.target.files?.[0]); e.target.value = ""; }} /></label>
            <button className="v-btn" onClick={() => ctx.go("links")}>Use a video link…</button>
            {upPct != null && <span className="v-muted">Uploading {Math.round(upPct * 100)}%</span>}
          </div>
          <select className="v-select" value={pid || ""} onChange={e => ctx.selectProject(e.target.value || null)} aria-label="Project">
            <option value="">— choose a project —</option>
            {ctx.projects.map(p => <option key={p.id} value={p.id}>{p.name} ({STATUS_LABEL[p.status] || p.status})</option>)}
          </select>
        </div>
        {project && (
          <div className="v-row" style={{marginTop: 14}}>
            <div className="v-chips">{[15, 30, 45, 60].map(d => <button key={d} className={`v-chip ${target === d ? "on" : ""}`} onClick={() => setTarget(d)}>{d}s</button>)}</div>
            <label className="v-small v-muted">Suggestions <input className="v-input sm" style={{width: 56}} type="number" min={1} max={20} value={count} onChange={e => setCount(Math.max(1, Math.min(20, Number(e.target.value) || 1)))} /></label>
            <label className="v-check" style={{margin: 0}} title={whisper?.available ? "Free local transcription" : whisper?.detail}>
              <input type="checkbox" checked={doTranscribe} onChange={e => setDoTranscribe(e.target.checked)} /> Transcribe locally {whisper && !whisper.available ? <span className="v-badge warn">{whisper.installed === false ? "not installed" : "model needed — see AI Models"}</span> : <span className="v-badge ok">available</span>}
            </label>
            <label className="v-small v-muted" title="Multi-signal creates safe candidates. If Ollama is configured, the local model re-ranks them for meaning and context; otherwise the rule-based score is clearly retained.">Ranking <select className="v-input sm" value={engineMode} onChange={e => setEngineMode(e.target.value as "auto" | "baseline")}><option value="auto">Local-AI re-rank when ready</option><option value="baseline">Simple heuristic</option></select></label>
            <label className="v-check" style={{margin: 0}} title={health?.clip_engine?.local_llm?.available ? "Use the configured local Ollama model to re-rank suggestions" : (health?.clip_engine?.local_llm?.reason || "Configure Ollama in .env to enable model re-ranking.")}><input type="checkbox" checked={localRerank} disabled={engineMode === "baseline"} onChange={e => setLocalRerank(e.target.checked)} /> Local AI re-rank {health?.clip_engine?.local_llm?.available ? <span className="v-badge ok">ready</span> : <span className="v-badge">fallback</span>}</label>
            <button className="v-btn" disabled={busy || !project} onClick={() => analyze(false)}>{cands.length ? "Re-analyze" : "Analyze"}</button>
            <button className="v-btn pri" disabled={busy || !project} onClick={() => analyze(true)}>Auto Clip · Find & Render</button>
            {!project.has_transcript && <span className="v-small v-muted">No transcript yet — ranking will use audio/visual signals only (labelled).</span>}
          </div>
        )}
        {project?.error && !busy && (project.download_error ? <LinkErrorBox err={project.download_error} onRetry={retryDownload} /> : <p className="v-err">{project.error}</p>)}
        {needsDownload && !busy && !project?.download_error && <div className="v-row" style={{marginTop: 10}}><button className="v-btn pri" onClick={retryDownload}>Download video</button><span className="v-small v-muted">Linked video not on disk yet. A valid local copy is never downloaded twice.</span></div>}
      </div>

      <div className="v-stack" style={{marginBottom: 16}}><JobStrip job={jobs[0]} ctx={ctx} /></div>

      {!project ? <div className="v-empty">Upload a video or add a link to begin.</div> : (
        <div className="v-grid2">
          <div className="v-stack">
            <div className="v-card">
              <h3>Source preview</h3>
              {project.has_source ? (
                <div className="v-player"><video ref={videoRef} controls preload="metadata" src={`${V}/projects/${pid}/source`} onTimeUpdate={onTime} />{caption && <div className="v-cap">{caption}</div>}</div>
              ) : <div className="v-empty">{busy ? "Downloading… progress is shown above." : "The linked video is not on disk yet. Use Download video / Retry download, or upload the file instead."}</div>}
              {sel && <p className="v-small v-muted" style={{margin: "8px 0 0"}}>Previewing clip {clock(sel.start)}–{clock(sel.end)}. Caption overlay is an approximation of your caption style; the export is burned in by FFmpeg.{capPrev?.granularity === "sentence" ? " This transcript has sentence-level timing only, so words are not highlighted individually." : ""}</p>}
              {project.probe && <p className="v-small v-dim" style={{margin: "6px 0 0"}}>{project.probe.width}×{project.probe.height} · {project.probe.fps} fps · {clock(project.probe.duration)} · {project.probe.has_audio ? "audio" : "no audio"}</p>}
            </div>
            <div className="v-card">
              <h3>Transcript {transcript?.available && <span className="v-badge">{transcript.source}{transcript.word_level ? " · word timings" : " · sentence timings"}</span>}</h3>
              {transcript?.available ? (
                <div className="v-tr">{transcript.segments.map((s: any, i: number) => (
                  <button key={i} className={sel && s.end > sel.start && s.start < sel.end ? "in" : ""} onClick={() => { const v = videoRef.current; if (v) { rangeRef.current = null; v.currentTime = s.start; } }}><time>{clock(s.start)}</time><span>{s.text}</span></button>))}</div>
              ) : <div className="v-empty">No transcript. Attach an .srt/.vtt/.json file{whisper?.available ? " or enable local transcription and re-analyze" : ", or install faster-whisper for free local transcription"}.</div>}
            </div>
          </div>

          <div className="v-stack">
            <div className="v-card">
              <h3>Suggested clips · ranked</h3>
              {cands.length === 0 ? <div className="v-empty">{busy ? "Working…" : "No suggestions yet. Press Analyze or Auto Clip."}</div> : (
                <div className="v-stack">{cands.map(c => <CandidateCard key={c.id} c={c} sel={c.id === selId} busy={busy} onSelect={() => play(c)} onChanged={ctx.refresh} getPlayhead={getPlayhead} ctx={ctx} />)}</div>)}
              <p className="v-small v-dim" style={{margin: "10px 0 0"}}>Scores are relative rankings within this video, not predictions of views. Open “Why selected” to see the evidence and rate a clip. Tick a clip to approve it for export.</p>
              <details className="v-det"><summary>Add a custom clip</summary>
                <div className="v-row" style={{marginTop: 8}}>
                  <input className="v-input sm" placeholder="start 1:05" value={customStart} onChange={e => setCustomStart(e.target.value)} />
                  <input className="v-input sm" placeholder="end 1:40" value={customEnd} onChange={e => setCustomEnd(e.target.value)} />
                  <button className="v-btn sm" disabled={busy || !customStart || !customEnd} title={busy ? "A job is running for this project" : "Enter a start and an end time (for example 1:05 and 1:40)"} onClick={addCustom}>Add</button>
                </div>
              </details>
            </div>

            <div className="v-card">
              <h3>Clip settings</h3>
              <div className="v-row">
                <div><span className="v-label">Format</span><div className="v-chips">{["9:16", "1:1", "16:9"].map(a => <button key={a} className={`v-chip ${rs.aspect === a ? "on" : ""}`} onClick={() => set("aspect", a)}>{a}</button>)}</div></div>
                <div><span className="v-label">Reframing</span><div className="v-chips">
                  <button className={`v-chip ${rs.reframe === "blur" ? "on" : ""}`} onClick={() => set("reframe", "blur")}>Blurred background</button>
                  <button className={`v-chip ${rs.reframe === "center" ? "on" : ""}`} onClick={() => set("reframe", "center")}>Centre crop</button>
                  <button className="v-chip" disabled title="No subject detector is bundled in this build">Subject tracking (unavailable)</button></div></div>
              </div>
              <label className="v-check" title={project.has_transcript ? "" : "Attach an .srt/.vtt/.json transcript or run local transcription first"}><input type="checkbox" checked={rs.captions && project.has_transcript} disabled={!project.has_transcript} onChange={e => set("captions", e.target.checked)} /> Burn in captions {!project.has_transcript && <span className="v-dim v-small">(unavailable: no transcript attached — captions are never skipped silently, so attach one to enable them)</span>}</label>
              {rs.captions && project.has_transcript && (
                <div className="v-row" style={{alignItems: "flex-end"}}>
                  <div><span className="v-label">Template</span><select className="v-select" value={rs.template_id} onChange={e => pickTemplate(e.target.value)}>{templates.map(x => <option key={x.id} value={x.id}>{x.name}</option>)}</select></div>
                  <div><span className="v-label">Style</span><select className="v-select" value={rs.mode} onChange={e => set("mode", e.target.value)}><option value="word_highlight">Word highlight</option><option value="clean">Clean</option></select></div>
                  <div><span className="v-label">Position</span><select className="v-select" value={rs.position} onChange={e => set("position", e.target.value)}><option value="bottom">Bottom</option><option value="middle">Middle</option><option value="top">Top</option></select></div>
                  <div><span className="v-label">Size %</span><input className="v-input sm" type="number" step="0.2" min={2} max={10} value={rs.font_size_pct} onChange={e => set("font_size_pct", Number(e.target.value))} /></div>
                  <div><span className="v-label">Words/line</span><input className="v-input sm" type="number" min={1} max={10} value={rs.max_words_per_line} onChange={e => set("max_words_per_line", Number(e.target.value))} /></div>
                  <div><span className="v-label">Text</span><input type="color" value={rs.color} onChange={e => set("color", e.target.value)} /></div>
                  <div><span className="v-label">Highlight</span><input type="color" value={rs.highlight_color} onChange={e => set("highlight_color", e.target.value)} /></div>
                  <label className="v-check"><input type="checkbox" checked={rs.uppercase} onChange={e => set("uppercase", e.target.checked)} /> UPPERCASE</label>
                  <label className="v-check"><input type="checkbox" checked={rs.background} onChange={e => set("background", e.target.checked)} /> Box</label>
                </div>
              )}
              <details className="v-det" open><summary>Audio</summary>
                <label className="v-check"><input type="checkbox" checked={rs.keep_original_audio} onChange={e => set("keep_original_audio", e.target.checked)} /> Keep original audio</label>
                <div className="v-row"><label className="v-small v-muted">Volume <input className="v-input sm" type="number" step="0.1" min={0} max={3} value={rs.volume} onChange={e => set("volume", Number(e.target.value))} /></label>
                  <label className="v-check" style={{margin: 0}}><input type="checkbox" checked={rs.remove_silence} onChange={e => set("remove_silence", e.target.checked)} /> Remove silences ≥</label>
                  <input className="v-input sm" type="number" step="0.1" min={0.3} max={5} value={rs.silence_min_seconds} disabled={!rs.remove_silence} onChange={e => set("silence_min_seconds", Number(e.target.value))} /><span className="v-dim v-small">s</span></div>
                <div className="v-row" style={{marginTop: 8}}>
                  <label className="v-btn sm">{rs.music_id ? `Music: ${rs.music_name}` : "Add background music"}<input type="file" hidden accept="audio/*" onChange={e => { uploadMusic(e.target.files?.[0]); e.target.value = ""; }} /></label>
                  {rs.music_id && <button className="v-btn sm" onClick={() => setRs(p => ({...p, music_id: "", music_name: ""}))}>Remove</button>}
                  {rs.music_id && <><label className="v-small v-muted">Music vol <input className="v-input sm" type="number" step="0.05" min={0} max={1} value={rs.music_volume} onChange={e => set("music_volume", Number(e.target.value))} /></label>
                    <label className="v-check" style={{margin: 0}}><input type="checkbox" checked={rs.ducking} onChange={e => set("ducking", e.target.checked)} /> Duck under speech</label></>}
                </div>
              </details>
              <div className="v-row" style={{marginTop: 14, justifyContent: "space-between"}}>
                <span className="v-muted">{approved.length} approved clip(s) · {rs.aspect === "9:16" ? "1080×1920" : rs.aspect === "16:9" ? "1920×1080" : "1080×1080"} · 30 fps · H.264/AAC</span>
                <button className="v-btn pri" disabled={busy || approved.length === 0 || !project.has_source} title={busy ? "A job is running for this project" : !project.has_source ? "The source video is not on disk yet (download or upload it first)" : approved.length === 0 ? "Approve at least one suggestion first: nothing is exported without your approval" : "Render the approved clips"} onClick={render}>Render {approved.length || ""} approved clip(s)</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {exportsHere.length > 0 && (
        <div style={{marginTop: 22}}>
          <h3 className="v-sub" style={{textTransform: "uppercase", letterSpacing: ".08em", fontSize: 13}}>Exports for this project</h3>
          <div className="v-grid3">{exportsHere.map((e: any) => <ExportCard key={e.id} e={{...e, project_name: undefined, file_exists: true}} onChange={ctx.refresh} notify={ctx.notify} />)}</div>
        </div>
      )}
    </>
  );
}

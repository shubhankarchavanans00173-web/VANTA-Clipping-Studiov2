"use client";
import {useState} from "react";
import {call} from "./api";
import type {Ctx} from "./ctx";

export function reportText(d: any): string {
  const js = d.js_runtime || {};
  return [
    `VANTA ${d.app?.version} diagnostics`,
    `Python: ${d.python?.version} (${d.python?.executable})${d.python?.in_virtualenv ? " [virtualenv]" : " [NOT a virtualenv]"}`,
    `yt-dlp: ${d.yt_dlp?.installed ? d.yt_dlp.version : "NOT INSTALLED"}${d.yt_dlp?.age_days != null ? ` (${d.yt_dlp.age_days} days old)` : ""}; solver scripts (yt-dlp-ejs): ${d.yt_dlp?.ejs_version || "not installed"}`,
    `Platform links enabled (VANTA_ENABLE_YTDLP): ${d.yt_dlp?.enabled ? "yes" : "no"}`,
    `FFmpeg: ${d.ffmpeg?.version || "NOT FOUND"}; ffprobe: ${d.ffmpeg?.ffprobe ? "found" : "NOT FOUND"}`,
    `JavaScript runtime: ${js.available ? `${js.name} ${js.version} (${js.path})` : `none - ${js.note}`}`,
    `.env: ${d.env_file?.path} (${d.env_file?.exists ? "found" : "missing"})`,
    `Download folder: ${d.folders?.sources} writable=${d.folders?.writable} free=${d.folders?.free_bytes != null ? (d.folders.free_bytes / 1e9).toFixed(1) + " GB" : "?"}`,
    `Ready for platform downloads: ${d.ready ? "yes" : "NO"}`,
    ...(d.problems || []).map((p: string) => `PROBLEM: ${p}`), ...(d.warnings || []).map((w: string) => `WARNING: ${w}`),
  ].join("\n");
}

export function DiagnosticsPanel({ctx, autoRun}: {ctx: Ctx; autoRun?: boolean}) {
  const [d, setD] = useState<any>(null), [busy, setBusy] = useState(false);
  async function run() {
    setBusy(true);
    try { setD(await call("/diagnostics?refresh=true")); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { setBusy(false); }
  }
  const [started, setStarted] = useState(false);
  if (autoRun && !started) { setStarted(true); run(); }
  const row = (label: string, ok: boolean | null, text: string) => (
    <><dt>{label}</dt><dd className="v-small"><span className={`v-badge ${ok === null ? "" : ok ? "ok" : "warn"}`}>{ok === null ? "info" : ok ? "ok" : "attention"}</span> <span style={{wordBreak: "break-all"}}>{text}</span></dd></>);
  return (
    <div className="v-card" id="v-diagnostics">
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <h3 style={{margin: 0}}>Dependency diagnostics</h3>
        <div className="v-row">
          <button className="v-btn sm" disabled={busy} onClick={run}>{busy ? "Checking…" : d ? "Re-run" : "Run diagnostics"}</button>
          {d && <button className="v-btn sm" onClick={() => navigator.clipboard?.writeText(reportText(d)).then(() => ctx.notify("Report copied.", "ok"), () => ctx.notify("Could not copy; select the text manually.", "bad"))}>Copy report</button>}
        </div>
      </div>
      {!d ? <p className="v-muted v-small">Checks the Python environment, yt-dlp, FFmpeg, Node.js/JavaScript runtime and folders the backend is really using.</p> : (
        <>
          <dl className="v-kv" style={{marginTop: 10}}>
            {row("Python (backend)", true, `${d.python.version} · ${d.python.executable}`)}
            {row("yt-dlp", d.yt_dlp.installed, d.yt_dlp.installed ? `${d.yt_dlp.version}${d.yt_dlp.age_days != null ? ` · ${d.yt_dlp.age_days} days old` : ""} · run as “python -m yt_dlp”` : "not installed in this Python")}
            {row("Challenge solver (yt-dlp-ejs)", !!d.yt_dlp.ejs_version, d.yt_dlp.ejs_version || "not installed — Update yt-dlp installs it")}
            {row("Platform links", d.yt_dlp.enabled, d.yt_dlp.enabled ? "VANTA_ENABLE_YTDLP is on" : "VANTA_ENABLE_YTDLP is off")}
            {row("FFmpeg / ffprobe", d.ffmpeg.available, d.ffmpeg.version || "not found on PATH")}
            {row("JavaScript runtime", d.js_runtime.available, d.js_runtime.available ? `${d.js_runtime.name} ${d.js_runtime.version}` : d.js_runtime.note)}
            {row(".env file", d.env_file.exists, d.env_file.path)}
            {row("Download folder", d.folders.writable, `${d.folders.sources}${d.folders.free_bytes != null ? ` · ${(d.folders.free_bytes / 1e9).toFixed(1)} GB free` : ""}`)}
          </dl>
          {d.problems.map((p: string, i: number) => <p key={i} className="v-err v-small" style={{margin: "6px 0 0"}}>✗ {p}</p>)}
          {d.warnings.map((w: string, i: number) => <p key={i} className="v-muted v-small" style={{margin: "6px 0 0"}}>⚠ {w}</p>)}
          {d.problems.length === 0 && <p className="v-small" style={{margin: "8px 0 0"}}><span className="v-badge ok">ready</span> Everything needed for platform downloads was found. A video can still be unavailable, private or restricted.</p>}
        </>)}
    </div>
  );
}

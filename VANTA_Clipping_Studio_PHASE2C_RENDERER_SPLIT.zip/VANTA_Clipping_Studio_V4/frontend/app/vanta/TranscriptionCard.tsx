"use client";
import {useCallback, useEffect, useState} from "react";
import {call, del, post} from "./api";
import type {Ctx} from "./ctx";

/** Local transcription status + the explicit, confirmed model download (nothing is downloaded without the user's approval). */
export function TranscriptionCard({ctx}: {ctx: Ctx}) {
  const [st, setSt] = useState<any>(null), [err, setErr] = useState<string | null>(null), [pick, setPick] = useState<string>("");
  const load = useCallback(async () => {
    try { const s = await call("/transcription/status"); setSt(s); setErr(null); setPick(p => p || s.model); } catch (e: any) { setErr(e.message); }
  }, []);
  useEffect(() => { load(); }, [load]);
  const downloading = st?.download?.status === "downloading";
  useEffect(() => {
    if (!downloading) return;
    const t = setInterval(load, 1000);
    return () => clearInterval(t);
  }, [downloading, load]);
  useEffect(() => { if (st?.download?.status === "done") ctx.refresh(); }, [st?.download?.status]); // eslint-disable-line react-hooks/exhaustive-deps

  if (err) return <div className="v-card"><h3>Transcription</h3><p className="v-muted">Backend not reachable: {err}</p></div>;
  if (!st) return <div className="v-card"><h3>Transcription</h3><p className="v-muted">Loading…</p></div>;
  const m = st.models.find((x: any) => x.name === pick) || st.models[0];
  const dl = st.download;

  async function download() {
    if (!window.confirm(`Download the “${m.name}” model (about ${m.approx_mb} MB) from Hugging Face to\n${st.cache_dir}\n\nThis is a one-time download; transcription afterwards runs offline.`)) return;
    try { await post("/transcription/models/download", {model: m.name, confirm: true}); await load(); } catch (e: any) { ctx.notify(e.message, "bad"); }
  }
  async function cancel() { try { await post("/transcription/models/download/cancel"); await load(); } catch (e: any) { ctx.notify(e.message, "bad"); } }
  async function clearCache() { try { const r = await del("/transcription/cache"); ctx.notify(`Cleared ${r.cleared} saved transcript(s).`, "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); } }

  return (
    <div className="v-card"><h3>Transcription</h3>
      <p style={{margin: 0}}>
        <span className={`v-badge ${st.ready ? "ok" : "warn"}`}>{st.ready ? "ready" : !st.installed ? "not installed" : "model needed"}</span>{" "}
        <strong>faster-whisper</strong> <span className="v-dim v-small">free, runs locally{st.library_version ? ` · v${st.library_version}` : ""}</span></p>
      <p className="v-small v-muted" style={{margin: "4px 0"}}>{st.detail}</p>
      {st.installed && <p className="v-small v-dim" style={{margin: "4px 0"}}>Runs on: {st.device_reason}; precision {st.compute_type}. Active model: <strong>{st.model}</strong>{st.model_valid ? "" : " (invalid — see VANTA_WHISPER_MODEL)"}.</p>}
      {st.installed && (
        <div style={{display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", margin: "8px 0"}}>
          <select className="v-input sm" style={{minWidth: 230}} value={pick} onChange={e => setPick(e.target.value)} disabled={downloading}>
            {st.models.map((x: any) => <option key={x.name} value={x.name}>{x.name} · ~{x.approx_mb} MB{x.cached ? " · downloaded" : ""}</option>)}
          </select>
          {m.cached
            ? <span className="v-badge ok">downloaded</span>
            : <button className="v-btn" disabled={downloading} onClick={download}>Download (~{m.approx_mb} MB)…</button>}
          {downloading && <button className="v-btn" onClick={cancel}>Cancel download</button>}
        </div>)}
      {st.installed && m.note && <p className="v-small v-dim" style={{margin: "0 0 4px"}}>{m.name}: {m.note}. {m.name.endsWith(".en") ? "English only." : ""} To make it the default set VANTA_WHISPER_MODEL={m.name} in .env.</p>}
      {downloading && (
        <div style={{margin: "8px 0"}}>
          <div style={{height: 8, background: "#ffffff18", borderRadius: 4, overflow: "hidden"}}><div style={{height: "100%", width: `${Math.round((dl.progress || 0) * 100)}%`, background: "#7cf0b0"}} /></div>
          <div className="v-small v-muted">{dl.message}</div>
        </div>)}
      {dl.status === "failed" && <p className="v-small" style={{color: "#ff8a8a"}}>Download failed: {dl.error}</p>}
      {dl.status === "cancelled" && <p className="v-small v-muted">{dl.message}</p>}
      {dl.status === "done" && <p className="v-small v-muted">{dl.message}</p>}
      {!st.installed && <p className="v-small v-muted">Install it with <code>enable_local_transcription.bat</code> (or <code>pip install faster-whisper</code> in the backend environment), then restart the backend.</p>}
      <p className="v-small v-dim" style={{marginBottom: 0}}>Models are stored in <code>{st.cache_dir}</code>. Without a model, upload an .srt/.vtt/.json transcript. Word-by-word highlighting needs real word timestamps (faster-whisper or a JSON transcript that has them). Finished transcripts are reused when the identical video is analysed again.{" "}
        <a href="#" onClick={e => { e.preventDefault(); clearCache(); }}>Clear saved transcripts</a></p>
    </div>
  );
}

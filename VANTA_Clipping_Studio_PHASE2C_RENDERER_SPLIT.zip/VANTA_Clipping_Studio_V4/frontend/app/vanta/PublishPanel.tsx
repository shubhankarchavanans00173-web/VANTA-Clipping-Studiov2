"use client";
import {useCallback, useEffect, useState} from "react";
import {API, V, call, post} from "./api";

type Thumb = {name: string; time: number; url: string; sharpness: number; dark: boolean; recommended: boolean};
const put = (path: string, body: any) => call(path, {method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});

/** Thumbnail (real frames of the exported video) + title/description/hashtags. Nothing here publishes anything. */
export function PublishPanel({eid, notify}: {eid: string; notify: (m: string, k?: "ok" | "bad") => void}) {
  const [thumbs, setThumbs] = useState<Thumb[]>([]), [sel, setSel] = useState<any>(null), [busy, setBusy] = useState(false), [custom, setCustom] = useState("");
  const [title, setTitle] = useState(""), [desc, setDesc] = useState(""), [tags, setTags] = useState(""), [msg, setMsg] = useState<string | null>(null), [prov, setProv] = useState<any>(null);
  const load = useCallback(async () => {
    try {
      const t = await call(`/exports/${eid}/thumbnails`); setThumbs(t.candidates); setSel(t.selected);
      const m = await call(`/exports/${eid}/metadata`); setTitle(m.title || ""); setDesc(m.description || ""); setTags((m.hashtags || []).join(" ")); setProv(m.provenance || null);
    } catch (e: any) { notify(e.message, "bad"); }
  }, [eid, notify]);
  useEffect(() => { load(); }, [load]);

  async function find() { setBusy(true); try { const r = await post(`/exports/${eid}/thumbnails?count=5`); setThumbs(r.candidates); setSel(null); } catch (e: any) { notify(e.message, "bad"); } finally { setBusy(false); } }
  async function choose(body: any) { try { const r = await put(`/exports/${eid}/thumbnail`, body); setSel(r.selected); if (body.time !== undefined) { const t = await call(`/exports/${eid}/thumbnails`); setThumbs(t.candidates); } notify("Thumbnail chosen.", "ok"); } catch (e: any) { notify(e.message, "bad"); } }
  async function suggest() {
    try { const s = await post(`/exports/${eid}/metadata/suggest`); setMsg(s.message); if (s.available) { setTitle(s.title); setDesc(s.description); setTags(s.hashtags.join(" ")); } } catch (e: any) { notify(e.message, "bad"); }
  }
  async function save() {
    try { const r = await put(`/exports/${eid}/metadata`, {title, description: desc, hashtags: tags}); setProv(r.provenance); setTags(r.hashtags.join(" ")); notify("Details saved.", "ok"); } catch (e: any) { notify(e.message, "bad"); }
  }
  const copy = async () => { try { await navigator.clipboard.writeText(`${title}\n\n${desc}\n\n${tags}`.trim()); notify("Copied.", "ok"); } catch { notify("Copy is not available in this browser.", "bad"); } };

  return (
    <div style={{marginTop: 10}}>
      <h4 style={{margin: "0 0 6px"}}>Thumbnail</h4>
      <div className="v-row">
        <button className="v-btn sm" disabled={busy} onClick={find}>{thumbs.length ? "Find frames again" : "Find thumbnail frames"}</button>
        <span className="v-small v-dim">Real frames from this video. “Recommended” = sharpest non-dark frame (a technical measure, not a click prediction).</span>
      </div>
      {thumbs.length > 0 && (
        <div style={{display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(88px,1fr))", gap: 6, margin: "8px 0"}}>
          {thumbs.map(t => (
            <button key={t.name} onClick={() => choose({name: t.name})} title={`${t.time}s${t.dark ? " · dark frame" : ""}`} style={{padding: 0, border: sel?.name === t.name ? "2px solid #7cf0b0" : "1px solid #ffffff30", borderRadius: 6, background: "none", cursor: "pointer", position: "relative", overflow: "hidden"}}>
              <img src={API + t.url} alt={`frame at ${t.time}s`} style={{width: "100%", display: "block"}} />
              <span className="v-small" style={{position: "absolute", left: 3, bottom: 3, background: "#000a", padding: "0 4px", borderRadius: 3}}>{t.time}s{t.recommended ? " ★" : ""}</span>
            </button>))}
        </div>)}
      <div className="v-row">
        <input className="v-input sm" style={{width: 90}} placeholder="time (s)" value={custom} onChange={e => setCustom(e.target.value)} />
        <button className="v-btn sm" disabled={!custom || isNaN(Number(custom))} title={!custom ? "Type a time in seconds first" : "Use the frame at this time"} onClick={() => choose({time: Number(custom)})}>Use frame at time</button>
        {sel ? <a className="v-btn sm" href={`${V}/exports/${eid}/thumbnail`}>Download thumbnail</a> : <span className="v-small v-dim">Pick a frame to enable download.</span>}
      </div>

      <h4 style={{margin: "14px 0 6px"}}>Title, description, hashtags</h4>
      <div className="v-row"><button className="v-btn sm" onClick={suggest}>Suggest from transcript</button>
        <span className="v-small v-dim">Uses only the words spoken in this clip. Nothing is invented; with no transcript the fields stay empty.</span></div>
      {msg && <p className="v-small v-muted" style={{margin: "6px 0"}}>{msg}</p>}
      <label className="v-small v-muted">Title ({title.length}/100)<input className="v-input" style={{width: "100%"}} value={title} onChange={e => setTitle(e.target.value)} /></label>
      <label className="v-small v-muted">Description ({desc.length}/5000)<textarea className="v-input" rows={4} style={{width: "100%"}} value={desc} onChange={e => setDesc(e.target.value)} /></label>
      <label className="v-small v-muted">Hashtags (max 15, separated by spaces)<input className="v-input" style={{width: "100%"}} value={tags} onChange={e => setTags(e.target.value)} /></label>
      <div className="v-row" style={{marginTop: 6}}>
        <button className="v-btn sm pri" onClick={save}>Save details</button><button className="v-btn sm" onClick={copy}>Copy all</button>
        {prov && <span className="v-small v-dim">Saved: title from {prov.title}, description from {prov.description}, hashtags from {prov.hashtags}.</span>}
      </div>
    </div>
  );
}

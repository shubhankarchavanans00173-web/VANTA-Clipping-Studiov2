"use client";
import {useEffect, useState} from "react";
import {call} from "./api";
import type {Ctx} from "./ctx";
import {DiagnosticsPanel} from "./DiagnosticsPanel";
import {SettingsFields} from "./SettingsFields";

function SchedulerPanel({ctx}: {ctx: Ctx}) {
  const [s, setS] = useState<any>(null), [tasks, setTasks] = useState<any[]>([]), [busy, setBusy] = useState(false);
  const load = async () => {
    try { const [config, queue] = await Promise.all([call("/scheduler"), call("/scheduler/tasks")]); setS(config); setTasks(queue); }
    catch (e: any) { ctx.notify(e.message, "bad"); }
  };
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const save = async (patch: any) => {
    setBusy(true);
    try { const next = await call("/scheduler", {method: "PUT", headers: {"Content-Type": "application/json"}, body: JSON.stringify(patch)}); setS(next); await load(); ctx.notify("Scheduler settings saved.", "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); } finally { setBusy(false); }
  };
  const cancel = async (id: string) => {
    try { await call("/scheduler/tasks/" + id, {method: "DELETE"}); await load(); ctx.notify("Scheduled task removed.", "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); }
  };
  const runNow = async () => {
    setBusy(true);
    try { const r = await call("/scheduler/run-now", {method: "POST"}); await load(); ctx.refresh(); ctx.notify(r.dispatched ? "Queued local render batch started." : "No ready scheduled clips to run.", "ok"); }
    catch (e: any) { ctx.notify(e.message, "bad"); } finally { setBusy(false); }
  };
  if (!s) return <div className="v-card"><h3>Local scheduler</h3><p className="v-muted">Loading…</p></div>;
  return <div className="v-card" style={{marginTop: 16}}>
    <div className="v-row" style={{justifyContent: "space-between"}}><h3 style={{margin: 0}}>Local scheduler <span className={"v-badge " + (s.enabled && !s.paused ? "ok" : "")}>{s.enabled ? s.paused ? "paused" : "enabled" : "off"}</span></h3><span className="v-small v-muted">Never uploads to YouTube</span></div>
    <p className="v-small v-muted">Queue an approved clip from Create Shorts, then explicitly enable this daily local render scheduler. It is off by default and has a single-backend lock.</p>
    <div className="v-row">
      <label className="v-check"><input type="checkbox" checked={!!s.enabled} disabled={busy} onChange={e => save({enabled: e.target.checked})} /> Enable scheduled renders</label>
      <label className="v-check"><input type="checkbox" checked={!!s.paused} disabled={!s.enabled || busy} onChange={e => save({paused: e.target.checked})} /> Pause</label>
      <label className="v-small">Timezone <input className="v-input sm" value={s.timezone || "UTC"} onChange={e => setS({...s, timezone: e.target.value})} onBlur={() => save({timezone: s.timezone})} /></label>
      <label className="v-small">Daily time <input className="v-input sm" type="time" value={s.time_of_day || "09:00"} onChange={e => setS({...s, time_of_day: e.target.value})} onBlur={() => save({time_of_day: s.time_of_day})} /></label>
      <label className="v-small">Videos/run <input className="v-input sm" style={{width: 52}} type="number" min={1} max={10} value={s.videos_per_run ?? 1} onChange={e => setS({...s, videos_per_run: Number(e.target.value) || 1})} onBlur={() => save({videos_per_run: s.videos_per_run})} /></label>
      <label className="v-small">Retries <input className="v-input sm" style={{width: 52}} type="number" min={0} max={5} value={s.retry_limit ?? 1} onChange={e => setS({...s, retry_limit: Number(e.target.value) || 0})} onBlur={() => save({retry_limit: s.retry_limit})} /></label>
      <button className="v-btn sm" disabled={busy || s.paused} onClick={runNow}>Run queued clips now</button>
    </div>
    <div className="v-small v-muted" style={{marginTop: 10}}>Queue: {tasks.length ? tasks.map(t => t.candidate_id.slice(0, 8) + " " + t.status + (t.attempts ? " retry " + t.attempts : "")).join(" · ") : "empty"}</div>
    {tasks.some(t => ["ready", "dispatching"].includes(t.status)) && <div className="v-row" style={{marginTop: 6}}>{tasks.filter(t => ["ready", "dispatching"].includes(t.status)).map(t => <button className="v-btn sm bad" key={t.id} onClick={() => cancel(t.id)}>Remove {t.candidate_id.slice(0, 8)}</button>)}</div>}
  </div>;
}

export function SettingsView({ctx}: {ctx: Ctx}) {
  const [s, setS] = useState<any>(null);
  useEffect(() => { call("/settings").then(setS).catch(e => ctx.notify(e.message, "bad")); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const h = ctx.health;
  return (
    <>
      <h1 className="v-h1">Settings</h1>
      <p className="v-sub">Runtime information is read-only. The whitelisted settings below are saved to <code>.env</code> and apply after a restart; the local scheduler is managed separately.</p>
      <div className="v-grid2">
        <div className="v-card"><h3>System</h3>
          <dl className="v-kv"><dt>Backend</dt><dd>{h ? <span className={`v-badge ${h.status === "ok" ? "ok" : "warn"}`}>{h.status}</span> : <span className="v-badge bad">unreachable</span>} {h?.version}</dd>
            <dt>FFmpeg</dt><dd className="v-small">{h?.ffmpeg || "not found — install FFmpeg and restart"}</dd>
            <dt>Data folder</dt><dd className="v-small" style={{wordBreak: "break-all"}}>{s?.data_dir}</dd></dl></div>
        <div className="v-card"><h3>Limits</h3>
          <dl className="v-kv"><dt>Max upload</dt><dd>{s?.limits?.max_upload_mib} MiB</dd><dt>Max duration</dt><dd>{s?.limits?.max_duration_minutes} min</dd>
            <dt>Clip length</dt><dd>{s?.limits?.clip_seconds?.[0]}–{s?.limits?.clip_seconds?.[1]} s</dd><dt>Target lengths</dt><dd>{s?.limits?.target_durations?.join(", ")} s</dd></dl></div>
        <div className="v-card"><h3>Publishing</h3>
          <p style={{margin: 0}}><span className="v-badge">off</span> VANTA never publishes anything. The earlier text-to-video studio (with its optional YouTube upload) is still available as the <a href="/legacy" style={{textDecoration: "underline"}}>legacy studio</a>.</p></div>
        <div className="v-card"><h3>Appearance &amp; accounts</h3><p className="v-muted" style={{margin: 0}}>Theme switching and user accounts are not part of this local app.</p></div>
      </div>
      <SettingsFields ctx={ctx} />
      <SchedulerPanel ctx={ctx} />
      <div style={{marginTop: 16}}><DiagnosticsPanel ctx={ctx} /></div>
    </>
  );
}

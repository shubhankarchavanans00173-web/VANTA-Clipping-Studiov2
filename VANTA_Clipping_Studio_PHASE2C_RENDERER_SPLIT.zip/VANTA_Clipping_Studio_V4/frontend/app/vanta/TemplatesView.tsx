"use client";
import {useCallback, useEffect, useState} from "react";
import {call, del, post} from "./api";
import type {Ctx} from "./ctx";

export function TemplatesView({ctx}: {ctx: Ctx}) {
  const [items, setItems] = useState<any[]>([]);
  const [f, setF] = useState({name: "", mode: "word_highlight", position: "bottom", font_size_pct: 4.4, max_words_per_line: 3, color: "#FFFFFF", highlight_color: "#FFC83C", uppercase: false, background: false});
  const load = useCallback(() => { call("/templates").then(setItems).catch(e => ctx.notify(e.message, "bad")); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [load]);
  const {name, ...style} = f;
  async function save() { try { await post("/templates", {name, style}); setF({...f, name: ""}); load(); ctx.notify("Template saved. Choose it in Clip settings.", "ok"); } catch (e: any) { ctx.notify(e.message, "bad"); } }
  return (
    <>
      <h1 className="v-h1">Templates</h1>
      <p className="v-sub">Reusable caption styles. Pick one in Create Shorts → Clip settings.</p>
      <div className="v-grid2">
        <div className="v-card"><h3>Your templates</h3>
          <table className="v-table"><tbody>{items.map(t => <tr key={t.id}>
            <td><strong>{t.name}</strong> {t.builtin ? <span className="v-badge">built-in</span> : null}<div className="v-small v-muted">{t.style.mode === "clean" ? "Clean" : "Word highlight"} · {t.style.position} · {t.style.font_size_pct}% · {t.style.max_words_per_line} words/line</div></td>
            <td>{!t.builtin && <button className="v-btn sm bad" onClick={async () => { try { await del(`/templates/${t.id}`); load(); } catch (e: any) { ctx.notify(e.message, "bad"); } }}>Delete</button>}</td></tr>)}</tbody></table></div>
        <div className="v-card"><h3>New caption template</h3>
          <input className="v-input" style={{width: "100%"}} placeholder="Template name" value={f.name} onChange={e => setF({...f, name: e.target.value})} />
          <div className="v-row" style={{alignItems: "flex-end"}}>
            <div><span className="v-label">Style</span><select className="v-select" value={f.mode} onChange={e => setF({...f, mode: e.target.value})}><option value="word_highlight">Word highlight</option><option value="clean">Clean</option></select></div>
            <div><span className="v-label">Position</span><select className="v-select" value={f.position} onChange={e => setF({...f, position: e.target.value})}><option value="bottom">Bottom</option><option value="middle">Middle</option><option value="top">Top</option></select></div>
            <div><span className="v-label">Size %</span><input className="v-input sm" type="number" step="0.2" value={f.font_size_pct} onChange={e => setF({...f, font_size_pct: Number(e.target.value)})} /></div>
            <div><span className="v-label">Words/line</span><input className="v-input sm" type="number" value={f.max_words_per_line} onChange={e => setF({...f, max_words_per_line: Number(e.target.value)})} /></div>
            <div><span className="v-label">Text</span><input type="color" value={f.color} onChange={e => setF({...f, color: e.target.value})} /></div>
            <div><span className="v-label">Highlight</span><input type="color" value={f.highlight_color} onChange={e => setF({...f, highlight_color: e.target.value})} /></div>
          </div>
          <label className="v-check"><input type="checkbox" checked={f.uppercase} onChange={e => setF({...f, uppercase: e.target.checked})} /> UPPERCASE</label>
          <label className="v-check"><input type="checkbox" checked={f.background} onChange={e => setF({...f, background: e.target.checked})} /> Background box</label>
          <button className="v-btn pri" disabled={!f.name.trim()} title={!f.name.trim() ? "Give the template a name" : "Save these caption settings as a template"} onClick={save}>Save template</button></div>
      </div>
    </>
  );
}

"use client";
import type {LinkErr} from "./api";

/** Shows a structured download failure: what happened, what to do next, diagnostic lines, and the always-available local-file fallback. */
export function LinkErrorBox({err, onRetry, retrying, onDiagnostics}: {err: LinkErr | {message: string; code?: string; hint?: string | null; retryable?: boolean; details?: string[]}; onRetry?: () => void; retrying?: boolean; onDiagnostics?: () => void}) {
  const code = (err as any).code as string | undefined;
  return (
    <div className="v-card" style={{borderColor: "#ff7d9466", marginTop: 8}} role="alert">
      <div className="v-row" style={{justifyContent: "space-between"}}>
        <strong className="v-err">{err.message}</strong>
        {code ? <span className="v-badge bad" title="Machine-readable error code">{code}</span> : null}
      </div>
      {err.hint ? <p className="v-small" style={{margin: "6px 0 0"}}><b>What to do:</b> {err.hint}</p> : null}
      {err.details && err.details.length > 0 ? (
        <details className="v-det"><summary>Diagnostic details</summary>
          <pre className="v-small v-muted" style={{whiteSpace: "pre-wrap", margin: "6px 0 0"}}>{err.details.join("\n")}</pre></details>) : null}
      <div className="v-row" style={{marginTop: 10}}>
        {onRetry ? <button className="v-btn sm pri" disabled={retrying} onClick={onRetry}>{retrying ? "Retrying…" : "Retry download"}</button> : null}
        {onDiagnostics ? <button className="v-btn sm" onClick={onDiagnostics}>Run diagnostics</button> : null}
      </div>
      <p className="v-dim v-small" style={{margin: "8px 0 0"}}>Fallback that always works: download the video yourself (only if you are allowed to) and use <b>Create Shorts → Upload video</b>. VANTA never bypasses private, login, age, DRM or regional restrictions.</p>
    </div>
  );
}

"use client";
import {useState} from "react";
import {ACTIVE, KIND_LABEL, STATUS_LABEL, post} from "./api";
import type {Ctx} from "./ctx";
import {FailureDetails} from "./FailureDetails";

export function QueueView({ctx}: {ctx: Ctx}) {
  const [cancelling, setCancelling] = useState<Record<string, boolean>>({});   // a second click while the first is in flight is ignored
  async function cancel(id: string) {
    if (cancelling[id]) return;
    setCancelling(c => ({...c, [id]: true}));
    try { await post(`/jobs/${id}/cancel`); } catch (e: any) { ctx.notify(e.message, "bad"); } finally { await ctx.refresh(); setCancelling(c => ({...c, [id]: false})); }
  }
  const running = ctx.jobs.some(j => ACTIVE.has(j.status) && j.status !== "queued");
  return (
    <>
      <h1 className="v-h1">Processing Queue</h1>
      <p className="v-sub">Live job states from the backend. Jobs run one at a time so files are never written concurrently. Percentages appear only when the underlying step reports them.</p>
      <div className="v-card">
        {ctx.jobs.length === 0 ? <div className="v-empty">No jobs yet.</div> : (
          <table className="v-table"><thead><tr><th>Project</th><th>Job</th><th>State</th><th>Progress</th><th>Detail</th><th>Started</th><th></th></tr></thead><tbody>
            {ctx.jobs.map(j => <tr key={j.id}>
              <td>{j.project_name || j.project_id}</td><td>{KIND_LABEL[j.kind] || j.kind}</td>
              <td><span className={`v-badge ${j.status === "failed" ? "bad" : j.status === "completed" ? "ok" : ACTIVE.has(j.status) ? "pur" : "warn"}`}>{STATUS_LABEL[j.status] || j.status}</span></td>
              <td className="v-small">{j.progress != null ? `${Math.round(j.progress * 100)}%` : ACTIVE.has(j.status) ? "working…" : "–"}</td>
              <td className="v-small v-muted" style={{maxWidth: 380}}>{j.error ? <span className="v-err">{j.error}</span> : j.status === "queued" && running ? "Waiting for the running job to finish (jobs run one at a time)" : j.message}<FailureDetails job={j} /></td>
              <td className="v-small v-muted">{new Date(j.created_at).toLocaleTimeString()}</td>
              <td>{ACTIVE.has(j.status) && <button className="v-btn sm" disabled={!!cancelling[j.id]} onClick={() => cancel(j.id)}>{cancelling[j.id] ? "Cancelling…" : "Cancel"}</button>}</td></tr>)}
          </tbody></table>)}
      </div>
    </>
  );
}

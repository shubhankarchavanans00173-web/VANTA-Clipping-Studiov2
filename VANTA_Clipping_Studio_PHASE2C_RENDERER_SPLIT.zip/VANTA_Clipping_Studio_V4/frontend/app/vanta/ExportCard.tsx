"use client";
import {V, bytes, clock, del, type Export} from "./api";
import {PublishPanel} from "./PublishPanel";
import {YouTubeUploadPanel} from "./YouTubeUploadPanel";

export function ExportCard({e, onChange, notify}: {e: Export; onChange: () => void; notify: (m: string, k?: "ok" | "bad") => void}) {
  const cls = e.aspect === "1:1" ? "sq" : e.aspect === "16:9" ? "wide" : "";
  const ok = e.validation?.valid;
  async function remove() {
    if (!window.confirm("Delete this exported MP4 from disk?")) return;
    try { await del(`/exports/${e.id}`); notify("Export deleted.", "ok"); onChange(); } catch (x: any) { notify(x.message, "bad"); }
  }
  return (
    <div className={`v-card v-exp ${cls}`}>
      {e.file_exists === false ? <div className="v-empty">File no longer on disk</div> : <video controls preload="metadata" src={`${V}/exports/${e.id}/preview`} />}
      <div className="v-row" style={{marginTop: 10, justifyContent: "space-between"}}>
        <strong style={{wordBreak: "break-all"}}>{e.project_name ? e.project_name + " · " : ""}{clock(e.meta?.start)}–{clock(e.meta?.end)}</strong>
        <span className={`v-badge ${ok ? "ok" : "bad"}`}>{ok ? "ffprobe verified" : "validation failed"}</span>
      </div>
      <div className="v-small v-muted" style={{margin: "4px 0 8px"}}>
        {e.aspect} · {clock(e.duration)} · {bytes(e.size_bytes)} · captions: {e.meta?.captions_granularity === "word" ? "word-timed" : e.meta?.captions_granularity === "sentence" ? "sentence-level" : "none"}
        {e.meta?.silence_removed ? " · silences removed" : ""} · reframe: {e.meta?.reframe_used}
      </div>
      {e.meta?.caption_verification && <div className={`v-small ${e.meta.caption_verification.visible ? "v-muted" : ""}`} style={{margin: "0 0 8px"}}>Captions {e.meta.caption_verification.visible ? "verified in the exported frame" : "NOT verified"} ({e.meta.caption_verification.points_passed ?? 1} of {e.meta.caption_verification.points_checked ?? 1} checked moments passed; worst moment {Math.round((e.meta.caption_verification.match_ratio ?? 0) * 100)}% of caption pixels found)</div>}
      <div className="v-row">
        <a className="v-btn pri sm" href={`${V}/exports/${e.id}/download`}>Download MP4</a>
        {e.srt_path ? <a className="v-btn sm" href={`${V}/exports/${e.id}/captions`}>SRT</a> : null}
        <button className="v-btn sm bad" onClick={remove}>Delete</button>
      </div>
      <details className="v-det" style={{marginTop: 8}}><summary>Thumbnail &amp; details</summary><PublishPanel eid={e.id} notify={notify} /></details>
      <details className="v-det" style={{marginTop: 8}}><summary>YouTube upload</summary><YouTubeUploadPanel eid={e.id} notify={notify} /></details>
    </div>
  );
}

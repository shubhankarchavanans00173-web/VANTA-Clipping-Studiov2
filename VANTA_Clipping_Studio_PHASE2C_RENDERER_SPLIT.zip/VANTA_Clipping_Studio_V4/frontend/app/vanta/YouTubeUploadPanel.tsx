"use client";
import {useCallback, useEffect, useState} from "react";
import {call, post} from "./api";

type Review = {title?: string; description?: string; hashtags?: string[]};
type UploadState = {state?: string; progress?: number; privacy?: string; error?: string; video_id?: string; url?: string; studio_url?: string; notes?: string[]};

export function YouTubeUploadPanel({eid, notify}: {eid: string; notify: (m: string, k?: "ok" | "bad") => void}) {
  const [service, setService] = useState<any>(null), [review, setReview] = useState<Review>({}), [upload, setUpload] = useState<UploadState>({});
  const [privacy, setPrivacy] = useState("private"), [confirmed, setConfirmed] = useState(false), [busy, setBusy] = useState(false);
  const load = useCallback(async () => {
    try {
      const [s, m, u] = await Promise.all([call("/youtube/status"), call<Review>("/exports/" + eid + "/metadata"), call<UploadState>("/exports/" + eid + "/youtube")]);
      setService(s); setReview(m); setUpload(u); if (u.privacy) setPrivacy(u.privacy);
    } catch (e: any) { notify(e.message, "bad"); }
  }, [eid, notify]);
  useEffect(() => { load(); }, [load]);

  async function connect() {
    setBusy(true);
    try { const r = await post("/youtube/connect"); setService(r); notify("OAuth consent was opened locally. Finish it in the browser, then refresh this panel.", "ok"); }
    catch (e: any) { notify(e.message, "bad"); } finally { setBusy(false); }
  }
  async function send() {
    setBusy(true);
    try {
      const r = await post("/exports/" + eid + "/youtube/upload", {title: review.title || "", description: review.description || "", tags: review.hashtags || [], privacy, confirm: true});
      setUpload(r); setConfirmed(false); notify("Upload queued after your confirmation. It remains local until YouTube confirms it.", "ok");
    } catch (e: any) { notify(e.message, "bad"); } finally { setBusy(false); }
  }
  const complete = upload.state === "completed";
  return <div className="v-panel" style={{marginTop: 8}}>
    <div className="v-row" style={{justifyContent: "space-between"}}><strong>YouTube upload review</strong><span className={"v-badge " + (complete ? "ok" : "")}>{upload.state || "not started"}</span></div>
    <p className="v-small v-muted">This is a separate, backend-only OAuth action. It is never used by the scheduler. Private is selected by default, and every upload needs this checkbox again.</p>
    <div className="v-small"><strong>Title:</strong> {review.title || "No saved title — edit it under Thumbnail & details first."}</div>
    <div className="v-small" style={{whiteSpace: "pre-wrap", marginTop: 4}}><strong>Description:</strong> {review.description || "—"}</div>
    {review.hashtags?.length ? <div className="v-small" style={{marginTop: 4}}><strong>Tags:</strong> {review.hashtags.join(" ")}</div> : null}
    {!service?.connected && !complete ? <div className="v-row" style={{marginTop: 10}}><span className="v-small v-muted">{service?.connect_error || "Connect a local Google OAuth client before uploading."}</span><button className="v-btn sm" onClick={connect} disabled={busy || !service?.client_secret_found || !service?.libraries}>Connect YouTube</button></div> : null}
    {service?.connected && !complete && <><div className="v-row" style={{marginTop: 10}}><label className="v-small">Visibility&nbsp; <select className="v-input sm" value={privacy} onChange={e => setPrivacy(e.target.value)}><option value="private">Private</option><option value="unlisted">Unlisted</option><option value="public">Public</option></select></label></div>
      <label className="v-small" style={{display: "block", marginTop: 8}}><input type="checkbox" checked={confirmed} onChange={e => setConfirmed(e.target.checked)} /> I reviewed this export, title and visibility. Upload this one video now.</label>
      <button className="v-btn pri sm" style={{marginTop: 8}} onClick={send} disabled={busy || !confirmed}>Explicitly confirm upload</button></>}
    {upload.state === "uploading" || upload.state === "queued" ? <div className="v-small" style={{marginTop: 8}}>YouTube upload progress: {upload.progress ?? 0}% — refresh this panel for the latest state.</div> : null}
    {upload.error ? <div className="v-small" style={{marginTop: 8, color: "#ff92a4"}}>{upload.error}</div> : null}
    {complete && <div className="v-small" style={{marginTop: 8}}>YouTube confirmed video ID <code>{upload.video_id}</code>. {upload.url && <a href={upload.url} target="_blank" rel="noreferrer">Open video</a>} {upload.studio_url && <a href={upload.studio_url} target="_blank" rel="noreferrer">Open Studio</a>}</div>}
  </div>;
}

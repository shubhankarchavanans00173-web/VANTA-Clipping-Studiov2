export const API = process.env.NEXT_PUBLIC_API_URL || "http://127.0.0.1:8000";
export const V = API + "/api/vanta";

export type Job = {id: string; project_id: string; project_name?: string; kind: "analyze" | "render" | "download"; status: string; progress: number | null; message?: string; error?: string; result?: any; created_at: string; finished_at?: string};
export type Feature = {value: number | null; evidence: string; kind?: string};
export type Analysis = {
  engine: string; engine_version?: string; score_meaning?: string; signals_used: string[]; signals_not_available?: string[];
  features?: Record<string, Feature>; summary?: string; caveats?: string[]; hook?: string | null; payoff?: string | null;
  confidence?: {level: string; rubric_coverage?: number; boundary_quality?: number; uncertain?: string[]; definition?: string};
  needs_setup?: boolean; suggested_setup?: {start: number; setup: string} | null; alternates?: {start: number; end: number; score: number; note: string}[];
  penalties?: Record<string, number>; llm?: {status: string; model?: string; adjustment?: number; error?: string; ratings?: Record<string, any>} | null;
};
export type Candidate = {id: string; project_id: string; rank: number | null; start: number; end: number; score: number | null; method: string; reasons: string[]; excerpt: string; status: string; origin: string; edited: number; error?: string; title?: string; analysis?: Analysis | null; feedback?: string | null};
export type Export = {id: string; project_id: string; project_name?: string; candidate_id?: string; filename: string; aspect: string; duration: number; size_bytes: number; validation: any; meta: any; srt_path?: string; created_at: string; file_exists?: boolean};
export type LinkErr = {code: string; message: string; retryable: boolean; hint?: string | null; details?: string[]};
export type Project = {id: string; download_error?: LinkErr | null; name: string; source_type: string; source_ref?: string; status: string; error?: string; probe?: any; transcript_meta?: any; has_source: boolean; has_transcript: boolean; created_at: string; counts?: Record<string, number>; exports?: any; candidates?: Candidate[]; jobs?: Job[]};

/** Error from the backend that keeps the structured fields (code, hint, retryable, details). */
export class ApiError extends Error {
  code?: string; hint?: string | null; retryable?: boolean; details?: string[]; status?: number; errors?: Record<string, string>;
  constructor(message: string, extra?: Partial<LinkErr> & {status?: number}) { super(message); Object.assign(this, extra); }
}

export async function call<T = any>(path: string, init?: RequestInit): Promise<T> {
  let r: Response;
  try { r = await fetch(V + path, init); }
  catch { throw new Error(`Cannot reach the backend at ${API}. Start it with start_backend.bat (or python backend/run.py).`); }
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    const d = data.detail;
    const msg = typeof d === "string" ? d : Array.isArray(d) ? d.map((x: any) => x.msg).join("; ") : d?.message || `Request failed (${r.status})`;
    throw new ApiError(msg, {status: r.status, ...(d && typeof d === "object" && !Array.isArray(d) ? {code: d.code, hint: d.hint, retryable: d.retryable, details: d.details, errors: d.errors} : {})});
  }
  return data as T;
}
export const post = <T = any>(path: string, body?: any) => call<T>(path, {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body ?? {})});
export const patch = <T = any>(path: string, body: any) => call<T>(path, {method: "PATCH", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)});
export const del = <T = any>(path: string) => call<T>(path, {method: "DELETE"});

/** Multipart upload with real byte-level progress (fetch cannot report upload progress). */
export function upload<T = any>(path: string, form: FormData, onProgress?: (fraction: number) => void): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", V + path);
    xhr.upload.onprogress = e => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
    xhr.onerror = () => reject(new Error(`Cannot reach the backend at ${API}.`));
    xhr.onload = () => {
      let data: any = {};
      try { data = JSON.parse(xhr.responseText); } catch {}
      if (xhr.status >= 200 && xhr.status < 300) resolve(data);
      else { const d = data.detail; reject(new Error(typeof d === "string" ? d : d?.message || `Upload failed (${xhr.status})`)); }
    };
    xhr.send(form);
  });
}

export const clock = (s: number | null | undefined) => {
  if (s == null || !isFinite(s)) return "–";
  const m = Math.floor(s / 60), sec = s - m * 60;
  return `${m}:${sec.toFixed(1).padStart(4, "0")}`;
};
export const bytes = (n: number) => n > 1e9 ? (n / 1e9).toFixed(2) + " GB" : n > 1e6 ? (n / 1e6).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1e3)) + " KB";
export const ACTIVE = new Set(["queued", "downloading", "validating", "transcribing", "analyzing", "rendering"]);
export const STATUS_LABEL: Record<string, string> = {queued: "Queued", downloading: "Downloading", validating: "Validating", transcribing: "Transcribing", analyzing: "Analyzing", awaiting_approval: "Awaiting approval", rendering: "Rendering", completed: "Completed", failed: "Failed", cancelled: "Cancelled", new: "New", ready: "Ready"};
export const METHOD_LABEL: Record<string, string> = {"multi-signal": "Rule-based multi-signal", "signal-segmentation": "Audio/scene cues only (no transcript)", "transcript-heuristic": "Simple transcript heuristic", "audio-visual-heuristic": "Audio/visual heuristic (no transcript)", manual: "Your range"};
export const FEEDBACK_LABELS: [string, string][] = [["excellent", "Excellent"], ["good", "Good"], ["weak", "Weak"], ["incomplete", "Incomplete"], ["repetitive", "Repetitive"], ["missing_context", "Missing context"]];
export const FEATURE_LABEL: Record<string, string> = {hook: "Hook", payoff: "Payoff", standalone_clarity: "Standalone clarity", story_completeness: "Completeness", information_value: "Information value", opening_quality: "Opening", ending_quality: "Ending", duration_fit: "Duration fit", caption_readability: "Caption readability", emotion: "Emotional wording", energy_dynamics: "Loudness variation", speech_activity: "Speech activity", visual_activity: "Scene cuts", pause_before_payoff: "Pause before payoff", context_dependency: "Context dependency (penalty)", repetition: "Repetition (penalty)", low_value_content: "Intro/outro/filler (penalty)"};
export const KIND_LABEL: Record<string, string> = {analyze: "Analyze", render: "Render", download: "Download"};

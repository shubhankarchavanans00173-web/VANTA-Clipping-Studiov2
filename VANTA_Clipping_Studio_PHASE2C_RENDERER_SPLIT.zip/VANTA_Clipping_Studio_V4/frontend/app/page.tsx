"use client";

import {useCallback, useEffect, useRef, useState} from "react";
import "./vanta/vanta.css";
import {ACTIVE, call, type Job, type Project} from "./vanta/api";
import type {Ctx} from "./vanta/ctx";
import {CreateView} from "./vanta/CreateView";
import {LinksView} from "./vanta/LinksView";
import {ProjectsView} from "./vanta/ProjectsView";
import {QueueView} from "./vanta/QueueView";
import {ExportsView} from "./vanta/ExportsView";
import {TemplatesView} from "./vanta/TemplatesView";
import {ModelsView} from "./vanta/ModelsView";
import {SettingsView} from "./vanta/SettingsView";

const NAV: [string, string, string][] = [["create", "✦", "Create Shorts"], ["links", "⛓", "Video Links"], ["projects", "▤", "My Projects"], ["queue", "⟳", "Processing Queue"],
  ["exports", "⇩", "Exports"], ["templates", "❖", "Templates"], ["models", "◈", "AI Models"], ["settings", "⚙", "Settings"]];

export default function Vanta() {
  const [section, setSection] = useState("create"), [health, setHealth] = useState<any>(null), [projects, setProjects] = useState<Project[]>([]), [jobs, setJobs] = useState<Job[]>([]);
  const [project, setProject] = useState<Project | null>(null), [selected, setSelected] = useState<string | null>(null);
  const [toast, setToast] = useState<{m: string; k: "ok" | "bad"} | null>(null), [offline, setOffline] = useState(false);
  const selRef = useRef<string | null>(null), timer = useRef<any>(null);
  selRef.current = selected;

  const notify = useCallback((m: string, k: "ok" | "bad" = "ok") => { setToast({m, k}); clearTimeout(timer.current); timer.current = setTimeout(() => setToast(null), k === "bad" ? 9000 : 5000); }, []);
  const seq = useRef(0);
  const refresh = useCallback(async () => {
    const mine = ++seq.current;   // overlapping refreshes: only the newest response may update the screen (no stale overwrite)
    try {
      const [ps, js] = await Promise.all([call<Project[]>("/projects"), call<Job[]>("/jobs?limit=100")]);
      const id = selRef.current;
      let proj: Project | null = null, gone = false;
      if (id) { try { proj = await call<Project>(`/projects/${id}`); } catch (e: any) { if (e?.status === 404) gone = true; else throw e; } }
      if (mine !== seq.current) return;
      setProjects(ps); setJobs(js); setOffline(false);
      if (id && !gone) setProject(proj); else { setProject(null); if (gone) setSelected(null); }
    } catch { if (mine === seq.current) setOffline(true); }
  }, []);
  const selectProject = useCallback((id: string | null) => {
    setSelected(id); selRef.current = id;
    try { if (id) localStorage.setItem("vanta.project", id); else localStorage.removeItem("vanta.project"); } catch {}
    refresh();
  }, [refresh]);

  useEffect(() => { call("/health").then(setHealth).catch(() => setOffline(true)); try { const id = localStorage.getItem("vanta.project"); if (id) { setSelected(id); selRef.current = id; } } catch {} refresh(); }, [refresh]);
  const anyActive = jobs.some(j => ACTIVE.has(j.status));
  useEffect(() => { const t = setInterval(refresh, anyActive ? 1500 : 6000); return () => clearInterval(t); }, [refresh, anyActive]);

  const ctx: Ctx = {health, projects, jobs, project, selectProject, refresh, notify, go: setSection};
  const active = jobs.filter(j => ACTIVE.has(j.status)).length;
  const View = {create: CreateView, links: LinksView, projects: ProjectsView, queue: QueueView, exports: ExportsView, templates: TemplatesView, models: ModelsView, settings: SettingsView}[section] || CreateView;

  return (
    <div className="v-app">
      <aside className="v-side">
        <div className="v-brand"><div className="v-logo">V</div><div>VANTA<small>Clipping Studio</small></div></div>
        {NAV.map(([id, icon, label]) => (
          <button key={id} className={`v-nav ${section === id ? "on" : ""}`} onClick={() => setSection(id)}><span aria-hidden>{icon}</span>{label}{id === "queue" && active > 0 ? <span className="n">{active}</span> : null}</button>))}
        <div className="v-side-foot">Human approval before every export.<br />Never auto-publishes.<br /><a href="/legacy">Legacy text-to-video studio</a></div>
      </aside>
      <main className="v-main">
        {offline && <div className="v-card" style={{borderColor: "#ff7d9466", marginBottom: 16}}><strong>Backend not reachable.</strong> <span className="v-muted">Start it with <code>start_backend.bat</code> (or <code>python backend/run.py</code>) and keep it running.</span></div>}
        {health && health.status !== "ok" && <div className="v-card" style={{borderColor: "#ffc65c66", marginBottom: 16}}><strong>FFmpeg is missing.</strong> <span className="v-muted">Install FFmpeg (e.g. <code>winget install Gyan.FFmpeg</code>), reopen the terminal and restart the backend.</span></div>}
        <View ctx={ctx} />
      </main>
      {toast && <div className={`v-toast ${toast.k}`} role="status" onClick={() => setToast(null)}>{toast.m}</div>}
    </div>
  );
}

@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON ( echo Python 3.11+ backend environment not found. Run setup_backend.bat first. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
if "%~1"=="" (
  "%STUDIO_PYTHON%" backend\diagnose.py
) else (
  "%STUDIO_PYTHON%" backend\diagnose.py --test-url %1
)
set "RC=%ERRORLEVEL%"
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo VANTA - Enable free local transcription (faster-whisper)
echo ============================================================
echo Installs the faster-whisper LIBRARY into the SAME Python environment the backend uses.
echo It does NOT download a speech model: you approve that separately in AI Models
echo (or with scripts\check_transcription.bat --download small). No paid services.
echo.
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON (
  echo Could not find the backend Python environment. Run setup_backend.bat first.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
echo Backend Python: %STUDIO_PYTHON%
"%STUDIO_PYTHON%" -m pip install --upgrade --upgrade-strategy only-if-needed "faster-whisper>=1.0"
if errorlevel 1 (
  echo Failed to install faster-whisper. Check your internet connection. Nothing else was changed.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
echo.
"%STUDIO_PYTHON%" backend\check_transcription.py
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo Transcription self-check failed. The package remains installed; read the output above.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  endlocal & exit /b %RC%
)
echo.
echo Restart VANTA (stop_all.bat, then start_all.bat), then open AI Models to download a model.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b 0

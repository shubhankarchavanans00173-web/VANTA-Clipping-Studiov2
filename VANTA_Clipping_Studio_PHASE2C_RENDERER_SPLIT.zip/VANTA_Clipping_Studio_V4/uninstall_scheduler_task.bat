@echo off
setlocal
rem Removes only the per-user VANTA backend startup task made by install_scheduler_task.bat.
where schtasks >nul 2>nul || (
  echo Windows Task Scheduler command was not found.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
schtasks /Delete /TN "VANTA Clipping Studio Backend" /F
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo The task was not removed (it may not exist or belong to another user).
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

# VANTA Clipping Studio - CONTINUATION PROMPT (single current file)

Replaces the four older CONTINUATION_PROMPT*.md files (merged on 2026-11-03; updated session 7, after the renderer split). Paste this into a new session together with the project zip.
Act as senior Python/FastAPI, Next.js/TypeScript, FFmpeg, QA and Windows engineer. CONTINUE the existing project (folder `VANTA_Clipping_Studio_V4`: FastAPI backend in `backend/app/clipstudio/` mounted at `/api/vanta`, SQLite, FFmpeg, Next.js 14 frontend in `frontend/app/vanta/`; the older text-to-video studio lives at `/legacy` and must keep working). Do not rebuild it.

READ FIRST: `README.md`, `UPGRADE_STATUS.md`, `docs/FINAL_TEST_REPORT.md`, `docs/ROADMAP.md`, `docs/INTELLIGENT_CLIPS.md`, `.env.example`. Then give a short summary and plan before changing code if the user has not already approved a plan.

## Standing rules
1. Human approval before every export or upload. Nothing publishes automatically. Never weaken this.
2. No paid API calls (use the cost gate in `clipstudio/cost.py`), no network calls in tests, no model downloads without explicit approval. Secrets stay in the backend, never in a zip, report or log.
3. Never bypass DRM, bot checks, login, age or region limits (a test forbids cookie/geo/login flags). Show clear errors instead.
4. Be honest: label every result VERIFIED (exact command + output), PARTIAL, or NOT VERIFIED. Never claim live YouTube download, OAuth upload, Whisper on a real model, Windows `.bat` execution, or browser playback worked unless it was actually run. No ranking-quality claims without human-labelled data. Never fabricate previews, progress or exports.
5. Small steps; back up before editing; keep working code (preserve the original ranker and user data). After each step run the relevant test modules, `python -m compileall -q backend`, and for frontend changes `npx tsc --noEmit` and `npm run build`.
6. Add tests for every behaviour change and mutation-check them (break the code, confirm a test fails). Test the heuristic against a failing case, not only a passing one.
7. Update README.md, UPGRADE_STATUS.md and docs/FINAL_TEST_REPORT.md at the end of each phase with accurate status.
8. Before zipping, delete from the package copy: `.env`, cookies, tokens, `data/secrets`, `data/jobs.db`, `data/cache`, `data/vanta`, `data/outputs/e2e*`, `check_captions_output`, `verify_report.txt`, `__pycache__`, `node_modules`, `.next`.

## Working method (sandbox lessons)
* Tool calls time out at ~300 s: run long suites detached (`nohup setsid bash -c '... > /tmp/log 2>&1' &`) and poll; run tests per module (`cd backend && PYTHONPATH=. python -m unittest tests.test_core`). `test_captions_render` is the slowest.
* A venv with `pip install fastapi uvicorn pydantic Pillow python-multipart httpx pytest yt-dlp edge-tts google-api-python-client google-auth-oauthlib` is enough; ffmpeg/ffprobe/node exist in the sandbox.
* The sandbox cannot run Windows `.bat` files, resolve youtube.com, reach Hugging Face, or decode H.264 in a browser. Anything touching those is PARTIAL / NOT VERIFIED plus a checklist for the user.

## Do not reintroduce
* Whole-stderr regex matching in `ytdlp.py` (classify from `ERROR:` lines only), PATH lookup of yt-dlp, or a catch-all "outdated" message. yt-dlp runs only as `<backend python> -m yt_dlp`.
* `if ... & ...` chains in `.bat` files for multi-step logic (use labels). Always `call _find_python.bat` for the interpreter.

## Known limits to keep documented
Scores are heuristic rankings, not predictions. No subject tracking (blurred background or centre crop). Without word timings captions are sentence-level. Jobs run one at a time on purpose. Rendering is CPU-bound. After a restart render/download jobs resume (capped); analysis jobs are marked Failed.

## STATE (update this block every session)
* Sessions 1-5: see `UPGRADE_STATUS.md` (links, local transcription with stub model only, job-state audit, thumbnails/metadata, scheduler, YouTube upload with mocks only, launcher audit, FINAL2 zip).
* Session 6, Phase 1 DONE (Linux-verified only): `verify_all.bat` + `backend/verify_all.py` + `backend/tests/test_verify_all.py` (26 tests, 2 mutations caught). The `.bat` itself and the Windows command-line builder are NOT executed on Windows.
* Session 6, Phase 2a DONE (Linux-verified): resumable render/download jobs (`db.recover_interrupted`, `tests/test_resume.py`, 14 tests, mutations caught). `VANTA_RESUME_JOBS`, `VANTA_MAX_RESUMES` in `.env.example`.
* Session 6, Phase 2b backend DONE (Linux-verified): `clipstudio/envsettings.py`, `GET/PUT /settings/fields`, `tests/test_envsettings.py` (24 tests, 4 mutations caught). UI form NOT built.
* Session 6, Phase 2b-UI DONE (Linux-verified): `frontend/app/vanta/SettingsFields.tsx` mounted in `SettingsView`; `ApiError.errors` keeps per-field 422 messages. `npx tsc --noEmit` and `npm run build` pass; `docs/ui_checks/settings_clickthrough.py` (Playwright, 32 checks) passes; 3 UI mutations caught. Real Windows restart NOT verified.
* Session 7, Phase 2c step 1 DONE (Linux-verified): `router.py` split into `clipstudio/routes/*.py` (system, scheduling, projects, transcription, candidates, render_jobs, exports, publishing, templates, cloud_ai, common) with `router.py` as a thin assembler that re-exports every old name (incl. private helpers) so imports and `mock.patch("app.clipstudio.router.youtube_upload.status")` still work. Guard: `tests/test_router_split.py` (6 tests) + `tests/data/vanta_routes_snapshot.json` taken from the ORIGINAL file; 3 mutations caught; whole-app OpenAPI identical before/after except one cosmetic schema component name. All backend modules run separately and OK except `test_captions_render` (not run). A pre-existing stale test (`test_final2_e2e_light`) was fixed. Frontend untouched, not rebuilt.
* Session 7, Phase 2c step 2 DONE (Linux-verified): `ytdlp.py` (670 lines) is a 281-line facade + `ytdlp_const/urls/errors/probe/proc.py`. KEY RULE LEARNED: anything tests patch via `mock.patch.object(ytdlp, X)` (installed, version, base_command, diagnostics, download, update, check_disk, and the `subprocess`/`shutil`/`time` references) must stay in `ytdlp.py`, because a patch only reaches callers that look the name up in that module; only pure/leaf code was moved, and every old name (incl. private) is re-exported. Guard: `tests/test_ytdlp_split.py` (9 tests) + `tests/data/ytdlp_surface_snapshot.json` taken from the ORIGINAL; 5 mutations caught. All 21 backend modules OK (test_captions_render not run). pyflakes caught 2 missing imports in the new modules - always run it on new modules (`pip install pyflakes`).
* Session 7, Phase 2c step 3 DONE (Linux-verified): legacy `app/renderer.py` (1002 lines) is a 347-line facade + `renderer_common/scenes/audio/validate/download/clips.py`; same rule as ytdlp (functions tests patch, e.g. `_temporal_motion_score`, and their callers stay in the facade; everything else re-exported). Guard `tests/test_renderer_split.py` (8 tests) + `tests/data/renderer_surface_snapshot.json`; 5 mutations caught; all 22 backend modules OK (test_captions_render not run). A dependency map via `ast` (which top-level name uses which) made the cut acyclic: do that first for every split.
* NEXT: 2c remaining splits, ONE file per step, same method: `frontend/app/vanta/CreateView.tsx` (needs `npx tsc --noEmit`, `npm run build`, `docs/ui_checks/*_clickthrough.py` with `/usr/bin/python3`; restart `next start` between mutation runs), then `frontend/app/legacy/page.tsx` (very long lines). Then 2d (Queue UI "continued automatically as job X" link, click it through in a browser). Then Phase 3. The user still owes `verify_report.txt` from `verify_all.bat`; fix every FAIL in it first if pasted.
* Sandbox lessons (session 7): newer FastAPI (0.162) includes sub-routers lazily, so `app.routes` hides them and `router.routes` has only the include entries; snapshot the API with `app.openapi()` instead. Run the module list from a script detached (`nohup setsid`) and poll; all backend modules together take about 8 minutes. If the user says "do it however you want, just give me the zip and prompt", pick the next step, finish it with tests, update the docs and this file, and hand over the cleaned zip.
* Sandbox lessons added: for browser checks use `/usr/bin/python3` (has Playwright; the project venv does not). Restart `next start` by killing `[n]ext-server` (never `pkill -f next-server` inside a command that contains that text - it kills your own shell) and wait for the port; otherwise a stale server silently serves the old build and mutation runs are invalid. Seed a temp env with `VANTA_ENV_FILE`, `STUDIO_DATA_DIR`.

## PHASES (ask the user before starting each one; at the end of each give: files changed, exact commands and results, a VERIFIED/PARTIAL/NOT VERIFIED table, what the user must test on Windows)
PHASE 2 - RELIABILITY
* (2a) Resumable jobs: DONE, see STATE. Remaining idea: surface "continued automatically" in the Queue UI and click it through in a browser.
* Editable settings (backend DONE; UI form pending): whitelist of keys, per-field validation, atomic `.env` write with a backup that preserves comments and the file's encoding (`envload.py` reads UTF-8/UTF-16/ANSI), secrets write-only and masked, each field labelled "restart required" or "applies now". Backend and UI form are done (see STATE); the scheduler keeps its own `PUT /scheduler`.
* Split oversized files without behaviour change (re-export for compatibility; existing tests stay green): `router.py` (DONE, session 7), `ytdlp.py` (DONE, session 7), legacy `renderer.py` (DONE, session 7), `frontend/app/vanta/CreateView.tsx` (30 KB), `frontend/app/legacy/page.tsx` (53 KB, very long lines).
PHASE 3 - CLIP QUALITY
* Rating workflow in the UI (six rating labels and `/evaluation/summary` already exist; `selection/dataset_eval.py` has `--export-pool` / `--dataset`). Report engine vs heuristic with sample size and the >=30 threshold; say "no conclusion" when data is too small.
* Rank-weights editor with reset (today env-only: `VANTA_RANK_WEIGHTS`, scoring.py). Decision pending: UI override beats `.env` with a visible "overridden" badge (default yes).
* Multilingual cues, Hindi first. `selection/lexicon.py` tokenises with `[A-Za-z0-9']+`, which probably drops Devanagari: confirm with a failing test, then make tokenisation Unicode-aware with English output unchanged (test it).
* Optional: better Ollama re-ranking, fake transport only.
PHASE 4 - RENDERING
* NVENC: detect by a real 1-frame test encode, automatic libx264 fallback (libx264 is hardcoded at `clipstudio/render.py`), show the encoder actually used in the UI and export record. Never fail a render because the GPU encoder is missing. Leave legacy `renderer.py` / `pro_render.py` alone.
* Pluggable face/person reframing adapter; default stays blur/centre crop; UI says when no detector is installed. Risk: the user's machine may use Python 3.14 where OpenCV / faster-whisper wheels may not exist, so make it optional and degrade cleanly.
* Hook-first cold-open template, intro/outro slots, batch export presets (aspect + caption style + audio), waveform/timeline trimming (FFmpeg peaks endpoint) in addition to typed timestamps.
PHASE 5 - PUBLISHING (manual approval stays)
* Optional local-LLM title/description/hashtags with provenance and the transcript-only version always available as fallback.
* Optional read-only YouTube analytics via the existing OAuth, mocks only unless the user confirms credentials.
* Do NOT add other platforms or auto-publishing without asking.

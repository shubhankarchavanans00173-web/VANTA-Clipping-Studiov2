@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo VANTA - Enable public video link downloads (yt-dlp)
echo ============================================================
echo Installs the free yt-dlp downloader into the SAME Python environment the
echo backend uses, and turns the feature on in .env. Use only videos you own or
echo have permission to use. This does not bypass private, login, age, DRM or
echo regional restrictions and makes no paid API calls.
echo.
call "%~dp0_find_python.bat"
if not defined STUDIO_PYTHON (
  echo Could not find the backend Python environment. Run setup_backend.bat first.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
echo Backend Python: %STUDIO_PYTHON%
"%STUDIO_PYTHON%" -m pip install --upgrade --upgrade-strategy only-if-needed -r backend\requirements-links.txt
if errorlevel 1 (
  echo Failed to install yt-dlp. Check your internet connection. Nothing else was changed.
  if not "%VANTA_NO_PAUSE%"=="1" pause
  exit /b 1
)
if not exist ".env" (
  if exist ".env.example" (copy ".env.example" ".env" >nul) else (type nul > ".env")
)
findstr /R /C:"^[ ]*VANTA_ENABLE_YTDLP=1" ".env" >nul
if errorlevel 1 (
  >>".env" echo.
  >>".env" echo # Enables best-effort public platform link ingestion
  >>".env" echo VANTA_ENABLE_YTDLP=1
)
echo.
echo Running diagnostics...
"%STUDIO_PYTHON%" backend\diagnose.py
set "RC=%ERRORLEVEL%"
echo.
echo Restart VANTA (stop_all.bat, then start_all.bat) so the backend re-reads .env.
echo If a video cannot be fetched, upload a permitted local file instead.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

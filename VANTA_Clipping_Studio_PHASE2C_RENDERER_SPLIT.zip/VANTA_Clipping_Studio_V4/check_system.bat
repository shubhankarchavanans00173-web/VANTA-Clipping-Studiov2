@echo off
setlocal
cd /d "%~dp0"
call "%~dp0_find_python.bat"
set "RC=0"
echo ===== VANTA system check =====
where ffmpeg >nul 2>nul && (echo [OK] ffmpeg found) || (echo [!!] ffmpeg NOT found - install: winget install Gyan.FFmpeg then reopen this window & set "RC=1")
where ffprobe >nul 2>nul && (echo [OK] ffprobe found) || (echo [!!] ffprobe NOT found - it ships with ffmpeg & set "RC=1")
where node >nul 2>nul && (echo [OK] node found: & node --version) || (echo [!!] Node.js NOT found - install v20+ from https://nodejs.org & set "RC=1")
if defined STUDIO_PYTHON ( echo [OK] backend Python: %STUDIO_PYTHON% & "%STUDIO_PYTHON%" --version ) else ( echo [!!] Python 3.10+ backend environment not found - run setup_backend.bat & set "RC=1")
if exist ".env" (echo [OK] .env found) else (echo [--] no .env yet: start_all.bat creates it from .env.example)
if defined STUDIO_PYTHON ( echo. & "%STUDIO_PYTHON%" backend\diagnose.py ) else set "RC=1"
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

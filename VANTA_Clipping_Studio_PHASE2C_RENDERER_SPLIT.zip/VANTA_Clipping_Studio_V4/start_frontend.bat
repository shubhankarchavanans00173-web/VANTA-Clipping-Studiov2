@echo off
setlocal
cd /d "%~dp0frontend"
where node >nul 2>nul || ( echo Node.js 20+ was not found. Run setup_frontend.bat after installing Node.js. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
where npm >nul 2>nul || ( echo npm was not found. Run setup_frontend.bat after repairing Node.js. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
if not exist "node_modules\next\package.json" ( echo Frontend dependencies are missing. Run setup_frontend.bat first. & if not "%VANTA_NO_PAUSE%"=="1" pause & exit /b 1 )
npm run dev
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" echo Frontend stopped with an error.
if not "%VANTA_NO_PAUSE%"=="1" pause
endlocal & exit /b %RC%

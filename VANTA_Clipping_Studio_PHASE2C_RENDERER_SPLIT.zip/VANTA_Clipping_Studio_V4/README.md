# VANTA Clipping Studio

> **Development status:** VANTA is an actively developed, local-first project. Some features and integrations remain unverified on Windows or against live platform services. See `docs/FINAL_TEST_REPORT.md` and `UPGRADE_STATUS.md` for the exact verified, partial, and pending work. Do not treat YouTube ingestion, automatic scheduling, or YouTube publishing as production-ready.


Turn a video file (or a supported video link) into ready-to-review vertical **Shorts**.
Upload → analyse → review ranked suggestions → trim / approve → render real MP4s → download.
**Human approval is required before every export, and nothing is ever published automatically.**

VANTA is built on top of the earlier *Universal AI Shorts Studio* (text-to-video generator). That studio is untouched and still
available at `/legacy` (original docs: `docs/LEGACY_README.md`).

## What it does
| Step | Details |
|---|---|
| Input | Local upload (mp4, mov, mkv, webm, avi, …, validated with ffprobe) or a link (see *Links* below) |
| Transcript | Attach `.srt` / `.vtt` / `.json` (Whisper-style, word timings supported) or use free local `faster-whisper` (run `enable_local_transcription.bat`, then approve one model download in AI Models; see `docs/LOCAL_TRANSCRIPTION.md`) |
| Analysis | **V4 multi-signal engine** (`docs/INTELLIGENT_CLIPS.md`): sentence-based candidates, hook / payoff / standalone clarity / completeness / opening & ending / context dependency / repetition features, optional audio-loudness and scene-cut signals, diverse selection, evidence-based “Why selected”, confidence, alternatives, and your own ratings. The original simple heuristic stays selectable and is the visible fallback. Without a transcript the result is **labelled** low-confidence cues only |
| Review | Rank, score, excerpt, *why selected*, editable start/end (`1:05.5`, `65.5`, `0:01:05`), “start/end = playhead”, custom ranges, approve/reject, live preview with caption overlay |
| Render | 9:16 (1080×1920), 1:1, 16:9 · H.264 + AAC · 30 fps · accurate trim · blurred-background or centre-crop reframing · burned-in captions (word highlight or clean) · optional silence removal · optional music with ducking · volume control |
| Validation | Every export is re-inspected with ffprobe (codec, size, fps, audio, duration). A file only becomes downloadable if that passes |
| Tracking | Projects, jobs (real states and progress), exports and caption templates in SQLite |

**Scores are relative rankings within one video. They are not predictions of views or virality.**

## Install and run (Windows, same as before)
1. Install **Python 3.11 or 3.12 (recommended; 3.10 still works)**, **Node.js 20+**, **FFmpeg** (`winget install Gyan.FFmpeg`, reopen the terminal). `check_system.bat` verifies.
2. `setup_all.bat` (once), then `start_all.bat` → http://localhost:3000
3. Optional: copy `.env.example` to `.env`.

Linux/macOS: `pip install -r backend/requirements.txt`, `python backend/run.py` (port 8000), and in `frontend/`: `npm install && npm run dev`.

Optional extras: `pip install -r backend/requirements-optional.txt` (faster-whisper, yt-dlp).

## Using it
1. **Create Shorts** → *Upload video* (progress shown). Optionally *Attach transcript*.
2. Pick a target length (15/30/45/60 s) → **Analyze**. The Processing Queue shows the real state; percentages appear only when a step reports them.
3. Click **Preview** on a suggestion; tick the checkbox to approve; adjust times if needed.
4. Choose format, captions, audio → **Render**. Exports appear below and in **Exports** (MP4 + SRT).

## YouTube / video links (V3)
Full guide: **`docs/YOUTUBE_LINKS.md`**. Short version (Windows):
1. `setup_backend.bat` (once), install **FFmpeg** (`winget install Gyan.FFmpeg`) and **Node.js 20+** (needed by YouTube's JavaScript challenge).
2. `enable_youtube_links.bat` — installs `yt-dlp[default]` into the *same* Python the backend uses, sets `VANTA_ENABLE_YTDLP=1`, prints a diagnostic report.
3. `stop_all.bat`, then `start_all.bat`. Open **Video Links → Diagnostics**: every line should say `ok`.
4. Paste a watch / `youtu.be` / Shorts / embed link, tick the rights box, **Check link & download**. A real download job runs (progress in Create Shorts and the Queue); the file is validated with ffprobe before it becomes a source. Then **Analyze**.
5. Test without the UI: `diagnose_youtube.bat https://www.youtube.com/watch?v=jNQXAC9IVRw` (downloads for real, validates, deletes).
6. **One-command verification:** `verify_all.bat` runs the system check, a live YouTube download, the transcription and caption self-checks and the backend tests, then writes **`verify_report.txt`** (credentials and your user folder are removed). Each check is PASS, FAIL or SKIPPED (*skipped = not verified*). Useful options: `--skip-tests`, `--skip-network`, `--url <public video>`, `--video <file>` (real 60 s Whisper run; the model must already be downloaded). It never registers the scheduled task, never uploads and never downloads a model. Tests can take 10-25 minutes.
6. Stop: `stop_all.bat` (or close the two console windows).

Failures are classified precisely (unavailable, login/age, bot check, live, region, DRM, rate limit, network/timeout, extraction/JS-challenge, FFmpeg, disk, …) with a "what to do" hint and a **Retry download** button; a valid local copy is never downloaded twice. **Update yt-dlp** updates only the Python environment the backend runs in and reports the exact executable and versions. VANTA does not bypass private, login, age, DRM, bot-check or regional restrictions. If a link cannot be fetched, **upload the video file** (always works). No paid API is involved.

## Links
* **Direct file links** (`https://…/clip.mp4`): always available. Public hosts only, ≤1 GiB, ≤3 redirects, no credentials/custom ports; private/loopback/metadata addresses are blocked (re-checked on every redirect).
* **YouTube, Vimeo, TikTok, Instagram, X pages**: opt-in via `enable_youtube_links.bat` (installs `yt-dlp` and sets `VANTA_ENABLE_YTDLP=1`). Best effort for public videos you have the right to use. Private, login-gated, age-restricted, DRM or region-blocked videos are reported with a clear error and are **never bypassed**.
* DRM streaming services (Netflix, Prime, Disney+ …) are refused.
* If a link fails, **upload the file** — that always works.

## Optional paid cloud AI (off by default)
`VANTA_CLOUD_AI_ENABLED=1`, `VANTA_CLOUD_AI_MODEL`, `ANTHROPIC_API_KEY` (backend only). Then *AI Models* → *Get cost estimate* shows provider, model and estimated tokens/cost → you must tick and confirm. Each estimate is single-use, there are no automatic retries and no fallback to other providers. Without all three settings nothing can be sent.

## Limitations (honest list)
* **No subject tracking** — no detector is bundled; reframing is blurred-background or centre crop.
* **Local transcription needs `faster-whisper` and one approved model download.** Tested only with a stub model so far (see `docs/LOCAL_TRANSCRIPTION.md`); run `scripts\check_transcription.bat` to verify it on your PC. Without it, attach a transcript or accept the labelled audio/visual fallback.
* Without word timings (plain SRT/VTT), captions are **sentence-level** and the UI says so.
* **A live YouTube download has NOT been verified**: the build sandbox cannot resolve youtube.com. The downloader, staging, validation, retry, cancel and error classification are tested against stub downloader processes, and the real yt-dlp was run and correctly reported a DNS failure. Run `diagnose_youtube.bat <public url>` on your PC for the real check. The live `pip` update was only tested with a stubbed pip.
* The Windows `.bat` scripts and the `taskkill` process-tree kill were not executed (Linux sandbox); the POSIX equivalent is tested.
* The UI was built and type-checked, and every backend route it calls was exercised over HTTP, but no browser was available to click through it.
* Rendering is CPU-bound (roughly 0.3–1× real time at 1080p on a laptop).
* Single worker: jobs run one at a time on purpose. After a backend restart, interrupted **render and download** jobs continue automatically as a new job (finished clips are kept; capped at 2 resumes in a row; switch off with `VANTA_RESUME_JOBS=0`). Interrupted analysis/transcription jobs are marked *Failed* - start them again.
* In-browser playback depends on your browser decoding H.264 (normal desktop browsers do).
* Settings: **Settings → Editable settings** edits 20 whitelisted `.env` keys (grouped; shows the saved value and the value the running backend uses; per-field validation errors; "Remove my override" per field; API keys are write-only password boxes that only ever say "is set", with a Clear button). Writes are atomic with a `.env.bak` backup, keep comments and the file's encoding, and every change needs a backend restart (the page shows a "Restart required" banner until the running value matches). Linux-verified with a headless-browser click-through (`docs/ui_checks/settings_clickthrough.py`); the real restart check on Windows is still yours to run (see `docs/FINAL_TEST_REPORT.md`, Phase 2b-UI).

## API
Interactive docs at http://127.0.0.1:8000/docs (`/api/vanta/*`). Code layout: `backend/app/clipstudio/router.py` assembles the route modules in `backend/app/clipstudio/routes/` (`system`, `scheduling`, `projects`, `transcription`, `candidates`, `render_jobs`, `exports`, `publishing`, `templates`, `cloud_ai`; shared helpers in `common.py`). The yt-dlp adapter `backend/app/clipstudio/ytdlp.py` keeps the orchestrators (`installed`, `version`, `base_command`, `diagnostics`, `download`, `update`) and re-exports the leaf modules `ytdlp_const`, `ytdlp_urls`, `ytdlp_errors`, `ytdlp_probe`, `ytdlp_proc`; always import it as `from app.clipstudio import ytdlp`. The legacy renderer `backend/app/renderer.py` likewise keeps `render_video`, `_render_ai_video` and the motion-score helpers and re-exports the leaf modules `renderer_common`, `renderer_scenes`, `renderer_audio`, `renderer_validate`, `renderer_download`, `renderer_clips`; `pro_render.py` is unchanged. Key routes: `POST /projects/upload`, `POST /projects/link`, `POST /projects/{id}/analyze`, `PATCH /candidates/{id}`, `POST /projects/{id}/render`, `GET /jobs`, `GET /exports/{id}/download`.

## Development and tests
```
python -m compileall -q backend
set PYTHONPATH=backend
python -m unittest discover -s backend/tests -v      (182 tests; they build synthetic video with local FFmpeg and use stub downloader processes — no network)
cd frontend && npm install && npm run build
```
Tests never call a paid service or the network. See `UPGRADE_STATUS.md` for the verified results and `CONTINUATION_PROMPT.md` (the single current hand-off file) to resume work.

## Troubleshooting
* *“Backend not reachable”* — start `start_backend.bat`; port 8000 must be free.
* *“FFmpeg is missing”* — install FFmpeg and restart the backend.
* *Upload rejected “not readable media”* — the file is corrupt/not video; try re-exporting it.
* *Link fails* — read the code and hint in the red box (table in `docs/YOUTUBE_LINKS.md`), run **Video Links → Diagnostics**, then **Update yt-dlp**, then **Retry download**; or upload the file.
* *“Python 3.10 … Please update to Python 3.11” in a log* — only a warning about the Python version; harmless to downloads (optional upgrade: `migrate_python_env.bat`).
* *Backend ignores `.env`* — `.env` must be in the project root; it is read at backend start (restart). Saved as UTF-8, UTF-16 or ANSI all work.
* *No word highlighting* — your transcript has no word timings; use a JSON transcript with words or faster-whisper.

### Auto Clip (automatic find + render)
In Create Shorts, choose a project, set the target clip duration and number of suggestions, then click **Auto Clip · Find & Render**. VANTA runs its existing local ranking pipeline, approves the ranked candidates, and automatically queues vertical MP4 rendering with the current caption settings. You do not need to select timestamps manually. The normal Analyze/review/Render flow remains available too.

Important: ranking currently uses heuristic transcript/audio/scene signals, not a trained virality predictor; scores are not view predictions. Local transcription depends on the configured transcription engine being installed. If it is unavailable, VANTA falls back to available audio/visual signals and labels that limitation. Auto Clip does not publish to YouTube. Test with a video you have permission to use.

## Final2 additions: local scheduler and YouTube upload

The optional scheduler is **off by default**. In Create Shorts, approve a clip
and choose Schedule; then configure its timezone, daily time, videos per run,
retry count and pause state under Settings. It persists its queue in the VANTA
database, locks to a single backend, writes a scheduler log, recovers
interrupted work safely, and only renders local, already-approved clips. It
never uploads or publishes. Use install_scheduler_task.bat to start the local
backend at Windows sign-in, and uninstall_scheduler_task.bat to remove that
per-user helper. The task does not enable scheduling.

In Exports, review a video, its transcript-derived details and optional
thumbnail, then expand YouTube upload. It uses official backend-only OAuth,
defaults to Private, and requires a new checkbox confirmation for each export.
Full setup and live-testing limits are in docs/YOUTUBE_UPLOAD_SETUP.md.

### Windows start and troubleshooting

Run setup_all.bat, then check_system.bat, then start_all.bat. The scripts are
location-independent and choose the same Python 3.10+ interpreter through
_find_python.bat. They check Python, Node.js, FFmpeg and FFprobe. If a check
fails, install the named prerequisite, reopen the terminal, and rerun it.
VANTA_NO_PAUSE=1 suppresses pauses for automation. See .env.example for
upload/duration limits and optional local-only settings.

### Evaluation and release status

docs/CLIP_SELECTION_EVALUATION.md explains export-pool, dataset,
development/test splits and the no-human-label limitation. The current exact
verification/limitations are in docs/FINAL_TEST_REPORT.md.

## V4: intelligent clip selection
Full guide: `docs/INTELLIGENT_CLIPS.md`. Results of the baseline-vs-engine comparison and their limits: `docs/EVALUATION.md` (`python backend/evaluate_ranking.py`).
* Create Shorts → **Ranking** selects *Multi-signal (recommended)* or *Simple heuristic*. **Why selected** shows the summary, hook/payoff quotes, caveats, confidence, signals used / not analysed, per-feature evidence, alternative cut points, and rating buttons.
* Optional local language model via Ollama (`VANTA_LOCAL_LLM=ollama`, `VANTA_LOCAL_LLM_MODEL=...`): off by default, never downloads anything, validated output only, ±15 point influence. Tested with a fake transport only.
* **Not analysed:** laughter/applause, faces/emotion, on-screen text, vertical-crop suitability. Rule-based language cues are English only.
* Run backend tests per module if your shell has a time limit: `set PYTHONPATH=backend` then `python -m unittest tests.test_selection` etc. (227 tests in total).

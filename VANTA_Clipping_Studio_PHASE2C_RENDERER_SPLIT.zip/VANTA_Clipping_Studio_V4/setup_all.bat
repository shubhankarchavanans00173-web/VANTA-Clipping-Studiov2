@echo off
setlocal
cd /d "%~dp0"
call "%~dp0setup_backend.bat"
if errorlevel 1 ( endlocal & exit /b 1 )
call "%~dp0setup_frontend.bat"
set "RC=%ERRORLEVEL%"
endlocal & exit /b %RC%
